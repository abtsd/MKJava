import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.util.concurrent.CountDownLatch;

public class MyRegistry {
	public static void main(String[] args) throws RemoteException, InterruptedException {
		var port = 1099;
		if (args.length == 1) {
			port = Integer.parseInt(args[0]);
		}

		CountDownLatch latch = new CountDownLatch(1);
		LocateRegistry.createRegistry(port);
		latch.await();
	}
}
