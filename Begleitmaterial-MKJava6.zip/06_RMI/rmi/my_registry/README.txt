java -cp out/production/my_registry;out/production/rmi MyRegistry
java -cp out/production/my_registry;out/production/rmi MyRegistry 40000
