java --add-opens=java.base/java.lang=ALL-UNNAMED --add-opens=java.base/java.io=ALL-UNNAMED --add-opens=java.rmi/sun.rmi.transport=ALL-UNNAMED -cp ../../webserver/webserver.jar;../../libs/tomcat/* WebServer /demo out/production/agent_client 8080 false false

java -Djava.rmi.server.codebase=http://localhost:8080/demo/ -cp out/production/agent_client Client localhost
