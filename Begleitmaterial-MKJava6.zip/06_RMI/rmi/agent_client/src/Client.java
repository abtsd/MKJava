import agent.ServerAgent;

import java.rmi.Naming;

public class Client {
	public static void main(String[] args) throws Exception {
		var host = args[0];
		var remote = (ServerAgent) Naming.lookup("//" + host + "/agent");
		var demo = new DemoAgent(100);
		var result = (DemoAgent) remote.execute(demo);
		System.out.println(result.getResult());
	}
}
