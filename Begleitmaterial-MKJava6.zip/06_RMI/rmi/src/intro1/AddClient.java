package intro1;

public class AddClient {
	public static void main(String[] args) {
		var service = new AddServer();
		System.out.println(service.add(2.3, 5.7));
	}
}
