package intro1;

public class AddServer {
	public double add(double x, double y) {
		return x + y;
	}
}
