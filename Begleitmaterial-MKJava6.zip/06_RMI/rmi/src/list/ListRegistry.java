package list;

import java.rmi.ConnectException;
import java.rmi.Naming;

public class ListRegistry {
    public static void main(String[] args) throws Exception {
        var host = args[0];

        var registryNames = new String[]{
                "//" + host + ":1099",
                "//" + host + ":40000"
        };

        for (var registryName : registryNames) {
            try {
                var list = Naming.list(registryName);
                for (var name : list) {
                    System.out.println(name);
                }
            } catch (ConnectException e) {
                System.err.println("Keine Verbindung zu: " + registryName);
            }
        }
    }
}
