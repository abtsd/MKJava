package intro2;

public interface Add {
	double add(double x, double y);
}