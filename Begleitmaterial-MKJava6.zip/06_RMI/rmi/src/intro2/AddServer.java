package intro2;

public class AddServer implements Add {
	public double add(double x, double y) {
		return x + y;
	}
}