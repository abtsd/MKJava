package intro2;

public class AddClient {
	public static void main(String[] args) {
		var service = AddFactory.getInstance();
		System.out.println(service.add(2.3, 5.7));
	}
}