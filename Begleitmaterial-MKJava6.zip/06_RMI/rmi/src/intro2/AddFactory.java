package intro2;

public class AddFactory {
	public static Add getInstance() {
		return new AddServer();
	}
}