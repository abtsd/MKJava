package intro3;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class AddServer extends UnicastRemoteObject implements Add {
	public AddServer() throws RemoteException {
	}

	public double add(double x, double y) {
		return x + y;
	}

	public static void main(String[] args) throws Exception {
		var server = new AddServer();
		Naming.rebind("add", server);
	}
}