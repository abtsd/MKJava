package intro3;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Add extends Remote {
	double add(double x, double y) throws RemoteException;
}