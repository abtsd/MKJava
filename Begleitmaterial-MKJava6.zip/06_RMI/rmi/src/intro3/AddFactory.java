package intro3;

import java.rmi.Naming;

public class AddFactory {
	public static Add getInstance() throws Exception {
		return (Add) Naming.lookup("//localhost/add");
	}
}