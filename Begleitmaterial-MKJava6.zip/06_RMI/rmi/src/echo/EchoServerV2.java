package echo;

import java.rmi.Naming;
import java.rmi.server.UnicastRemoteObject;

public class EchoServerV2 {
	public static void main(String[] args) throws Exception {
		var remote = new EchoImplV2();
		UnicastRemoteObject.exportObject(remote, 50000);
		Naming.rebind("echo", remote);
		System.out.println("EchoServerV2 gestartet ...");
	}
}
