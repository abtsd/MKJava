package echo;

public class EchoImplV2 implements Echo {
	public String getEcho(String s) {
		return s;
	}
}
