package echo;

import java.rmi.Naming;

public class EchoClient {
	public static void main(String[] args) throws Exception {
		var host = args[0];

		var remote = (Echo) Naming.lookup("//" + host + "/echo");
		var received = remote.getEcho("Das ist ein Test.");
		System.out.println(received);
	}
}
