package echo;

import java.rmi.Naming;

public class EchoServerV1 {
	public static void main(String[] args) throws Exception {
		var remote = new EchoImplV1();
		Naming.rebind("echo", remote);
		System.out.println("EchoServerV1 gestartet ...");
	}
}
