package echo;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class EchoImplV1 extends UnicastRemoteObject implements Echo {
	public EchoImplV1() throws RemoteException {
	}

	public String getEcho(String s) {
		return s;
	}
}
