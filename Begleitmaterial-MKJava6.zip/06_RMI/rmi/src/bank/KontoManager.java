package bank;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface KontoManager extends Remote {
	Konto getKonto(int id, int pin) throws RemoteException;
}
