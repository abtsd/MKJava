package bank;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class KontoImpl extends UnicastRemoteObject implements Konto {
	private final int pin;
	private int saldo;

	public KontoImpl(int pin) throws RemoteException {
		this.pin = pin;
	}

	public int getSaldo() {
		return saldo;
	}

	public void add(int betrag) {
		if (saldo + betrag < 0) {
			throw new IllegalArgumentException("Das Konto kann nicht überzogen werden.");
		}
		saldo += betrag;
	}

	public int getPin() {
		return pin;
	}
}
