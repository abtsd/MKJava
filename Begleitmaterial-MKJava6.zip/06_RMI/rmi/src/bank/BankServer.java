package bank;

import java.rmi.Naming;

public class BankServer {
	public static void main(String[] args) throws Exception {
		var remote = new KontoManagerImpl();
		Naming.rebind("bank", remote);
		System.out.println("BankServer gestartet ...");
	}
}
