package bank;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Hashtable;

public class KontoManagerImpl extends UnicastRemoteObject implements KontoManager {
	private final Hashtable<Integer, KontoImpl> hashtable;

	public KontoManagerImpl() throws RemoteException {
		hashtable = new Hashtable<>();
	}

	public Konto getKonto(int id, int pin) throws RemoteException {
		var konto = hashtable.get(id);
		if (konto == null) {
			konto = new KontoImpl(pin);
			hashtable.put(id, konto);
			System.out.println("Konto " + id + " wurde eingerichtet.");
			return konto;
		} else {
			if (konto.getPin() == pin)
				return konto;
			else
				throw new IllegalArgumentException("PIN ist ungültig.");
		}
	}
}
