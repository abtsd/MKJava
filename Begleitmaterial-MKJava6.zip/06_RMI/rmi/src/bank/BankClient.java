package bank;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.util.Scanner;

public class BankClient {
    public static void main(String[] args) {
        var host = args[0];
        var id = Integer.parseInt(args[1]);
        var pin = Integer.parseInt(args[2]);

        Konto konto;
        try {
            var manager = (KontoManager) Naming.lookup("//" + host + "/bank");
            konto = manager.getKonto(id, pin);
        } catch (Exception e) {
            System.err.println(e.getMessage());
            return;
        }

        try (var scanner = new Scanner(System.in)) {
            String input;
            while (true) {
                try {
                    System.out.println("get | <zahl> | q:");
                    input = scanner.nextLine();
                    if (input.length() == 0 || input.equals("q"))
                        break;
                    if (input.equals("get")) {
                        System.out.println("Aktueller Kontostand: " + konto.getSaldo());
                    } else {
                        var betrag = Integer.parseInt(input);
                        konto.add(betrag);
                    }
                } catch (NumberFormatException ignored) {
                } catch (IllegalArgumentException | RemoteException e) {
                    System.err.println(e.getMessage());
                }
            }
        }
    }
}
