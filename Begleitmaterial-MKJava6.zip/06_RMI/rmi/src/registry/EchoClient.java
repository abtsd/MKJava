package registry;

import java.rmi.Naming;

public class EchoClient {
	public static void main(String args[]) throws Exception {
		var host = args[0];
		var port = 40000;
		String text = "Das ist ein Test.";

		var remote = (Echo) Naming.lookup("//" + host + ":" + port + "/echo");
		var received = remote.getEcho(text);
		System.out.println(received);
	}
}
