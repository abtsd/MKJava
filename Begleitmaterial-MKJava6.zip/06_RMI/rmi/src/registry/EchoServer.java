package registry;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;

public class EchoServer {
	public static void main(String args[]) throws Exception {
		var registryPort = 40000;

		LocateRegistry.createRegistry(registryPort);
		var remote = new EchoImpl();
		UnicastRemoteObject.exportObject(remote, 50000);
		Naming.rebind("//:" + registryPort + "/echo", remote);
		System.out.println("EchoServer gestartet ...");
	}
}
