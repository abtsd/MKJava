package registry;

public class EchoImpl implements Echo {
	public String getEcho(String s) {
		return s;
	}
}
