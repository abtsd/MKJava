java -cp out/production/rmi intro1.AddClient
java -cp out/production/rmi intro2.AddClient

rmiregistry -J-Djava.class.path=out/production/rmi
java -cp out/production/rmi intro3.AddServer
java -cp out/production/rmi intro3.AddClient

rmiregistry -J-Djava.class.path=out/production/rmi -J-Djava.rmi.server.logCalls=true
java -cp out/production/rmi echo.EchoServerV1
java -cp out/production/rmi echo.EchoClient localhost
java -cp out/production/rmi echo.EchoServerV2
java -cp out/production/rmi echo.EchoClient localhost

java -cp out/production/rmi registry.EchoServer
java -cp out/production/rmi registry.EchoClient localhost

java -cp out/production/rmi list.ListRegistry localhost

rmiregistry -J-Djava.class.path=out/production/rmi
java -cp out/production/rmi bank.BankServer
java -cp out/production/rmi bank.BankClient localhost 4711 12345
