# Zur Ausgabe von Sonderzeichen bei Windows: chcp 1252
java -cp out/production/callback_client subscriber.Subscriber localhost 60000
java -cp out/production/callback_client publisher.Publisher localhost "Das ist ein Test"
