package subscriber;

import message.api.MessageManager;

import java.rmi.Naming;
import java.rmi.RemoteException;

public class Subscriber {
    public static void main(String[] args) throws Exception {
        var host = args[0];
        var millis = Integer.parseInt(args[1]);

        var manager = (MessageManager) Naming.lookup("//" + host + "/message");

        var listener = new MessageListenerImpl();
        manager.setMessageListener(listener);

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                manager.removeMessageListener(listener);
            } catch (RemoteException e) {
                System.err.println(e);
            }
        }));

        try {
            Thread.sleep(millis);
        } catch (InterruptedException ignored) {
        }

        System.exit(0);
    }
}
