package subscriber;

import message.api.Message;
import message.api.MessageListener;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class MessageListenerImpl extends UnicastRemoteObject implements MessageListener {
	public MessageListenerImpl() throws RemoteException {
	}

	public void onMessage(Message message) {
		System.out.println(message.getTimestamp());
		System.out.println("\t" + message.getText());
	}
}
