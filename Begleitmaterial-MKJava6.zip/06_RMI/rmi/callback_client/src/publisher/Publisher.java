package publisher;

import message.api.Message;
import message.api.MessageManager;

import java.rmi.Naming;
import java.time.LocalDateTime;

public class Publisher {
	public static void main(String[] args) throws Exception {
		var host = args[0];
		var text = args[1];

		var manager = (MessageManager) Naming.lookup("//" + host + "/message");
		var message = new Message();
		message.setTimestamp(LocalDateTime.now());
		message.setText(text);
		manager.send(message);
	}
}
