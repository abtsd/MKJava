package message.api;

import java.io.Serializable;
import java.time.LocalDateTime;

public class Message implements Serializable {
	private LocalDateTime timestamp;
	private String text;

	public LocalDateTime getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getText() {
		return text;
	}
}
