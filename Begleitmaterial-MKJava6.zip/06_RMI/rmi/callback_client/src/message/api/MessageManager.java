package message.api;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface MessageManager extends Remote {
	void setMessageListener(MessageListener listener) throws RemoteException;

	void removeMessageListener(MessageListener listener) throws RemoteException;

	void send(Message message) throws RemoteException;
}
