import java.rmi.Naming;

public class MessageServer {
	public static void main(String[] args) throws Exception {
		var remote = new MessageManagerImpl();
		Naming.rebind("message", remote);
		System.out.println("MessageServer gestartet ...");
	}
}
