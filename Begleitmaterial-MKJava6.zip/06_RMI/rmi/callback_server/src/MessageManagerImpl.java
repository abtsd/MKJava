import message.api.Message;
import message.api.MessageListener;
import message.api.MessageManager;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class MessageManagerImpl extends UnicastRemoteObject implements MessageManager {
	private final List<MessageListener> listeners;

	public MessageManagerImpl() throws RemoteException {
		listeners = new CopyOnWriteArrayList<>();
		new ControlThread().start();
	}

	public void setMessageListener(MessageListener listener) {
		listeners.add(listener);
	}

	public void removeMessageListener(MessageListener listener) {
		listeners.remove(listener);
	}

	public synchronized void send(Message message) {
		for (var listener : listeners) {
			try {
				listener.onMessage(message);
			} catch (RemoteException e) {
				System.err.println(e.getMessage());
			}
		}
	}

	private class ControlThread extends Thread {
		public void run() {
			while (true) {
				try {
					Thread.sleep(5000);
				} catch (InterruptedException ignored) {
				}

				System.out.println("Anzahl Subscribers: " + listeners.size());
			}
		}
	}
}
