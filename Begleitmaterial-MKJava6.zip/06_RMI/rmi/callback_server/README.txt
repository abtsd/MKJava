rmiregistry -J-Djava.class.path=out/production/callback_server
java -cp out/production/callback_server MessageServer
