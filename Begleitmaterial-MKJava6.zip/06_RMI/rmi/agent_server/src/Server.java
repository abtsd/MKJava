import java.rmi.Naming;

public class Server {
	public static void main(String[] args) throws Exception {
		var remote = new ServerAgentImpl();
		Naming.rebind("agent", remote);
		System.out.println("Server gestartet ...");
	}
}
