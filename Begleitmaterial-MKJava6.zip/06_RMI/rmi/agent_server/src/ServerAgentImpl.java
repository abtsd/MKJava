import agent.Agent;
import agent.ServerAgent;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class ServerAgentImpl extends UnicastRemoteObject implements ServerAgent {
	public ServerAgentImpl() throws RemoteException {
	}

	public Agent execute(Agent agent) {
		agent.execute();
		return agent;
	}
}
