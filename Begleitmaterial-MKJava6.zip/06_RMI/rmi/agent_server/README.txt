rmiregistry -J-Djava.class.path=out/production/agent_server
java -Djava.rmi.server.useCodebaseOnly=false -Djava.security.manager -Djava.security.policy=policy.txt -cp out/production/agent_server Server
