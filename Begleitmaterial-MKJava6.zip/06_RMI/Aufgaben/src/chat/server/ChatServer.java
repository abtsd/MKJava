package chat.server;

import java.rmi.Naming;
import java.rmi.Remote;
import java.rmi.registry.LocateRegistry;

public class ChatServer {
	public static void main(String args[]) throws Exception {
		LocateRegistry.createRegistry(1099);
		Remote remote = new ChatManagerImpl();
		Naming.rebind("chat", remote);
		System.out.println("ChatServer gestartet ...");
	}
}
