package chat.server;

import chat.api.Callback;
import chat.api.ChatManager;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class ChatManagerImpl extends UnicastRemoteObject implements ChatManager {
	private final List<Callback> clients = new CopyOnWriteArrayList<>();

	public ChatManagerImpl() throws RemoteException {
	}

	@Override
	public void login(String user, Callback callback) {
		clients.add(callback);
		showLoginToAll(user);
		System.out.println("Login: " + user);
		System.out.println("Anzahl Clients: " + clients.size());
	}

	@Override
	public void logout(String user, Callback callback) {
		clients.remove(callback);
		showLogoutToAll(user);
		System.out.println("Logout: " + user);
		System.out.println("Anzahl Clients: " + clients.size());
	}

	@Override
	public void notifyClients(String name, String message) {
		showMessageToAll(name, message);
	}

	private void showLoginToAll(String user) {
		for (Callback callback : clients) {
			try {
				callback.showLogin(user);
			} catch (RemoteException e) {
				System.err.println(e.getMessage());
			}
		}
	}

	private void showLogoutToAll(String user) {
		for (Callback callback : clients) {
			try {
				callback.showLogout(user);
			} catch (RemoteException e) {
				System.err.println(e.getMessage());
			}
		}
	}

	private void showMessageToAll(String user, String message) {
		for (Callback callback : clients) {
			try {
				callback.showMessage(user, message);
			} catch (RemoteException e) {
				System.err.println(e.getMessage());
			}
		}
	}
}