package chat.client;

import chat.api.ChatManager;

import java.rmi.Naming;
import java.util.Scanner;

public class ChatClient {
	public static void main(String[] args) throws Exception {
		var host = args[0];
		var user = args[1];

		var remote = (ChatManager) Naming.lookup("//" + host + "/chat");

		var callback = new CallbackImpl();
		remote.login(user, callback);

		var scanner = new Scanner(System.in);
		while (true) {
			var text = scanner.nextLine();
			if (text.equals(".exit")) {
				remote.logout(user, callback);
				break;
			} else {
				remote.notifyClients(user, text);
			}
		}

		scanner.close();
		System.exit(0);
	}
}
