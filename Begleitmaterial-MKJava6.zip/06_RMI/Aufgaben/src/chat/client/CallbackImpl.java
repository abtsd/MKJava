package chat.client;

import chat.api.Callback;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class CallbackImpl extends UnicastRemoteObject implements Callback {
	public CallbackImpl() throws RemoteException {
	}

	@Override
	public void showLogin(String user) {
		System.out.println(user + " ist dazugekommen.");
	}

	@Override
	public void showLogout(String user) {
		System.out.println(user + " hat sich verabschiedet.");
	}

	@Override
	public void showMessage(String user, String message) {
		System.out.println(user + ": " + message);
	}
}