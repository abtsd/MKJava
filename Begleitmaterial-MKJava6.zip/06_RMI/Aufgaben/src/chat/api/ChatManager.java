package chat.api;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface ChatManager extends Remote {
	void login(String user, Callback callback) throws RemoteException;

	void logout(String user, Callback callback) throws RemoteException;

	void notifyClients(String user, String message) throws RemoteException;
}