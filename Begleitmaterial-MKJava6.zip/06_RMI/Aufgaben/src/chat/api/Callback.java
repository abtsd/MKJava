package chat.api;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Callback extends Remote {
	void showLogin(String user) throws RemoteException;

	void showLogout(String user) throws RemoteException;

	void showMessage(String user, String message) throws RemoteException;
}