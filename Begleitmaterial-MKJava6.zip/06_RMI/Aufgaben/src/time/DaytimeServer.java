package time;

import java.rmi.Naming;

public class DaytimeServer {
	public static void main(String[] args) throws Exception {
		var remote = new DaytimeImpl();
		Naming.rebind("daytime", remote);
		System.out.println("DaytimeServer gestartet ...");
	}
}
