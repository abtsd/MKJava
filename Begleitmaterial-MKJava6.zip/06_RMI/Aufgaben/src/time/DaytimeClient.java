package time;

import java.rmi.Naming;

public class DaytimeClient {
	public static void main(String[] args) throws Exception {
		var host = args[0];
		var remote = (Daytime) Naming.lookup("//" + host + "/daytime");
		String daytime = remote.getDaytime();
		System.out.println(daytime);
	}
}
