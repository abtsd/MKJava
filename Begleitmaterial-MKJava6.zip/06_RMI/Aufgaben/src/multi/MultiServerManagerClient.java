package multi;

import java.rmi.Naming;

public class MultiServerManagerClient {
	public static void main(String[] args) throws Exception {
		var host = args[0];
		var cmd = args[1];

		var remote = (MultiServerManager) Naming.lookup("//" + host + "/multiServerManager");

		if (cmd.equals("shutdown")) {
			remote.shutdown();
		} else if (cmd.equals("reconfigure")) {
			remote.reconfigure();
		}
	}
}
