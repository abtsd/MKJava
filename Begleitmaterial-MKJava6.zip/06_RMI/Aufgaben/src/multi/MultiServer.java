package multi;

import java.io.FileInputStream;
import java.io.IOException;
import java.rmi.Naming;
import java.rmi.Remote;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;
import java.util.Properties;

public class MultiServer extends UnicastRemoteObject implements MultiServerManager {
    private static final String MANAGER_SERVICE = "multiServerManager";
    private static final String SERVICES = "services.properties";
    private static final int REGISTRY_PORT = 1099;
    private Properties services;

    public MultiServer() throws Exception {
        LocateRegistry.createRegistry(REGISTRY_PORT);
        Naming.rebind(MANAGER_SERVICE, this);
        readServices();
        registerServices();
        System.out.println("MultiServer gestartet ...");
    }

    public void readServices() throws IOException {
        try (var in = new FileInputStream(SERVICES)) {
            services = new Properties();
            services.load(in);
        }
    }

    public void registerServices() throws Exception {
        var serviceNames = services.propertyNames();
        while (serviceNames.hasMoreElements()) {
            var name = (String) serviceNames.nextElement();
            var serv = Class.forName(services.getProperty(name));
            var remote = (Remote) serv.getDeclaredConstructor().newInstance();
            Naming.bind(name, remote);
            System.out.println("Dienst " + name + " wurde registriert.");
        }
    }

    public void unregisterServices() throws Exception {
        var list = Naming.list("//localhost:" + REGISTRY_PORT);
        for (var name : list) {
            if (!name.contains(MANAGER_SERVICE)) {
                Naming.unbind(name);
                System.out.println("Dienst " + name + " wurde beendet.");
            }
        }
    }

    public void shutdown() {
        System.out.println("MultiServer wird beendet ...");
        new Thread(() -> {
            try {
                unregisterServices();
            } catch (Exception ignored) {
            }
            System.exit(0);
        }).start();
    }

    public void reconfigure() {
        System.out.println("MultiServer wird rekonfiguriert ...");
        try {
            unregisterServices();
            readServices();
            registerServices();
        } catch (Exception e) {
            System.err.println(e);
        }
    }

    public static void main(String[] args) throws Exception {
        new MultiServer();
    }
}
