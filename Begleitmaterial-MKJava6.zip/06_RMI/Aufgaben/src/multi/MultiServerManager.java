package multi;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface MultiServerManager extends Remote {
	void shutdown() throws RemoteException;

	void reconfigure() throws RemoteException;
}