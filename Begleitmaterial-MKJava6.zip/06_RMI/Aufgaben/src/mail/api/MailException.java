package mail.api;

public class MailException extends Exception {
	public MailException() {
	}

	public MailException(String msg) {
		super(msg);
	}
}
