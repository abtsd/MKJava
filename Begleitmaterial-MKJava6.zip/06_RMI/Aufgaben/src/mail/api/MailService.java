package mail.api;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface MailService extends Remote {
	void register(Credentials credentials) throws RemoteException, MailException;

	void unregister(Credentials credentials) throws RemoteException, MailException;

	void sendMail(Credentials credentials, Mail mail) throws RemoteException, MailException;
	
	List<Mail> getMails(Credentials credentials) throws RemoteException, MailException;
}
