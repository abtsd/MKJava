package mail.client;

import mail.api.Credentials;
import mail.api.Mail;
import mail.api.MailException;
import mail.api.MailService;

import java.rmi.Naming;
import java.util.Scanner;

public class MailClient {
    public static void main(String[] args) throws Exception {
        var host = args[0];
        var user = args[1];
        var password = args[2];

        var remote = (MailService) Naming.lookup("//" + host + "/mail");
        var credentials = new Credentials(user, password);

        try (var scanner = new Scanner(System.in)) {
            while (true) {
                System.out.print("register, unregister, get, send, exit > ");
                String cmd = scanner.nextLine();
                if (cmd.equals("exit"))
                    break;

                switch (cmd) {
                    case "register":
                        try {
                            remote.register(credentials);
                            System.out.println("Angemeldet");
                        } catch (MailException e) {
                            System.err.println(e.getMessage());
                        }
                        break;

                    case "unregister":
                        try {
                            remote.unregister(credentials);
                            System.out.println("Abgemeldet");
                        } catch (MailException e) {
                            System.err.println(e.getMessage());
                        }
                        break;

                    case "get":
                        try {
                            var list = remote.getMails(credentials);
                            for (var mail : list) {
                                System.out.println(mail);
                            }
                        } catch (MailException e) {
                            System.err.println(e.getMessage());
                        }
                        break;

                    case "send":
                        String recipient;
                        do {
                            System.out.print("Empfänger: ");
                            recipient = scanner.nextLine().trim();
                        } while (recipient.length() == 0);

                        var message = "";
                        do {
                            System.out.print("Nachricht: ");
                            message = scanner.nextLine().trim();
                        } while (message.length() == 0);

                        var mail = new Mail(user, recipient, message);

                        try {
                            remote.sendMail(credentials, mail);
                            System.out.println("Mail wurde gesendet.");
                        } catch (MailException e) {
                            System.err.println(e.getMessage());
                        }
                        break;

                    default:
                        System.out.println("Falsches Kommando");
                        break;
                }
            }
        }
    }
}
