package mail.server;

import mail.api.Credentials;
import mail.api.Mail;
import mail.api.MailException;
import mail.api.MailService;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

public class MailServiceImpl extends UnicastRemoteObject implements MailService {
	private static final String FILE_NAME = "mail.dat";
	private Map<String, Credentials> users;
	private Map<String, List<Mail>> mails;

	public MailServiceImpl() throws RemoteException {
		users = new Hashtable<>();
		mails = new Hashtable<>();
		
		try {
			var file = new File(FILE_NAME);
			if (file.exists()) {
				restore();
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}

	@Override
	public void register(Credentials credentials) throws RemoteException, MailException {
		var user = credentials.getUser();
		if (users.get(user) != null) {
			throw new MailException("User '" + user + "' ist bereits angemeldet.");
		}

		users.put(user, credentials);
		System.out.println("User '" + user + "' wurde angemeldet.");
	}

	@Override
	public void unregister(Credentials credentials) throws RemoteException, MailException {
		checkPassword(credentials);

		var user = credentials.getUser();
		users.remove(user);
		System.out.println("User '" + user + "' wurde abgemeldet.");
	}

	@Override
	public void sendMail(Credentials credentials, Mail mail) throws RemoteException, MailException {
		checkPassword(credentials);

		var user = credentials.getUser();
		if (!mail.getSender().equals(user)) {
			throw new MailException("User '" + user + "' ist nicht der Absender.");
		}

		var recipient = mail.getRecipient();
		if (users.get(recipient) == null) {
			throw new MailException("Empfänger '" + recipient + "' ist nicht angemeldet.");
		}

		var list = mails.get(recipient);
		if (list == null) {
			list = new ArrayList<>();
		}

		list.add(mail);
		mails.put(recipient, list);
		System.out.println("mail.api.Mail '" + mail + "' wurde gespeichert.");
		System.out.println("Anzahl Mails für '" + recipient + "': " + list.size());
	}

	@Override
	public List<Mail> getMails(Credentials credentials) throws RemoteException, MailException {
		checkPassword(credentials);

		var user = credentials.getUser();
		var list = mails.remove(user);
		if (list == null) {
			list = new ArrayList<>();
		} else {
			System.out.println("Alle Mails für '" + user + "' wurden gelöscht.");
		}
		return list;
	}

	public void store() throws IOException {
		try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
			out.writeObject(users);
			out.writeObject(mails);
			out.flush();
		}
	}

	@SuppressWarnings("unchecked")
	private void restore() throws ClassNotFoundException, IOException {
		try (var in = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
			users = (Map<String, Credentials>) in.readObject();
			mails = (Map<String, List<Mail>>) in.readObject();
		}
	}

	private void checkPassword(Credentials credentials) throws MailException {
		var user = credentials.getUser();
		var c = users.get(user);
		if (c == null) {
			throw new MailException("User '" + user + "' ist nicht angemeldet.");
		}
		if (!c.getPassword().equals(credentials.getPassword())) {
			throw new MailException("Das Passwort ist falsch.");
		}
	}
}
