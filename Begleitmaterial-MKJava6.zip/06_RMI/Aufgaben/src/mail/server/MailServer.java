package mail.server;

import java.io.IOException;
import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

public class MailServer {
	public static void main(String[] args) throws Exception {
		LocateRegistry.createRegistry(1099);
		var service = new MailServiceImpl();
		
		Runtime.getRuntime().addShutdownHook(new Thread(() -> {
			try {
				service.store();
			} catch (IOException ignored) {
			}
		}));
		
		Naming.rebind("mail", service);
		System.out.println("MailServer gestartet ...");
	}
}
