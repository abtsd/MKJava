rmiregistry -J-Djava.class.path=../rmi/out/production/agent_server
java -Djava.rmi.server.useCodebaseOnly=false -Djava.security.manager -Djava.security.policy=../rmi/policy.txt -cp ../rmi/out/production/agent_server Server

java --add-opens=java.base/java.lang=ALL-UNNAMED --add-opens=java.base/java.io=ALL-UNNAMED --add-opens=java.rmi/sun.rmi.transport=ALL-UNNAMED -cp ../../webserver/webserver.jar;../../libs/tomcat/* WebServer /demo out/production/fak 8080 false false
java -Djava.rmi.server.codebase=http://localhost:8080/demo/ -cp out/production/fak FakClient localhost
