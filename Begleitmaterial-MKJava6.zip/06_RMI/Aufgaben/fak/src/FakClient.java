import agent.ServerAgent;

import java.rmi.Naming;

public class FakClient {
	public static void main(String args[]) throws Exception {
		var host = args[0];
		var remote = (ServerAgent) Naming.lookup("//" + host + "/agent");
		var fak = new Fakultaet(100);
		Fakultaet result = (Fakultaet) remote.execute(fak);
		System.out.println(result.getResult());
	}
}
