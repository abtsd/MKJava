package agent;

import java.io.Serializable;

public interface Agent extends Serializable {
	void execute();
}