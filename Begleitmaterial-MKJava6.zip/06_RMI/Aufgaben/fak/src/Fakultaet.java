import agent.Agent;

import java.math.BigInteger;

public class Fakultaet implements Agent {
	private final int n;
	private BigInteger fak;

	public Fakultaet(int n) {
		this.n = n;
	}

	public void execute() {
		fak = BigInteger.ONE;
		for (var i = 1; i <= n; i++) {
			fak = fak.multiply(BigInteger.valueOf(i));
		}
	}

	public String getResult() {
		return fak.toString();
	}
}