rmiregistry -J-Djava.class.path=out/production/Aufgaben
java -cp out/production/Aufgaben time.DaytimeServer
java -cp out/production/Aufgaben time.DaytimeClient localhost

java -cp out/production/Aufgaben chat.server.ChatServer
# Zur Ausgabe von Sonderzeichen bei Windows: chcp 1252
java -cp out/production/Aufgaben chat.client.ChatClient localhost Hugo
java -cp out/production/Aufgaben chat.client.ChatClient localhost Emil

jar --create --file services.jar -C ../rmi/out/production/rmi intro3/Add.class
jar --update --file services.jar -C ../rmi/out/production/rmi intro3/AddServer.class
jar --update --file services.jar -C ../rmi/out/production/rmi echo/Echo.class
jar --update --file services.jar -C ../rmi/out/production/rmi echo/EchoImplV1.class
java -cp out/production/Aufgaben;services.jar multi.MultiServer
java -cp ../rmi/out/production/rmi intro3.AddClient
java -cp ../rmi/out/production/rmi echo.EchoClient localhost
java -cp out/production/Aufgaben multi.MultiServerManagerClient localhost reconfigure
java -cp out/production/Aufgaben multi.MultiServerManagerClient localhost shutdown

java -cp out/production/Aufgaben mail.server.MailServer
# Zur Ausgabe von Sonderzeichen bei Windows: chcp 1252
java -cp out/production/Aufgaben mail.client.MailClient localhost Hugo aaa
java -cp out/production/Aufgaben mail.client.MailClient localhost Emil bbb
