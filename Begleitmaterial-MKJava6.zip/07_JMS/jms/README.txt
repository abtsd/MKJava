java -cp out/production/jms;../../libs/activemq/* p2p.Producer localhost
java -cp out/production/jms;../../libs/activemq/* p2p.Consumer1 localhost
java -cp out/production/jms;../../libs/activemq/* p2p.Consumer2 localhost
java -cp out/production/jms;../../libs/activemq/* p2p.Consumer3 localhost
java -cp out/production/jms;../../libs/activemq/* p2p.QueueInfo localhost

java -cp out/production/jms;../../libs/activemq/* reqresp.Responder localhost
# Zur Ausgabe von Sonderzeichen bei Windows: chcp 1252
java -cp out/production/jms;../../libs/activemq/* reqresp.Requestor localhost

java -cp out/production/jms;../../libs/activemq/* topic.nondurable.Publisher localhost
java -cp out/production/jms;../../libs/activemq/* topic.nondurable.Subscriber localhost

java -cp out/production/jms;../../libs/activemq/* topic.durable.Publisher localhost
java -cp out/production/jms;../../libs/activemq/* topic.durable.DurableSubscriber localhost 0001
java -cp out/production/jms;../../libs/activemq/* topic.durable.Unsubscribe localhost 0001

java -cp out/production/jms;../../libs/activemq/* filter.Publisher localhost
java -cp out/production/jms;../../libs/activemq/* filter.Subscriber localhost
java -cp out/production/jms;../../libs/activemq/* filter.Subscriber localhost "Priority = 'normal' OR Priority = 'high'"
java -cp out/production/jms;../../libs/activemq/* filter.Subscriber localhost "Priority = 'high'"

java -cp out/production/jms;../../libs/activemq/* transaction.Producer localhost false
java -cp out/production/jms;../../libs/activemq/* transaction.Consumer localhost true
