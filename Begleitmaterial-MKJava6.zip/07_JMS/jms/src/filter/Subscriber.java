package filter;

import utils.Utils;

import javax.jms.*;
import javax.naming.NamingException;

public class Subscriber {
    public static void main(String[] args) {
        var host = args[0];
        var messageSelector = "";
        if (args.length == 2)
            messageSelector = args[1];

        Connection connection = null;
        try {
            var ctx = Utils.getContext(host);
            var factory = (ConnectionFactory) ctx.lookup("ConnectionFactory");
            var topic = (Destination) ctx.lookup("dynamicTopics/topic3");

            connection = factory.createConnection();
            var session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            var messageConsumer = session.createConsumer(topic, messageSelector, false);
            messageConsumer.setMessageListener(Subscriber::handleMessage);
            connection.start();

            Thread.sleep(30000);
        } catch (NamingException | JMSException | InterruptedException e) {
            System.err.println(e.getMessage());
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (JMSException e) {
                    System.err.println(e.getMessage());
                }
            }
        }
    }

    private static void handleMessage(Message message) {
        try {
            if (message instanceof TextMessage) {
                var textMessage = (TextMessage) message;
                System.out.print(textMessage.getText());
                System.out.println(": " + textMessage.getStringProperty("Priority"));
            }
        } catch (JMSException e) {
            System.err.println(e);
        }
    }
}
