package filter;

import utils.Utils;

import javax.jms.*;
import javax.naming.NamingException;

public class Publisher {
	public static void main(String[] args) {
		var host = args[0];

		Connection connection = null;
		try {
			var ctx = Utils.getContext(host);
			var factory = (ConnectionFactory) ctx.lookup("ConnectionFactory");
			var topic = (Destination) ctx.lookup("dynamicTopics/topic3");

			connection = factory.createConnection();
			var session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			var messageProducer = session.createProducer(topic);

			for (int i = 0; i < 60; i++) {
				var message = session.createTextMessage();
				message.setText("Nachricht " + i);

				if (Math.random() < 0.25) {
					message.setStringProperty("Priority", "low");
				} else if (Math.random() < 0.75) {
					message.setStringProperty("Priority", "normal");
				} else {
					message.setStringProperty("Priority", "high");
				}

				messageProducer.send(message);
				System.out.println(message.getText() + ": " + message.getStringProperty("Priority"));
				Thread.sleep(1000);
			}
		} catch (NamingException | JMSException | InterruptedException e) {
			System.err.println(e.getMessage());
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (JMSException e) {
					System.err.println(e.getMessage());
				}
			}
		}
	}
}
