package topic.nondurable;

import utils.Utils;

import javax.jms.*;
import javax.naming.NamingException;

public class Subscriber {
	public static void main(String[] args) {
		var host = args[0];

		Connection connection = null;
		try {
			var ctx = Utils.getContext(host);
			var factory = (ConnectionFactory) ctx.lookup("ConnectionFactory");
			var topic = (Destination) ctx.lookup("dynamicTopics/topic1");

			connection = factory.createConnection();
			var session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			var messageConsumer = session.createConsumer(topic);
			messageConsumer.setMessageListener(Subscriber::handleMessage);
			connection.start();

			Thread.sleep(60000);
		} catch (NamingException | JMSException | InterruptedException e) {
			System.err.println(e.getMessage());
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (JMSException e) {
					System.err.println(e.getMessage());
				}
			}
		}
	}

	private static void handleMessage(Message message) {
		try {
			if (message instanceof MapMessage) {
				MapMessage mapMessage = (MapMessage) message;
				System.out.println(mapMessage.getString("Time"));
				System.out.println(mapMessage.getString("Message"));
				System.out.println();
			}
		} catch (JMSException e) {
			System.err.println(e);
		}
	}
}
