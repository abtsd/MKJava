package topic.durable;

import utils.Utils;

import javax.jms.*;
import javax.naming.NamingException;
import java.time.LocalTime;

public class Publisher {
	public static void main(String[] args) {
		var host = args[0];

		Connection connection = null;
		try {
			var ctx = Utils.getContext(host);
			var factory = (ConnectionFactory) ctx.lookup("ConnectionFactory");
			var topic = (Destination) ctx.lookup("dynamicTopics/topic2");

			connection = factory.createConnection();
			var session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			var messageProducer = session.createProducer(topic);

			for (int i = 0; i < 24; i++) {
				System.out.println(i);
				var message = session.createMapMessage();
				message.setString("Time", LocalTime.now().toString());
				message.setString("Message", "Message " + i);
				messageProducer.send(message);
				Thread.sleep(5000);
			}
		} catch (NamingException | JMSException | InterruptedException e) {
			System.err.println(e.getMessage());
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (JMSException e) {
					System.err.println(e.getMessage());
				}
			}
		}
	}
}
