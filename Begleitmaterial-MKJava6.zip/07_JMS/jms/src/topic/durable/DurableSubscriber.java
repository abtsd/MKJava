package topic.durable;

import utils.Utils;

import javax.jms.*;
import javax.naming.NamingException;

public class DurableSubscriber {
	public static void main(String[] args) {
		var host = args[0];
		var clientID = args[1];
		var subscriptionName = "test";

		Connection connection = null;
		try {
			var ctx = Utils.getContext(host);
			var factory = (ConnectionFactory) ctx.lookup("ConnectionFactory");
			var topic = (Destination) ctx.lookup("dynamicTopics/topic2");

			connection = factory.createConnection();
			connection.setClientID(clientID);
			var session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			var messageConsumer = session.createDurableSubscriber((Topic) topic, subscriptionName);
			messageConsumer.setMessageListener(DurableSubscriber::handleMessage);
			connection.start();
			Thread.sleep(20000);
		} catch (NamingException | JMSException | InterruptedException e) {
			System.err.println(e.getMessage());
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (JMSException e) {
					System.err.println(e.getMessage());
				}
			}
		}
	}

	private static void handleMessage(Message message) {
		try {
			if (message instanceof MapMessage) {
				var mapMessage = (MapMessage) message;
				System.out.println(mapMessage.getString("Time"));
				System.out.println(mapMessage.getString("Message"));
				System.out.println();
			}
		} catch (JMSException e) {
			System.err.println(e.getMessage());
		}
	}
}
