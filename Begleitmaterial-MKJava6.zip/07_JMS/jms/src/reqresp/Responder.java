package reqresp;

import utils.Utils;

import javax.jms.*;
import javax.naming.NamingException;
import java.io.IOException;

public class Responder {
    public static void main(String[] args) {
        var host = args[0];

        Connection connection = null;
        try {
            var ctx = Utils.getContext(host);
            var factory = (ConnectionFactory) ctx.lookup("ConnectionFactory");
            var queue = (Destination) ctx.lookup("dynamicQueues/queue2");

            connection = factory.createConnection();
            var session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            var messageConsumer = session.createConsumer(queue);
            connection.start();

            var t = new Thread(() -> {
                System.out.println("Responder gestartet ...");

                try {
                    while (true) {
                        var request = (TextMessage) messageConsumer.receive();
                        if (request == null)
                            break;

                        var text = request.getText();
                        var tempQueue = request.getJMSReplyTo();
                        var response = session.createTextMessage();
                        response.setText("Anwort: " + text);
                        var producer = session.createProducer(tempQueue);
                        producer.send(response);
                        producer.close();
                    }
                } catch (JMSException e) {
                    System.err.println(e.getMessage());
                }
            });

            t.start();

            System.out.println("Stoppen mit ENTER");
            System.in.read();
            messageConsumer.close();
        } catch (NamingException | JMSException | IOException e) {
            System.err.println(e.getMessage());
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (JMSException e) {
                    System.err.println(e.getMessage());
                }
            }
        }
    }
}
