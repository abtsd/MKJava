package reqresp;

import utils.Utils;

import javax.jms.*;
import javax.naming.NamingException;
import java.util.Scanner;

public class Requestor {
	public static void main(String[] args) {
		var host = args[0];

		Connection connection = null;
		try {
			var ctx = Utils.getContext(host);
			var factory = (ConnectionFactory) ctx.lookup("ConnectionFactory");
			var queue = (Destination) ctx.lookup("dynamicQueues/queue2");

			connection = factory.createConnection();
			var session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			var tempQueue = session.createTemporaryQueue();
			var messageProducer = session.createProducer(queue);
			var messageConsumer = session.createConsumer(tempQueue);
			connection.start();

			var scanner = new Scanner(System.in);
			while (true) {
				System.out.print("> ");
				var text = scanner.nextLine();
				if (text.equals("q"))
					break;

				var request = session.createTextMessage();
				request.setText(text);
				request.setJMSReplyTo(tempQueue);
				messageProducer.send(request);

				var response = (TextMessage) messageConsumer.receive();
				System.out.println(response.getText());
			}
		} catch (NamingException | JMSException e) {
			System.err.println(e.getMessage());
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (JMSException e) {
					System.err.println(e.getMessage());
				}
			}
		}
	}
}
