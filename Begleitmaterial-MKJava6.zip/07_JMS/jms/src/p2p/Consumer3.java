package p2p;

import utils.Utils;

import javax.jms.*;
import javax.naming.NamingException;

public class Consumer3 {
    public static void main(String[] args) {
        var host = args[0];

        Connection connection = null;
        try {
            var ctx = Utils.getContext(host);
            var factory = (ConnectionFactory) ctx.lookup("ConnectionFactory");
            var queue = (Destination) ctx.lookup("dynamicQueues/queue1");

            connection = factory.createConnection();
            var session = connection.createSession(false, Session.CLIENT_ACKNOWLEDGE);
            var messageConsumer = session.createConsumer(queue);
            connection.start();

            Message message;
            int count = 0;
            while ((message = messageConsumer.receive(30000)) != null) {
                try {
                    if (message instanceof TextMessage) {
                        count++;

                        var textMessage = (TextMessage) message;
                        System.out.println("\nNachricht: " + textMessage.getText());
                        System.out.println("Status: " + message.getStringProperty("Status"));
                        System.out.println("Redelivered: " + textMessage.getJMSRedelivered());

                        System.out.println("Nachricht wird verarbeitet");
                        try {
                            Thread.sleep(3000);
                        } catch (InterruptedException ignored) {
                        }

                        if (count == 1)
                            throw new RuntimeException("Abbruch!");

                        System.out.println("Nachricht wurde erfolgreich verarbeitet");
                        message.acknowledge();
                    }
                } catch (RuntimeException e) {
                    System.err.println(e.getMessage());
                    try {
                        session.recover();
                    } catch (JMSException e1) {
                        System.err.println(e.getMessage());
                    }
                }
            }
        } catch (NamingException | JMSException e) {
            System.err.println(e);
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (JMSException e) {
                    System.err.println(e.getMessage());
                }
            }
        }
    }
}
