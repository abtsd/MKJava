package p2p;

import utils.Utils;

import javax.jms.*;
import javax.naming.NamingException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class QueueInfo {
	public static void main(String[] args) {
		var host = args[0];

		Connection connection = null;
		try {
			var ctx = Utils.getContext(host);
			var factory = (ConnectionFactory) ctx.lookup("ConnectionFactory");
			var queue = (Destination) ctx.lookup("dynamicQueues/queue1");

			connection = factory.createConnection();
			connection.start();
			var session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			var browser = session.createBrowser((Queue) queue);

			var e = browser.getEnumeration();
			SimpleDateFormat f = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
			int cnt = 0;

			while (e.hasMoreElements()) {
				cnt++;

				var message = (Message) e.nextElement();

				System.out.print(cnt + ".");
				System.out.println("\tDestination: " + message.getJMSDestination());
				System.out.println("\tMessageID: " + message.getJMSMessageID());
				System.out.println("\tTimestamp: " + f.format(new Date(message.getJMSTimestamp())));
				System.out.println("\tPriority: " + message.getJMSPriority());

				var expiration = message.getJMSExpiration();

				if (expiration == 0) {
					System.out.println("\tExpiration: 0");
				} else {
					System.out.println("\tExpiration: " + f.format(new Date(expiration)));
				}

				System.out.println("\tProperties:");

				var names = message.getPropertyNames();

				while (names.hasMoreElements()) {
					var name = (String) names.nextElement();
					System.out.println("\t\t" + name + " = " + message.getStringProperty(name));
				}

				System.out.println();
			}
		} catch (NamingException | JMSException e) {
			System.err.println(e.getMessage());
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (JMSException e) {
					System.err.println(e.getMessage());
				}
			}
		}
	}
}
