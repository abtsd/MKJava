package p2p;

import utils.Utils;

import javax.jms.*;
import javax.naming.NamingException;

public class Consumer1 {
	public static void main(String[] args) {
		var host = args[0];

		Connection connection = null;
		try {
			var ctx = Utils.getContext(host);
			var factory = (ConnectionFactory) ctx.lookup("ConnectionFactory");
			var queue = (Destination) ctx.lookup("dynamicQueues/queue1");

			connection = factory.createConnection();
			var session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			var messageConsumer = session.createConsumer(queue);
			connection.start();

			Message message;
			while ((message = messageConsumer.receive(30000)) != null) {
				if (message instanceof TextMessage) {
					var textMessage = (TextMessage) message;
					System.out.println("Nachricht: " + textMessage.getText());
					System.out.println("Status: " + message.getStringProperty("Status"));
				}
			}
		} catch (NamingException | JMSException e) {
			System.err.println(e.getMessage());
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (JMSException e) {
					System.err.println(e.getMessage());
				}
			}
		}
	}
}
