package transaction;

import utils.Utils;

import javax.jms.*;
import javax.naming.NamingException;

public class Consumer {
	public static void main(String[] args) {
		var host = args[0];
		var exception = Boolean.parseBoolean(args[1]);

		Connection connection = null;
		try {
			var ctx = Utils.getContext(host);
			var factory = (ConnectionFactory) ctx.lookup("ConnectionFactory");
			var queue = (Destination) ctx.lookup("dynamicQueues/queue3");

			connection = factory.createConnection();
			var session = connection.createSession(true, Session.AUTO_ACKNOWLEDGE);
			var messageConsumer = session.createConsumer(queue);
			connection.start();

			while (true) {
				try {
					var message = messageConsumer.receive(30000);
					if (message == null)
						break;

					if (message instanceof TextMessage) {
						var textMessage = (TextMessage) message;
						System.out.println(textMessage.getText() +
								" (Redelivered: " + textMessage.getJMSRedelivered() + ")");
					} else {
						session.commit();
						System.out.println("Committed");
						continue;
					}

					if (exception) {
						exception = false;
						throw new RuntimeException("Simulierter Fehler");
					}
				} catch (RuntimeException e) {
					System.err.println(e.getMessage());
					try {
						session.rollback();
						System.out.println("Rolled back");
					} catch (JMSException e1) {
						System.err.println(e1.getMessage());
					}
				}
			}
		} catch (NamingException | JMSException e) {
			System.err.println(e.getMessage());
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (JMSException e) {
					System.err.println(e.getMessage());
				}
			}
		}
	}
}
