package transaction;

import utils.Utils;

import javax.jms.*;
import javax.naming.NamingException;
import java.time.LocalTime;

public class Producer {
	public static void main(String[] args) {
		var host = args[0];
		var exception = Boolean.parseBoolean(args[1]);

		Connection connection = null;
		Session session = null;
		try {
			var ctx = Utils.getContext(host);
			var factory = (ConnectionFactory) ctx.lookup("ConnectionFactory");
			var queue = (Destination) ctx.lookup("dynamicQueues/queue3");

			connection = factory.createConnection();
			session = connection.createSession(true, Session.AUTO_ACKNOWLEDGE);
			var messageProducer = session.createProducer(queue);

			for (int i = 0; i < 4; i++) {
				var message = session.createTextMessage();
				message.setText("Nachricht " + i + " " + LocalTime.now().toString());
				messageProducer.send(message);
			}

			// Leere Nachricht signalisiert den Abschluss
			messageProducer.send(session.createMessage());

			if (exception) {
				throw new RuntimeException("Simulierter Fehler");
			}

			session.commit();
			System.out.println("Committed");
		} catch (RuntimeException e) {
			System.err.println(e.getMessage());
			try {
				if (session != null) {
					session.rollback();
					System.out.println("Rolled back");
				}
			} catch (JMSException e1) {
				System.err.println(e1.getMessage());
			}
		} catch (NamingException | JMSException e) {
			System.err.println(e.getMessage());
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (JMSException e) {
					System.err.println(e.getMessage());
				}
			}
		}
	}
}
