package time;

import utils.Utils;

import javax.jms.*;
import javax.naming.NamingException;
import java.io.IOException;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Timer;
import java.util.TimerTask;

public class Publisher {
	public static void main(String[] args) {
		var host = args[0];

		Connection connection = null;
		try {
			var ctx = Utils.getContext(host);
			var factory = (ConnectionFactory) ctx.lookup("ConnectionFactory");
			var topic = (Destination) ctx.lookup("dynamicTopics/Aufgaben_topic1");

			connection = factory.createConnection();
			var session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			var messageProducer = session.createProducer(topic);

			var task = new TimerTask() {
				@Override
				public void run() {
					try {
						var message = session.createTextMessage();
						var time = LocalTime.now();
						message.setText(time.format(DateTimeFormatter.ofPattern("HH:mm")));
						messageProducer.send(message);
					} catch (JMSException e) {
						System.err.println(e.getMessage());
					}
				}
			};

			var timer = new Timer(true);
			timer.schedule(task, 0, 60000);

			System.out.println("Stoppen mit ENTER");
			System.in.read();
		} catch (NamingException | JMSException | IOException e) {
			System.err.println(e.getMessage());
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (JMSException e) {
					System.err.println(e.getMessage());
				}
			}
		}
	}
}
