package time;

import utils.Utils;

import javax.jms.*;
import javax.naming.NamingException;
import java.io.IOException;

public class Subscriber {
	public static void main(String[] args) {
		var host = args[0];

		Connection connection = null;
		try {
			var ctx = Utils.getContext(host);
			var factory = (ConnectionFactory) ctx.lookup("ConnectionFactory");
			var topic = (Destination) ctx.lookup("dynamicTopics/Aufgaben_topic1");

			connection = factory.createConnection();
			var session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			var messageConsumer = session.createConsumer(topic);
			messageConsumer.setMessageListener(Subscriber::handleMessage);
			connection.start();

			System.out.println("Stoppen mit ENTER");
			System.in.read();
		} catch (NamingException | JMSException | IOException e) {
			System.err.println(e.getMessage());
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (JMSException e) {
					System.err.println(e.getMessage());
				}
			}
		}
	}

	private static void handleMessage(Message message) {
		try {
			if (message instanceof TextMessage) {
				var textMessage = (TextMessage) message;
				System.out.println(textMessage.getText());
			}
		} catch (JMSException e) {
			System.err.println(e.getMessage());
		}
	}
}
