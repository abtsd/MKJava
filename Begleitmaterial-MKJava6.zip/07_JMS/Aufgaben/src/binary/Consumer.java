package binary;

import utils.Utils;

import javax.jms.*;
import javax.naming.NamingException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Consumer {
	public static void main(String[] args) {
		var host = args[0];

		Connection connection = null;
		try {
			var ctx = Utils.getContext(host);
			var factory = (ConnectionFactory) ctx.lookup("ConnectionFactory");
			var queue = (Destination) ctx.lookup("dynamicQueues/Aufgaben_queue2");

			connection = factory.createConnection();
			var session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			var messageConsumer = session.createConsumer(queue);
			connection.start();

			var message = messageConsumer.receive();
			if (message instanceof BytesMessage) {
				var bytesMessage = (BytesMessage) message;
				var filename = "out_" + message.getStringProperty("filename");
				try (var out = new FileOutputStream(filename)) {
					var buffer = new byte[1024];
					var c = 0;
					while ((c = bytesMessage.readBytes(buffer)) != -1) {
						out.write(buffer, 0, c);
					}
					out.flush();
				}
			}
		} catch (NamingException | JMSException | IOException e) {
			System.err.println(e.getMessage());
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (JMSException e) {
					System.err.println(e.getMessage());
				}
			}
		}
	}
}
