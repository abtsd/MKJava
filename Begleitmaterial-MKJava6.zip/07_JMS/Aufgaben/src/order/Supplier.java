package order;

import jakarta.json.bind.JsonbBuilder;
import utils.Utils;

import javax.jms.*;
import javax.naming.NamingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Supplier {
	public static void main(String[] args) {
		var host = args[0];

		Connection connection = null;
		try {
			var ctx = Utils.getContext(host);
			var factory = (ConnectionFactory) ctx.lookup("ConnectionFactory");
			var queue = (Destination) ctx.lookup("dynamicQueues/Aufgaben_queue3");

			connection = factory.createConnection();
			var session = connection.createSession(true, Session.AUTO_ACKNOWLEDGE);
			var messageConsumer = session.createConsumer(queue);
			connection.start();
			System.out.println("Supplier gestartet ...");

			while (true) {
				try {
					var inMessage = (TextMessage) messageConsumer.receive(30000);
					if (inMessage == null)
						break;
					var task = new MyTask(session, inMessage);
					task.start();
				} catch (JMSException e) {
					System.err.println(e.getMessage());
				}
			}
		} catch (NamingException | JMSException e) {
			System.err.println(e.getMessage());
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (JMSException e) {
					System.err.println(e.getMessage());
				}
			}
		}
	}

	private static class MyTask extends Thread {
		private final TextMessage inMessage;
		private final Session session;

		public MyTask(Session session, TextMessage inMessage) {
			this.session = session;
			this.inMessage = inMessage;
		}

		@Override
		public void run() {
			try {
				var orders = deserialize(inMessage.getText());
				var messageProducer = session.createProducer(inMessage.getJMSReplyTo());
				var outMessage = session.createTextMessage();

				var result = new ArrayList<String>();
				for (var order : orders) {
					var item = order.getItem();
					var quantity = order.getQuantity();
					quantity = Math.min(quantity, new Random().nextInt(4) * 5);
					System.out.println(inMessage.getJMSMessageID() + " " + item + " " + quantity);
					result.add(item + " " + quantity);
					try {
						Thread.sleep(3000);
					} catch (InterruptedException ignored) {
					}
				}

				outMessage.setText(serialize(result));
				messageProducer.send(outMessage);
				session.commit();
			} catch (JMSException e) {
				System.err.println(e.getMessage());
				try {
					session.rollback();
				} catch (JMSException e1) {
					System.err.println(e1.getMessage());
				}
			}
		}
	}

	private static String serialize(ArrayList<String> list) {
		var jsonb = JsonbBuilder.create();
		return jsonb.toJson(list);
	}

	private static List<Order> deserialize(String data) {
		var jsonb = JsonbBuilder.create();
		var type = new ArrayList<Order>() {}.getClass().getGenericSuperclass();
		return jsonb.fromJson(data, type);
	}
}
