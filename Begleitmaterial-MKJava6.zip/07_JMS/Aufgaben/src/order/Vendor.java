package order;

import jakarta.json.bind.JsonbBuilder;
import utils.Utils;

import javax.jms.*;
import javax.naming.NamingException;
import java.util.ArrayList;
import java.util.List;

public class Vendor {
	public static void main(String[] args) {
		var host = args[0];

		Connection connection = null;
		try {
			var ctx = Utils.getContext(host);
			var factory = (QueueConnectionFactory) ctx.lookup("ConnectionFactory");
			var orderQueue = (Destination) ctx.lookup("dynamicQueues/Aufgaben_queue3");

			connection = factory.createConnection();
			var session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			var replyQueue = session.createTemporaryQueue();
			var messageProducer = session.createProducer(orderQueue);
			var messageConsumer = session.createConsumer(replyQueue);
			connection.start();

			var orders = new ArrayList<Order>();
			orders.add(new Order("4711", 5));
			orders.add(new Order("4712", 8));
			orders.add(new Order("4713", 22));

			var outMessage = session.createTextMessage();
			outMessage.setText(serialize(orders));
			outMessage.setJMSReplyTo(replyQueue);
			messageProducer.send(outMessage);

			System.out.println("Bestellt:");
			for (var order : orders) {
				System.out.println(order);
			}

			var inMessage = (TextMessage) messageConsumer.receive();
			System.out.println("\nGeliefert:");
			var result = deserialize(inMessage.getText());
			for (var s : result) {
				System.out.println(s);
			}
		} catch (NamingException | JMSException e) {
			System.err.println(e.getMessage());
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (JMSException e) {
					System.err.println(e.getMessage());
				}
			}
		}
	}

	private static String serialize(ArrayList<Order> orders) {
		var jsonb = JsonbBuilder.create();
		return jsonb.toJson(orders);
	}

	private static List<String> deserialize(String data) {
		var jsonb = JsonbBuilder.create();
		var type = new ArrayList<String>() {}.getClass().getGenericSuperclass();
		return jsonb.fromJson(data, type);
	}
}
