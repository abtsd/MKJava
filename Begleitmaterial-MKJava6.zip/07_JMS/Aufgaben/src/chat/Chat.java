package chat;

import utils.Utils;

import javax.jms.*;
import javax.naming.NamingException;
import java.util.Scanner;

public class Chat implements MessageListener {
	private final String name;
	private final Connection connection;
	private final Session session;
	private final MessageProducer messageProducer;

	public Chat(String host, String name) throws NamingException, JMSException {
		this.name = name;

		var ctx = Utils.getContext(host);
		var factory = (ConnectionFactory) ctx.lookup("ConnectionFactory");
		var topic = (Destination) ctx.lookup("dynamicTopics/Aufgaben_topic2");
		connection = factory.createConnection();

		connection.start();
		session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
		messageProducer = session.createProducer(topic);
		var messageConsumer = session.createConsumer(topic, "", true);
		messageConsumer.setMessageListener(this);

		sendMessage("angemeldet");
	}

	public void onMessage(Message message) {
		try {
			var textMessage = (TextMessage) message;
			System.out.println(textMessage.getText());
		} catch (JMSException e) {
			System.err.println(e.getMessage());
		}
	}

	public void sendMessage(String text) throws JMSException {
		var message = session.createTextMessage();
		message.setText(name + ": " + text);
		messageProducer.send(message);
	}

	public void close() {
		try {
			sendMessage("abgemeldet");
			if (connection != null)
				connection.close();
		} catch (JMSException e) {
			System.err.println(e.getMessage());
		}
	}

	public static void main(String[] args) throws Exception {
		var host = args[0];
		var name = args[1];
		var chat = new Chat(host, name);

		var scanner = new Scanner(System.in);
		System.out.println("Chat gestartet, User = " + name + ", q = Quit");
		while (true) {
			var line = scanner.nextLine();
			if (line.equals("q")) {
				break;
			} else {
				chat.sendMessage(line);
			}
		}
		scanner.close();
		chat.close();
	}
}
