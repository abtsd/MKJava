package priority;

import utils.Utils;

import javax.jms.*;
import javax.naming.NamingException;

public class Consumer {
	public static void main(String[] args) {
		var host = args[0];

		Connection connection = null;
		try {
			var ctx = Utils.getContext(host);
			var factory = (ConnectionFactory) ctx.lookup("ConnectionFactory");
			var queue = (Destination) ctx.lookup("dynamicQueues/Aufgaben_queue1");

			connection = factory.createConnection();
			var session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			var messageConsumer = session.createConsumer(queue);
			connection.start();

			Message message;
			while ((message = messageConsumer.receive(30000)) != null) {
				if (message instanceof TextMessage) {
					var textMessage = (TextMessage) message;
					System.out.println(textMessage.getText() + "(" + textMessage.getJMSPriority() + ")");
				}
			}
		} catch (NamingException | JMSException e) {
			System.err.println(e.getMessage());
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (JMSException e) {
					System.err.println(e.getMessage());
				}
			}
		}
	}
}
