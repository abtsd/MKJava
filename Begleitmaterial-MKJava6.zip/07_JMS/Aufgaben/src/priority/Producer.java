package priority;

import utils.Utils;

import javax.jms.*;
import javax.naming.NamingException;

public class Producer {
	public static void main(String[] args) {
		var host = args[0];

		Connection connection = null;
		try {
			var ctx = Utils.getContext(host);
			var factory = (ConnectionFactory) ctx.lookup("ConnectionFactory");
			var queue = (Destination) ctx.lookup("dynamicQueues/Aufgaben_queue1");

			connection = factory.createConnection();
			var session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			var messageProducer = session.createProducer(queue);

			var message = session.createTextMessage();
			message.setText("Nachricht 1");
			messageProducer.send(message);

			message.setText("Nachricht 2");
			messageProducer.send(message);

			message.setText("Nachricht 3");
			messageProducer.setPriority(9);
			messageProducer.send(message);
		} catch (NamingException | JMSException e) {
			System.err.println(e.getMessage());
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (JMSException e) {
					System.err.println(e.getMessage());
				}
			}
		}
	}
}
