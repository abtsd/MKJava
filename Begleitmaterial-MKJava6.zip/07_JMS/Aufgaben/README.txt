java -cp out/production/Aufgaben;../../libs/activemq/* time.Publisher localhost
java -cp out/production/Aufgaben;../../libs/activemq/* time.Subscriber localhost

java -cp out/production/Aufgaben;../../libs/activemq/* priority.Producer localhost
java -cp out/production/Aufgaben;../../libs/activemq/* priority.Consumer localhost

# Zur Ausgabe von Sonderzeichen bei Windows: chcp 1252
java -cp out/production/Aufgaben;../../libs/activemq/* chat.Chat localhost Hugo
java -cp out/production/Aufgaben;../../libs/activemq/* chat.Chat localhost Emil

java -cp out/production/Aufgaben;../../libs/activemq/* binary.Producer localhost
java -cp out/production/Aufgaben;../../libs/activemq/* binary.Consumer localhost

java -cp out/production/Aufgaben;../../libs/activemq/*;../../libs/json/* order.Vendor localhost
java -cp out/production/Aufgaben;../../libs/activemq/*;../../libs/json/* order.Supplier localhost
