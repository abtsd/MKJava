java --add-opens=java.base/java.lang=ALL-UNNAMED --add-opens=java.base/java.io=ALL-UNNAMED --add-opens=java.rmi/sun.rmi.transport=ALL-UNNAMED -cp ../../webserver/webserver.jar;../../libs/tomcat/*;out/production/partial WebServer "" . 8080 false false
java -cp out/production/partial client.MyClient localhost 8080

# keystore.jks und certs.jks bereitstellen
copy /Y ..\..\certificate\*.jks .

java --add-opens=java.base/java.lang=ALL-UNNAMED --add-opens=java.base/java.io=ALL-UNNAMED --add-opens=java.rmi/sun.rmi.transport=ALL-UNNAMED -cp ../../webserver/webserver.jar;../../libs/tomcat/*;out/production/wss WebServer "" . 8443 false true
java -cp out/production/wss client.EchoClient localhost 8443
java -Djavax.net.debug=all -cp out/production/wss client.EchoClient localhost 8443
java -cp out/production/wss client.EchoClientInsecure localhost 8443
java -Djavax.net.debug=all -cp out/production/wss client.EchoClientInsecure localhost 8443

java --add-opens java.base/java.lang=ALL-UNNAMED --add-opens java.rmi/sun.rmi.transport=ALL-UNNAMED --add-opens java.base/java.io=ALL-UNNAMED -cp out/production/push;../../libs/tomcat/* server.Server 8080
# Zur Ausgabe von Sonderzeichen bei Windows: chcp 1252
java -cp out/production/push;../../libs/json/* client.Subscriber localhost 8080
Browser: http://localhost:8080/demo
java -cp out/production/push;../../libs/json/* client.Publisher localhost 8080 "Das ist ein Test."
