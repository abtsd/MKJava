package server;

import jakarta.websocket.*;
import jakarta.websocket.server.ServerEndpoint;

import java.io.IOException;

@ServerEndpoint("/echo")
public class Echo {
	@OnOpen
	public void onOpen(Session session) {
		System.out.println(session.getId() + ": onOpen");
	}

	@OnClose
	public void onClose(Session session) {
		System.out.println(session.getId() + ": onClose");
	}

	@OnError
	public void onError(Session session, Throwable error) {
		System.out.println(session.getId() + ": " + error.getMessage());
	}

	@OnMessage
	public void onMessage(Session session, String message) {
		try {
			session.getBasicRemote().sendText("[Server] " + message);
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}
	}
}
