package client;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ExecutionException;

public class EchoClientInsecure {
	public static void main(String[] args) throws KeyManagementException, NoSuchAlgorithmException {
		var host = args[0];
		var port = Integer.parseInt(args[1]);

		var url = "wss://" + host + ":" + port + "/echo";

		var listener = new WebSocket.Listener() {
			@Override
			public void onOpen(WebSocket webSocket) {
				System.out.println("onOpen");
			}

			@Override
			public CompletionStage<?> onText(WebSocket webSocket, CharSequence data, boolean last) {
				System.out.println(data);
				webSocket.request(1);
				return null;
			}

			@Override
			public CompletionStage<?> onClose(WebSocket webSocket, int statusCode, String reason) {
				System.out.println("onClose: " + statusCode + " " + reason);
				return null;
			}

			@Override
			public void onError(WebSocket webSocket, Throwable error) {
				System.out.println("onError: " + error.getMessage());
			}
		};

		// allow insecure SSL connections
		var client = HttpClient.newBuilder()
				.sslContext(getInsecureContext())
				.build();
		var future = client.newWebSocketBuilder().buildAsync(URI.create(url), listener);

		try {
			var ws = future.get();
			ws.request(1);

			for (var i = 0; i < 5; i++) {
				var message = i + ". " + Math.random();
				ws.sendText(message, true);
				System.out.println("[Client] " + message);
				Thread.sleep(5000);
			}

			ws.sendClose(WebSocket.NORMAL_CLOSURE, "Closed");
		} catch (InterruptedException | ExecutionException e) {
			System.err.println(e.getMessage());
		}
	}

	private static SSLContext getInsecureContext() throws NoSuchAlgorithmException, KeyManagementException {
		var trustAllCerts = new TrustManager[]{
				new X509TrustManager() {
					public X509Certificate[] getAcceptedIssuers() {
						return null;
					}

					public void checkClientTrusted(
							X509Certificate[] certs, String authType) {
					}

					public void checkServerTrusted(
							X509Certificate[] certs, String authType) {
					}
				}
		};

		var sslContext = SSLContext.getInstance("TLS");
		sslContext.init(null, trustAllCerts, null);
		return sslContext;
	}
}
