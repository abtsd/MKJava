package client;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ExecutionException;

public class EchoClient {
	public static void main(String[] args) {
		var host = args[0];
		var port = Integer.parseInt(args[1]);

		var url = "wss://" + host + ":" + port + "/echo";

		System.setProperty("javax.net.ssl.trustStore", "certs.jks");
		System.setProperty("javax.net.ssl.trustStorePassword", "secret");

		var listener = new WebSocket.Listener() {
			@Override
			public void onOpen(WebSocket webSocket) {
				System.out.println("onOpen");
			}

			@Override
			public CompletionStage<?> onText(WebSocket webSocket, CharSequence data, boolean last) {
				System.out.println(data);
				webSocket.request(1);
				return null;
			}

			@Override
			public CompletionStage<?> onClose(WebSocket webSocket, int statusCode, String reason) {
				System.out.println("onClose: " + statusCode + " " + reason);
				return null;
			}

			@Override
			public void onError(WebSocket webSocket, Throwable error) {
				System.out.println("onError: " + error.getMessage());
			}
		};

		var client = HttpClient.newHttpClient();
		var future = client.newWebSocketBuilder().buildAsync(URI.create(url), listener);

		try {
			var ws = future.get();
			ws.request(1);

			for (var i = 0; i < 5; i++) {
				var message = i + ". " + Math.random();
				ws.sendText(message, true);
				System.out.println("[Client] " + message);
				Thread.sleep(5000);
			}

			ws.sendClose(WebSocket.NORMAL_CLOSURE, "Closed");
		} catch (InterruptedException | ExecutionException e) {
			System.err.println(e.getMessage());
		}
	}
}
