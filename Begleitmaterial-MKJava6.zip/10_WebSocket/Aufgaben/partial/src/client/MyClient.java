package client;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.util.ArrayList;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;

public class MyClient {
    public static void main(String[] args) {
        var host = args[0];
        var port = Integer.parseInt(args[1]);

        var url = "ws://" + host + ":" + port + "/my-endpoint";

        var values = new ArrayList<Integer>();
        var latch = new CountDownLatch(1);

        var listener = new WebSocket.Listener() {
            @Override
            public void onOpen(WebSocket webSocket) {
            }

            @Override
            public CompletionStage<?> onText(WebSocket webSocket, CharSequence data, boolean last) {
                values.add(Integer.parseInt(data.toString()));
                if (last)
                    latch.countDown();
                else
                    webSocket.request(1);
                return null;
            }

            @Override
            public CompletionStage<?> onClose(WebSocket webSocket, int statusCode, String reason) {
                System.out.println("onClose: " + statusCode + " " + reason);
                latch.countDown();
                return null;
            }

            @Override
            public void onError(WebSocket webSocket, Throwable error) {
                System.out.println("onError: " + error.getMessage());
                latch.countDown();
            }
        };

        var client = HttpClient.newHttpClient();
        var future = client.newWebSocketBuilder().buildAsync(URI.create(url), listener);

        try {
            var ws = future.get();
            ws.request(1);
            latch.await();
            ws.sendClose(WebSocket.NORMAL_CLOSURE, "Closed");

            System.out.println(values);
            var sum = values.stream().reduce(0, Integer::sum);
            System.out.println((double) sum / values.size());
        } catch (InterruptedException | ExecutionException e) {
            System.err.println(e.getMessage());
        }
    }
}
