package server;

import jakarta.websocket.OnClose;
import jakarta.websocket.OnError;
import jakarta.websocket.OnOpen;
import jakarta.websocket.Session;
import jakarta.websocket.server.ServerEndpoint;

import java.io.IOException;
import java.util.concurrent.ThreadLocalRandom;

@ServerEndpoint("/my-endpoint")
public class MyEndpoint {
    @OnOpen
    public void onOpen(Session session) {
        System.out.println(session.getId() + ": onOpen");
        new Sender(session).start();
    }

    @OnClose
    public void onClose(Session session) {
        System.out.println(session.getId() + ": onClose");
    }

    @OnError
    public void onError(Session session, Throwable error) {
        System.out.println(session.getId() + ": " + error.getMessage());
    }

    private static class Sender extends Thread {
        private final Session session;

        public Sender(Session session) {
            this.session = session;
        }

        @Override
        public void run() {
            var count = ThreadLocalRandom.current().nextInt(10, 30);

            var last = false;
            for (var i = 1; i <= count; i++) {
                try {
                    var value = ThreadLocalRandom.current().nextInt(1000);
                    if (i == count)
                        last = true;
                    if (session.isOpen())
                        session.getBasicRemote().sendText(String.valueOf(value), last);
                    Thread.sleep(ThreadLocalRandom.current().nextInt(1000, 5000));
                } catch (InterruptedException | IOException e) {
                    System.err.println(e.getMessage());
                }
            }
        }
    }
}
