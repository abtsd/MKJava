package client;

import jakarta.json.bind.JsonbBuilder;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.LocalDateTime;

public class Publisher {
	public static void main(String[] args) throws Exception {
		var host = args[0];
		var port = Integer.parseInt(args[1]);
		var text = args[2];

		var url = "http://" + host + ":" + port + "/demo/push";

		var message = new Message();
		message.setTimestamp(LocalDateTime.now());
		message.setText(text);

		var client = HttpClient.newHttpClient();
		var jsonb = JsonbBuilder.create();
		var request = HttpRequest.newBuilder()
				.uri(URI.create(url))
				.header("Content-Type", "application/json")
				.POST(HttpRequest.BodyPublishers.ofString(jsonb.toJson(message)))
				.build();
		var response = client.send(request, HttpResponse.BodyHandlers.discarding());
		System.out.println("Status: " + response.statusCode());
	}
}
