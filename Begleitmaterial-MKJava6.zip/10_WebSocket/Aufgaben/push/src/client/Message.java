package client;

import java.time.LocalDateTime;

public class Message {
	private LocalDateTime timestamp;
	private String text;

	public Message() {
	}

	public LocalDateTime getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	@Override
	public String toString() {
		return "Message{" +
				"timestamp=" + timestamp +
				", text='" + text + '\'' +
				'}';
	}
}
