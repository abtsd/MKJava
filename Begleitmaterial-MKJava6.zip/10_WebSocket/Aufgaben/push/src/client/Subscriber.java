package client;

import jakarta.json.bind.JsonbBuilder;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ExecutionException;

public class Subscriber {
    public static void main(String[] args) {
        var host = args[0];
        var port = Integer.parseInt(args[1]);

        var url = "ws://" + host + ":" + port + "/demo/sub";
        var jsonb = JsonbBuilder.create();

        var listener = new WebSocket.Listener() {
            @Override
            public void onOpen(WebSocket webSocket) {
                System.out.println("Subscriber gestartet");
            }

            @Override
            public CompletionStage<?> onText(WebSocket webSocket, CharSequence data, boolean last) {
                System.out.println(jsonb.fromJson(data.toString(), Message.class));
                webSocket.request(1);
                return null;
            }

            @Override
            public CompletionStage<?> onClose(WebSocket webSocket, int statusCode, String reason) {
                System.out.println("onClose: " + statusCode + " " + reason);
                return null;
            }

            @Override
            public void onError(WebSocket webSocket, Throwable error) {
                System.out.println("onError: " + error.getMessage());
            }
        };

        var client = HttpClient.newHttpClient();
        var future = client.newWebSocketBuilder().buildAsync(URI.create(url), listener);

        try {
            var ws = future.get();
            ws.request(1);
            System.out.println("Stoppen mit ENTER");
            System.in.read();
            ws.sendClose(WebSocket.NORMAL_CLOSURE, "Closed");
        } catch (InterruptedException | IOException | ExecutionException e) {
            System.err.println(e);
        }
    }
}
