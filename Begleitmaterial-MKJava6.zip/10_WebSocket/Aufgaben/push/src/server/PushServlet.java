package server;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class PushServlet extends HttpServlet {
	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		try (var in = new BufferedReader(new InputStreamReader(req.getInputStream(), StandardCharsets.UTF_8))) {
			var line = in.readLine();
			Push.broadcast(line);
		}
	}
}
