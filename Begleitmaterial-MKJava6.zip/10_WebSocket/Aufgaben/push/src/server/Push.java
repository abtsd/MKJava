package server;

import jakarta.websocket.OnClose;
import jakarta.websocket.OnError;
import jakarta.websocket.OnOpen;
import jakarta.websocket.Session;
import jakarta.websocket.server.ServerEndpoint;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

@ServerEndpoint("/sub")
public class Push {
	private static final List<Session> connections = new CopyOnWriteArrayList<>();

	@OnOpen
	public void onOpen(Session session) {
		System.out.println(session.getId() + ": onOpen");
		connections.add(session);
		System.out.println("Anzahl Sessions: " + connections.size());
	}

	@OnClose
	public void onClose(Session session) {
		System.out.println(session.getId() + ": onClose");
		connections.remove(session);
		System.out.println("Anzahl Sessions: " + connections.size());
	}

	@OnError
	public void onError(Session session, Throwable error) {
		System.out.println(session.getId() + ": " + error.getMessage());
	}

	public static void broadcast(String message) {
		for (var session : connections) {
			try {
				session.getBasicRemote().sendText(message);
			} catch (IOException e) {
				System.err.println(e.getMessage());
			}
		}
	}
}
