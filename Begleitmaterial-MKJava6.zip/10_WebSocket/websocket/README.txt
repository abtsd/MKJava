java --add-opens java.base/java.lang=ALL-UNNAMED --add-opens java.rmi/sun.rmi.transport=ALL-UNNAMED --add-opens java.base/java.io=ALL-UNNAMED -cp out/production/websocket;../../libs/tomcat/*;../../libs/json/* ws.server.Server 8080 false
Browser: http://localhost:8080/ws/echo.html
java -cp out/production/websocket ws.client.EchoClient localhost 8080

java --add-opens java.base/java.lang=ALL-UNNAMED --add-opens java.rmi/sun.rmi.transport=ALL-UNNAMED --add-opens java.base/java.io=ALL-UNNAMED -cp out/production/websocket;../../libs/tomcat/*;../../libs/json/* ws.server.Server 8080 true
Browser: http://localhost:8080/ws/news.html
java -cp out/production/websocket ws.client.NewsClient localhost 8080

java --add-opens java.base/java.lang=ALL-UNNAMED --add-opens java.rmi/sun.rmi.transport=ALL-UNNAMED --add-opens java.base/java.io=ALL-UNNAMED -cp out/production/websocket;../../libs/tomcat/*;../../libs/json/* ws.server.Server 8080 false
Browser: http://localhost:8080/ws/chat.html
