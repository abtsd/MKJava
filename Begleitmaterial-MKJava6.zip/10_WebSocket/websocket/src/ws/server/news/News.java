package ws.server.news;

import jakarta.websocket.OnClose;
import jakarta.websocket.OnError;
import jakarta.websocket.OnOpen;
import jakarta.websocket.Session;
import jakarta.websocket.server.ServerEndpoint;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

@ServerEndpoint("/news")
public class News {
	private static final List<Session> connections = new CopyOnWriteArrayList<>();

	@OnOpen
	public void onOpen(Session session) {
		System.out.println(session.getId() + ": onOpen");
		connections.add(session);
	}

	@OnClose
	public void onClose(Session session) {
		System.out.println(session.getId() + ": onClose");
		connections.remove(session);
	}

	@OnError
	public void onError(Session session, Throwable error) {
		System.out.println(session.getId() + ": " + error.getMessage());
	}

	public static class NewsThread extends Thread {
		@Override
		public void run() {
			var counter = new AtomicInteger();
			System.out.println("NewsThread gestartet.");

			while (true) {
				var z = 5 + (int) (Math.random() * 6);
				try {
					Thread.sleep(1000L * z);
				} catch (InterruptedException e) {
					break;
				}
				broadcast("[" + LocalDateTime.now() + "] News " + counter.incrementAndGet());
			}
		}

		private void broadcast(String message) {
			for (var session : connections) {
				try {
					session.getBasicRemote().sendText(message);
				} catch (IOException e) {
					System.err.println(e.getMessage());
				}
			}
		}
	}
}
