package ws.server.chat;

import jakarta.json.bind.Jsonb;
import jakarta.json.bind.JsonbBuilder;
import jakarta.json.bind.JsonbException;
import jakarta.websocket.DecodeException;
import jakarta.websocket.Decoder;

public class MessageDecoder implements Decoder.Text<Message> {
    private static final Jsonb jsonb = JsonbBuilder.create();

    @Override
    public Message decode(String s) throws DecodeException {
        try {
            return jsonb.fromJson(s, Message.class);
        } catch (JsonbException e) {
            throw new DecodeException(s, e.getMessage());
        }
    }

    @Override
    public boolean willDecode(String s) {
        return s != null;
    }
}
