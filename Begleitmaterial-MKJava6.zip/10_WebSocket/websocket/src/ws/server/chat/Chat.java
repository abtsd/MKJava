package ws.server.chat;

import jakarta.websocket.*;
import jakarta.websocket.server.PathParam;
import jakarta.websocket.server.ServerEndpoint;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

@ServerEndpoint(value = "/chat/{username}",
        decoders = MessageDecoder.class,
        encoders = MessageEncoder.class)
public class Chat {
    private static final List<Session> connections = new CopyOnWriteArrayList<>();
    private static final Map<String, String> users = Collections.synchronizedMap(new HashMap<>());
    private String username;

    @OnOpen
    public void onOpen(Session session, @PathParam("username") String username) {
        System.out.println(session.getId() + ": onOpen");
        this.username = username;
        connections.add(session);
        users.put(session.getId(), username);
        login();
    }

    @OnClose
    public void onClose(Session session) {
        System.out.println(session.getId() + ": onClose");
        users.remove(session.getId());
        connections.remove(session);
        logout();
    }

    @OnError
    public void onError(Session session, Throwable error) {
        System.out.println(session.getId() + ": " + error.getMessage());
    }

    @OnMessage
    public void onMessage(Session session, Message message) {
        broadcast(message);
    }

    private void login() {
        var message = new Message();
        message.setFrom(username);
        message.setContent("Online");
        broadcast(message);
        System.out.println("Login: " + username);
        System.out.println("Anzahl User: " + users.size());
    }

    private void logout() {
        var message = new Message();
        message.setFrom(username);
        message.setContent("Offline");
        broadcast(message);
        System.out.println("Logout: " + username);
        System.out.println("Anzahl User: " + users.size());
    }

    private void broadcast(Message message) {
        for (var session : connections) {
            if (session.isOpen()) {
                try {
                    session.getBasicRemote().sendObject(message);
                } catch (IOException | EncodeException e) {
                    System.err.println(e.getMessage());
                }
            }
        }
    }
}
