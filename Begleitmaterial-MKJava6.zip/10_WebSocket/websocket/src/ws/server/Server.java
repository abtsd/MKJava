package ws.server;

import org.apache.catalina.connector.Connector;
import org.apache.catalina.startup.Tomcat;
import ws.server.news.News;

import java.io.File;
import java.net.InetAddress;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Server {
    public static void main(String[] args) throws Exception {
        var port = Integer.parseInt(args[0]);
        var news = Boolean.parseBoolean(args[1]);

        var contextPath = "/ws";
        var docBase = "web";

        Logger.getLogger("org").setLevel(Level.SEVERE);

        var tomcat = new Tomcat();
        tomcat.setBaseDir(System.getProperty("java.io.tmpdir"));
        var ctx = tomcat.addWebapp(contextPath, new File(docBase).getAbsolutePath());

        var con = new Connector();
        con.setPort(port);

        var service = tomcat.getService();
        service.addConnector(con);

        tomcat.start();

        System.out.println("DocBase: " + ctx.getDocBase());
        String url = con.getScheme() + "://" + InetAddress.getLocalHost().getHostAddress() + ":" +
                con.getPort() + ctx.getPath();
        System.out.println("URL: " + url);
        System.out.println("Stoppen mit ENTER");

        Thread newsThread = null;
        if (news) {
            newsThread = new News.NewsThread();
            newsThread.start();
        }

        System.in.read();
        if (newsThread != null)
            newsThread.interrupt();

        tomcat.stop();
        tomcat.destroy();
    }
}
