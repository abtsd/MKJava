@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://learnwebservices.com/services/tempconverter", elementFormDefault = jakarta.xml.bind.annotation.XmlNsForm.QUALIFIED)
package generated;
