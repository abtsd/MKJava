
package generated;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java-Klasse für celsiusToFahrenheitResponse complex type.
 * 
 * <p>Das folgende Schemafragment gibt den erwarteten Content an, der in dieser Klasse enthalten ist.
 * 
 * <pre>
 * &lt;complexType name="celsiusToFahrenheitResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="TemperatureInFahrenheit" type="{http://www.w3.org/2001/XMLSchema}double"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "celsiusToFahrenheitResponse", propOrder = {
    "temperatureInFahrenheit"
})
public class CelsiusToFahrenheitResponse {

    @XmlElement(name = "TemperatureInFahrenheit")
    protected double temperatureInFahrenheit;

    /**
     * Ruft den Wert der temperatureInFahrenheit-Eigenschaft ab.
     * 
     */
    public double getTemperatureInFahrenheit() {
        return temperatureInFahrenheit;
    }

    /**
     * Legt den Wert der temperatureInFahrenheit-Eigenschaft fest.
     * 
     */
    public void setTemperatureInFahrenheit(double value) {
        this.temperatureInFahrenheit = value;
    }

}
