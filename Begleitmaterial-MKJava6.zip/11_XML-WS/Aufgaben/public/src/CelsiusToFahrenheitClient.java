import generated.CelsiusToFahrenheitRequest;
import generated.TempConverterEndpointService;

public class CelsiusToFahrenheitClient {
	public static void main(String[] args) {
		var celsius = Double.parseDouble(args[0]);

		var service = new TempConverterEndpointService();
		var port = service.getTempConverterEndpointPort();
		var request = new CelsiusToFahrenheitRequest();
		request.setTemperatureInCelsius(celsius);
		var response = port.celsiusToFahrenheit(request);
		var fahrenheit = response.getTemperatureInFahrenheit();
		System.out.println("Celsius: " + celsius + " -> Fahrenheit: " + fahrenheit);
	}
}
