http://www.learnwebservices.com

# WSDL
http://www.learnwebservices.com/services/tempconverter?wsdl

# Artefakte für Client generieren
java -cp ../../libs/xmlws/jaxws-tools.jar com.sun.tools.ws.WsImport -Xnocompile -encoding UTF-8 -s public/src -p generated http://www.learnwebservices.com/services/tempconverter?wsdl

# Aufruf Client
java -cp out/production/public;../../libs/xmlws/* CelsiusToFahrenheitClient 29.8

# Aufruf Client mit Dump
java -Dcom.sun.xml.ws.transport.http.client.HttpTransportPipe.dump=true -cp out/production/public;../../libs/xmlws/* CelsiusToFahrenheitClient 29.8
