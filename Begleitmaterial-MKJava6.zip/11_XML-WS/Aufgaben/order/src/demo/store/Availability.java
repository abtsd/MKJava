package demo.store;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;

@WebService
public interface Availability {
	@WebMethod
	boolean isAvailable(@WebParam(name = "id") int id, @WebParam(name = "quantity") int quantity);
}
