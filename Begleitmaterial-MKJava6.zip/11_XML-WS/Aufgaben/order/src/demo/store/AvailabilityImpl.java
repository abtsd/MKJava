package demo.store;

import jakarta.jws.WebService;

import java.util.Random;

@WebService(endpointInterface = "demo.store.Availability")
public class AvailabilityImpl implements Availability {
	@Override
	public boolean isAvailable(int id, int quantity) {
		var r = new Random();
		// Simulation Dauer der Prüfung
		var delay = 8 + r.nextInt(8);
		try {
			Thread.sleep(delay * 1000);
		} catch (InterruptedException ignored) {
		}
		// Simulation Verfügbarkeit
		var isAvailable = r.nextBoolean();
		System.out.println("Artikel " + id + " ist " + (isAvailable ? "" : "nicht ") + "verfügbar.");
		return isAvailable;
	}
}
