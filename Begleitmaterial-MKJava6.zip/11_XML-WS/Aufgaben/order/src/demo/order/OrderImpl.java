package demo.order;

import generated_server.AvailabilityImplService;
import jakarta.jws.WebService;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

@WebService(endpointInterface = "demo.order.Order")
public class OrderImpl implements Order {
	private final String wsdlLocation = System.getProperty("wsdlLocation");
	private static final Map<Integer, Double> map;

	// Angebotene Artikel mit Preis pro Stück
	static {
		map = new HashMap<>();
		map.put(4711, 10.);
		map.put(4712, 5.);
		map.put(4713, 8.);
		map.put(4714, 3.);
		map.put(4715, 12.);
		map.put(4716, 11.);
		map.put(4717, 4.);
		map.put(4718, 6.);
		map.put(4719, 10.);
	}

	@Override
	public double order(int id, int quantity) throws OrderFault {
		var p = map.get(id);
		if (p == null) {
			var message = "Artikel " + id + " existiert nicht.";
			System.out.println(message);
			throw new OrderFault(message);
		}

		try {
			var service = wsdlLocation == null ? new AvailabilityImplService() :
					new AvailabilityImplService(new URL(wsdlLocation));
			var port = service.getAvailabilityImplPort();
			var isAvailable = port.isAvailable(id, quantity);

			if (!isAvailable) {
				var message = "Artikel " + id + " (Menge: " + quantity + ") nicht verfügbar.";
				System.out.println(message);
				throw new OrderFault(message);
			}

			var price = quantity * p;
			System.out.println("Artikel " + id + " (Menge: " + quantity + ") kostet " + price + " EUR.");
			return price;
		} catch (MalformedURLException e) {
			System.err.println(e.getMessage());
			throw new RuntimeException(e);
		}
	}
}
