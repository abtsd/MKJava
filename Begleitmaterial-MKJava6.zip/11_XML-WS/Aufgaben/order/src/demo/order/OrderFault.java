package demo.order;

public class OrderFault extends Exception {
	public OrderFault() {
	}

	public OrderFault(String msg) {
		super(msg);
	}
}
