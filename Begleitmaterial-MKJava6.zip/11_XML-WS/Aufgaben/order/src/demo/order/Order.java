package demo.order;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;

@WebService
public interface Order {
	@WebMethod
	double order(@WebParam(name = "id") int id, @WebParam(name = "quantity") int quantity) throws OrderFault;
}
