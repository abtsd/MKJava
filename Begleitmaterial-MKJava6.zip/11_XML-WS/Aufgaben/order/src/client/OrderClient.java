package client;

import generated_client.OrderImplService;
import generated_client.OrderResponse;
import jakarta.xml.ws.AsyncHandler;
import jakarta.xml.ws.Response;

import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.concurrent.CountDownLatch;

public class OrderClient {
    private static CountDownLatch latch;

    public static void main(String[] args) {
        var file = args[0];

        try {
            var wsdlLocation = System.getProperty("wsdlLocation");
            var service = wsdlLocation == null ? new OrderImplService() :
                    new OrderImplService(new URL(wsdlLocation));
            var port = service.getOrderImplPort();
            var orders = Files.readAllLines(Paths.get(file));
            latch = new CountDownLatch(orders.size());
            for (var order : orders) {
                try {
                    var parts = order.split(" ");
                    var id = Integer.parseInt(parts[0]);
                    var quantity = Integer.parseInt(parts[1]);
                    port.orderAsync(id, quantity, new MyHandler(id, quantity));
                } catch (Exception e) {
                    System.err.println(e.getMessage());
                    latch.countDown();
                }
            }
            latch.await();
        } catch (IOException | InterruptedException e) {
            System.err.println(e.getMessage());
        }
    }

    private static class MyHandler implements AsyncHandler<OrderResponse> {
        int id;
        int quantity;

        MyHandler(int id, int quantity) {
            this.id = id;
            this.quantity = quantity;
        }

        public void handleResponse(Response<OrderResponse> res) {
            try {
                var response = res.get();
                var price = response.getReturn();
                System.out.println("Artikel " + id + " (Menge: " + quantity + ") kostet " + price + " EUR.");
            } catch (Exception e) {
                System.out.println(e.getCause().getMessage());
            }
            latch.countDown();
        }
    }
}
