@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://store.demo/")
package generated_server;
