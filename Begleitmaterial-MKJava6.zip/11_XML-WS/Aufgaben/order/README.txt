# Server AvailabilityPublisher starten
java --add-opens java.base/java.lang=ALL-UNNAMED -cp out/production/order;../../libs/xmlws/* server.AvailabilityPublisher localhost 8081

# WSDL und XSD abrufen
http://localhost:8081/ws/store
http://localhost:8081/ws/store?wsdl
http://localhost:8081/ws/store?xsd=1

# Artefakte für Order-Service generieren
java -cp ../../libs/xmlws/jaxws-tools.jar com.sun.tools.ws.WsImport -Xnocompile -encoding UTF-8 -s order/src -p generated_server http://localhost:8081/ws/store?wsdl

# Server OrderPublisher starten
java --add-opens java.base/java.lang=ALL-UNNAMED -cp out/production/order;../../libs/xmlws/* server.OrderPublisher localhost 8080

# WSDL und XSD abrufen
http://localhost:8080/ws/order
http://localhost:8080/ws/order?wsdl
http://localhost:8080/ws/order?xsd=1

# Artefakte für Client generieren
java -cp ../../libs/xmlws/jaxws-tools.jar com.sun.tools.ws.WsImport -Xnocompile -encoding UTF-8 -s order/src -p generated_client -b order/async.xml http://localhost:8080/ws/order?wsdl

# Aufruf Client
java -cp out/production/order;../../libs/xmlws/* client.OrderClient order/orders.txt
