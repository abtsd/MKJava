# Server starten
java --add-opens java.base/java.lang=ALL-UNNAMED -cp out/production/digest;../../libs/xmlws/* server.DigestPublisher localhost 8080

# Artefakte für Client generieren
java -cp ../../libs/xmlws/jaxws-tools.jar com.sun.tools.ws.WsImport -Xnocompile -encoding UTF-8 -s digest_client/src -p generated -b digest_client/async.xml http://localhost:8080/ws/digest?wsdl

# Aufruf Client
java -cp out/production/digest_client;../../libs/xmlws/* AsyncClient

# Aufruf Client für Network-Monitor
java -Dhttp.proxyHost=localhost -Dhttp.proxyPort=8888 -Dhttp.nonProxyHosts= -cp out/production/digest_client;../../libs/xmlws/* AsyncClient

# Aufruf Client mit Dump
java -Dcom.sun.xml.ws.transport.http.client.HttpTransportPipe.dump=true -cp out/production/digest_client;../../libs/xmlws/* AsyncClient
