import generated.DigestImplService;
import generated.DigestResponse;
import jakarta.xml.ws.AsyncHandler;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.CountDownLatch;

public class AsyncClient {
	public static void main(String[] args) throws InterruptedException, MalformedURLException {
		var wsdlLocation = System.getProperty("wsdlLocation");
		var service = wsdlLocation == null ? new DigestImplService() :
				new DigestImplService(new URL(wsdlLocation));
		var port = service.getDigestImplPort();

		var latch = new CountDownLatch(4);
		AsyncHandler<DigestResponse> handler = response -> {
			DigestResponse digestResponse;
			try {
				digestResponse = response.get();
				var digest = digestResponse.getReturn();
				System.out.println(digest);
			} catch (Exception e) {
				System.err.println(e.getMessage());
			}
			latch.countDown();
		};

		var text = "Das ist ein Test!";
		port.digestAsync(text, "MD5", handler);
		port.digestAsync(text, "SHA-1", handler);
		port.digestAsync(text, "SHA-256", handler);
		port.digestAsync(text, "SHA-512", handler);
		latch.await();
	}
}
