@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://www.w3.org/2005/05/xmlmime")
package generated;
