package client;

import generated.ImageServiceImplService;

import javax.swing.*;
import java.net.MalformedURLException;
import java.net.URL;

public class ImageDownloadClient {
    public static void main(String[] args) throws MalformedURLException {
        var name = args[0];

        var wsdlLocation = System.getProperty("wsdlLocation");
        var service = wsdlLocation == null ? new ImageServiceImplService() :
                new ImageServiceImplService(new URL(wsdlLocation));
        var port = service.getImageServiceImplPort();
        JLabel label;
        try {
            var image = port.downloadImage(name);
            label = new JLabel(new ImageIcon(image), JLabel.CENTER);
        } catch (Exception e) {
            label = new JLabel("<html>Fehler beim Download:<br>" + e.getMessage()
                    + "</html>", JLabel.CENTER);
        }

        var imageFrame = new JFrame();
        imageFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        imageFrame.setSize(1000, 1000);
        imageFrame.add(label);
        imageFrame.setVisible(true);
    }
}