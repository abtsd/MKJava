package demo.image;

import jakarta.jws.WebMethod;
import jakarta.jws.WebService;
import jakarta.xml.bind.annotation.XmlMimeType;

import java.awt.*;

@WebService
public interface ImageService {
	@WebMethod
	@XmlMimeType("image/*")
	Image downloadImage(String name);
}
