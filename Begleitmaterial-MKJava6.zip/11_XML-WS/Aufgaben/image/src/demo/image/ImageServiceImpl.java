package demo.image;

import jakarta.jws.WebService;
import jakarta.xml.ws.WebServiceException;
import jakarta.xml.ws.soap.MTOM;

import javax.imageio.ImageIO;
import java.awt.*;
import java.io.File;
import java.io.IOException;

@WebService(endpointInterface = "demo.image.ImageService")
@MTOM
public class ImageServiceImpl implements ImageService {
	private static final String DIR = "images";

	@Override
	public Image downloadImage(String name) {
		var path = DIR + "/" + name;
		var image = new File(path);
		try {
			return ImageIO.read(image);
		} catch (IOException e) {
			throw new WebServiceException(e.getMessage());
		}
	}
}
