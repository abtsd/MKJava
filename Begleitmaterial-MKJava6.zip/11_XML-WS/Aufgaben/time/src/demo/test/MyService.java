package demo.test;

import jakarta.jws.WebMethod;
import jakarta.jws.WebService;

@WebService
public interface MyService {
	@WebMethod
	String doSomething(String input);
}
