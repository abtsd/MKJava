package demo.test;

import jakarta.jws.HandlerChain;
import jakarta.jws.WebService;

import java.util.Random;

@WebService(endpointInterface = "demo.test.MyService")
@HandlerChain(file = "server-handler-chain.xml")
public class MyServiceImpl implements MyService {
	@Override
	public String doSomething(String input) {
		var r = new Random();
		try {
			Thread.sleep(r.nextInt(3000));
		} catch (InterruptedException ignored) {
		}
		return input;
	}
}
