@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://test.demo/")
package generated;
