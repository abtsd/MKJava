package server.handler;

import jakarta.xml.ws.handler.MessageContext;
import jakarta.xml.ws.handler.soap.SOAPHandler;
import jakarta.xml.ws.handler.soap.SOAPMessageContext;

import javax.xml.namespace.QName;

import java.time.Duration;
import java.time.Instant;
import java.util.Set;
import java.util.logging.Logger;

public class TimeLogger implements SOAPHandler<SOAPMessageContext> {
	private static final Logger log = Logger.getLogger(TimeLogger.class.getName());
	
	@Override
	public void close(MessageContext ctx) {
	}

	@Override
	public boolean handleFault(SOAPMessageContext ctx) {
		return true;
	}

	@Override
	public boolean handleMessage(SOAPMessageContext ctx) {
		var outbound = (Boolean) ctx.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);

		if (outbound) {
			var end = Instant.now();
			var start = (Instant) ctx.get("START");
			var duration = Duration.between(start, end);
			var message = String.format(
					"Start: %s Ende: %s Dauer: %5d ms", start.toString(), end.toString(), duration.toMillis());
			log.info(message);
		} else {
			ctx.put("START", Instant.now());
		}

		return true;
	}

	@Override
	public Set<QName> getHeaders() {
		return null;
	}
}
