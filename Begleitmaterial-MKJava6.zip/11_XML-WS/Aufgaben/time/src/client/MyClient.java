package client;

import generated.MyServiceImplService;

import java.net.MalformedURLException;
import java.net.URL;

public class MyClient {
	public static void main(String[] args) throws MalformedURLException {
		var wsdlLocation = System.getProperty("wsdlLocation");
		var service = wsdlLocation == null ? new MyServiceImplService() :
				new MyServiceImplService(new URL(wsdlLocation));
		var port = service.getMyServiceImplPort();
		var result = port.doSomething("Das ist ein Test.");
		System.out.println(result);
	}
}
