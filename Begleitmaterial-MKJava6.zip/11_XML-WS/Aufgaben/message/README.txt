# Server starten
java --add-opens java.base/java.lang=ALL-UNNAMED -cp out/production/message;../../libs/xmlws/* server.MessagePublisher localhost 8080

# WSDL und XSD abrufen
http://localhost:8080/ws/message
http://localhost:8080/ws/message?wsdl
http://localhost:8080/ws/message?xsd=1

# Artefakte für Client generieren
java -cp ../../libs/xmlws/jaxws-tools.jar com.sun.tools.ws.WsImport -Xnocompile -encoding UTF-8 -s message/src -p generated http://localhost:8080/ws/message?wsdl

# Aufruf Client
java -cp out/production/message;../../libs/xmlws/* client.MessageClient

# Aufruf Client für Network-Monitor
java -Dhttp.proxyHost=localhost -Dhttp.proxyPort=8888 -Dhttp.nonProxyHosts= -cp out/production/message;../../libs/xmlws/* client.MessageClient

# Aufruf Client mit Dump
java -Dcom.sun.xml.ws.transport.http.client.HttpTransportPipe.dump=true -cp out/production/message;../../libs/xmlws/* client.MessageClient
