package client;

import generated.Message;
import generated.MessageServiceImplService;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.LocalDateTime;

public class MessageClient {
	public static void main(String[] args) throws MalformedURLException {
		var wsdlLocation = System.getProperty("wsdlLocation");
		var service = wsdlLocation == null ? new MessageServiceImplService() :
				new MessageServiceImplService(new URL(wsdlLocation));
		var port = service.getMessageServiceImplPort();
		var username = "Hugo";
		var text = "Das ist ein Test!";
		var message = createMessage(username, text);
		port.send(message);
	}
	
	private static Message createMessage(String username, String text) {
		var message = new Message();
		message.setTimestamp(LocalDateTime.now().toString());
		message.setUsername(username);
		message.setText(text);
		return message;
	}
}
