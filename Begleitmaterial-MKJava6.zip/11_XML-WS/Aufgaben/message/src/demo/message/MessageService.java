package demo.message;

import jakarta.jws.Oneway;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;

@WebService
public interface MessageService {
	@WebMethod
	@Oneway
	void send(@WebParam(name = "message") Message message);
}
