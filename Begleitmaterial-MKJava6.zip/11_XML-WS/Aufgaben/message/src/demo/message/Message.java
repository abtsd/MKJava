package demo.message;

import jakarta.xml.bind.annotation.XmlType;

@XmlType(propOrder = { "timestamp", "username", "text" })
public class Message {
	private String timestamp;
	private String username;
	private String text;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
}
