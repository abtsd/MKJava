package demo.message;

import jakarta.jws.WebService;

@WebService(endpointInterface = "demo.message.MessageService")
public class MessageServiceImpl implements MessageService {
	@Override
	public void send(Message message) {
		System.out.println(message.getTimestamp());
		System.out.println("Username: " + message.getUsername());
		System.out.println("Text: " + message.getText());
	}
}
