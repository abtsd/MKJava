@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://message.demo/")
package generated;
