jar --create --file web/WEB-INF/lib/mosteller.jar -C out/production/mosteller demo
jar --create --file web/WEB-INF/lib/digest.jar -C out/production/digest demo

java --add-opens=java.base/java.lang=ALL-UNNAMED --add-opens=java.base/java.io=ALL-UNNAMED --add-opens=java.rmi/sun.rmi.transport=ALL-UNNAMED -cp ../../webserver/webserver.jar;../../libs/tomcat/*;../../libs/xmlws/* WebServer /ws web 8080 false false

http://localhost:8080/ws/
