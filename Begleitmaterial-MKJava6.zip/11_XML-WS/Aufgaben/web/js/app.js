function $(id) {
    return document.getElementById(id);
}

function send() {
    const text = $("text").value;
    const algorithm = $("algorithm").value;

    if (text.trim().length == 0) {
        $("text").value = "";
        $("text").focus();
        return;
    }

    const soap_message = '<?xml version="1.0" encoding="UTF-8"?>' +
        '<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" ' +
        'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" ' +
        'xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:m="http://digest.demo/">' +
        '<soap:Body>' +
        '<m:digest>' +
        '<text>' + text + '</text>' +
        '<algorithm>' + algorithm + '</algorithm>' +
        '</m:digest>' +
        '</soap:Body>' +
        '</soap:Envelope>';

    fetch("/ws/digest", {
        method: 'POST',
        headers: {
            'Content-Type': 'text/xml; charset=UTF-8'
        },
        body: soap_message
    }).then(response => {
        if (response.ok)
            return response.text();
        else
            throw new Error("HTTP-Statuscode = " + response.status);
    }).then(body => {
        const xmlDoc = new DOMParser().parseFromString(body, "text/xml");
        const result = xmlDoc.getElementsByTagName("return")[0].childNodes[0].nodeValue;
        $("result").value = result;
    }).catch(error => {
        alert(error);
    });
}

function reset() {
    $("text").value = "";
    $("algorithm").selectedIndex = 0;
    $("result").value = "";
}
