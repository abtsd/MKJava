package server;

import demo.digest.DigestImpl;
import jakarta.xml.ws.Endpoint;

import java.io.IOException;

public class DigestPublisher {
	public static void main(String[] args) throws IOException {
		var host = args[0];
		var port = Integer.parseInt(args[1]);

		var address = "http://" + host + ":" + port + "/ws/digest";
		var implementor = new DigestImpl();

		var endpoint = Endpoint.create(implementor);
		endpoint.publish(address);

		System.out.println("Service gestartet: " + address);
		System.out.println("Stoppen mit ENTER");
		System.in.read();
		endpoint.stop();
	}
}
