import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class DigestTest {
	public static void main(String[] args) throws NoSuchAlgorithmException {
		var text = "Das ist ein Test!";
		System.out.println(digest(text, "MD5"));
		System.out.println(digest(text, "SHA-1"));
		System.out.println(digest(text, "SHA-256"));
		System.out.println(digest(text, "SHA-512"));
	}
	
	private static String digest(String text, String algorithm) throws NoSuchAlgorithmException {
		var md = MessageDigest.getInstance(algorithm);
		md.update(text.getBytes());
		var digest = md.digest();

		var sb = new StringBuilder();
		for (var b : digest) {
			sb.append(String.format("%02x", b));
		}
		
		return sb.toString();
	}
}
