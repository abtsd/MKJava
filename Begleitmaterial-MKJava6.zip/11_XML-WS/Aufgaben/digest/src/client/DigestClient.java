package client;

import generated.DigestImplService;

import java.net.MalformedURLException;
import java.net.URL;

public class DigestClient {
	public static void main(String[] args) throws MalformedURLException {
		var wsdlLocation = System.getProperty("wsdlLocation");
		var service = wsdlLocation == null ? new DigestImplService() :
				new DigestImplService(new URL(wsdlLocation));
		var port = service.getDigestImplPort();
		var text = "Das ist ein Test!";
		try {
			System.out.println(port.digest(text, "MD5"));
			System.out.println(port.digest(text, "SHA-1"));
			System.out.println(port.digest(text, "SHA-256"));
			System.out.println(port.digest(text, "SHA-512"));
			System.out.println(port.digest(text, "xxx"));
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}
}
