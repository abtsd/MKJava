package demo.digest;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;

import java.security.NoSuchAlgorithmException;

@WebService
public interface Digest {
	@WebMethod
	String digest(
			@WebParam(name = "text") String text,
			@WebParam(name = "algorithm") String algorithm) throws NoSuchAlgorithmException;
}
