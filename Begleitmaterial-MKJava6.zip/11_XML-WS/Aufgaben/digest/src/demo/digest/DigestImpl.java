package demo.digest;

import jakarta.jws.WebService;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@WebService(endpointInterface = "demo.digest.Digest")
public class DigestImpl implements Digest {
	@Override
	public String digest(String text, String algorithm) throws NoSuchAlgorithmException {
		var md = MessageDigest.getInstance(algorithm);
		md.update(text.getBytes());
		var digest = md.digest();

		var sb = new StringBuilder();
		for (var b : digest) {
			sb.append(String.format("%02x", b));
		}

		return sb.toString();
	}
}
