@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://digest.demo/")
package generated;
