
package generated;

import javax.xml.namespace.QName;
import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlElementDecl;
import jakarta.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the generated package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _NoSuchAlgorithmException_QNAME = new QName("http://digest.demo/", "NoSuchAlgorithmException");
    private final static QName _Digest_QNAME = new QName("http://digest.demo/", "digest");
    private final static QName _DigestResponse_QNAME = new QName("http://digest.demo/", "digestResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: generated
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link NoSuchAlgorithmException }
     * 
     */
    public NoSuchAlgorithmException createNoSuchAlgorithmException() {
        return new NoSuchAlgorithmException();
    }

    /**
     * Create an instance of {@link Digest_Type }
     * 
     */
    public Digest_Type createDigest_Type() {
        return new Digest_Type();
    }

    /**
     * Create an instance of {@link DigestResponse }
     * 
     */
    public DigestResponse createDigestResponse() {
        return new DigestResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NoSuchAlgorithmException }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link NoSuchAlgorithmException }{@code >}
     */
    @XmlElementDecl(namespace = "http://digest.demo/", name = "NoSuchAlgorithmException")
    public JAXBElement<NoSuchAlgorithmException> createNoSuchAlgorithmException(NoSuchAlgorithmException value) {
        return new JAXBElement<NoSuchAlgorithmException>(_NoSuchAlgorithmException_QNAME, NoSuchAlgorithmException.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Digest_Type }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Digest_Type }{@code >}
     */
    @XmlElementDecl(namespace = "http://digest.demo/", name = "digest")
    public JAXBElement<Digest_Type> createDigest(Digest_Type value) {
        return new JAXBElement<Digest_Type>(_Digest_QNAME, Digest_Type.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DigestResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DigestResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://digest.demo/", name = "digestResponse")
    public JAXBElement<DigestResponse> createDigestResponse(DigestResponse value) {
        return new JAXBElement<DigestResponse>(_DigestResponse_QNAME, DigestResponse.class, null, value);
    }

}
