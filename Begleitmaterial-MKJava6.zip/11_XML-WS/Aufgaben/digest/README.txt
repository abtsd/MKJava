# Aufruf DigestTest
java -cp out/production/digest DigestTest

# Server starten
java --add-opens java.base/java.lang=ALL-UNNAMED -cp out/production/digest;../../libs/xmlws/* server.DigestPublisher localhost 8080

# WSDL und XSD abrufen
http://localhost:8080/ws/digest
http://localhost:8080/ws/digest?wsdl
http://localhost:8080/ws/digest?xsd=1

# Artefakte für Client generieren
java -cp ../../libs/xmlws/jaxws-tools.jar com.sun.tools.ws.WsImport -Xnocompile -encoding UTF-8 -s digest/src -p generated http://localhost:8080/ws/digest?wsdl

# Aufruf Client
java -cp out/production/digest;../../libs/xmlws/* client.DigestClient

# Aufruf Client für Network-Monitor
java -Dhttp.proxyHost=localhost -Dhttp.proxyPort=8888 -Dhttp.nonProxyHosts= -cp out/production/digest;../../libs/xmlws/* client.DigestClient

# Aufruf Client mit Dump
java -Dcom.sun.xml.ws.transport.http.client.HttpTransportPipe.dump=true -cp out/production/digest;../../libs/xmlws/* client.DigestClient
