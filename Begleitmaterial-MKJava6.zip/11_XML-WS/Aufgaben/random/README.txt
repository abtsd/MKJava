# Server starten
java --add-opens=java.base/java.lang=ALL-UNNAMED --add-opens=java.base/java.io=ALL-UNNAMED --add-opens=java.rmi/sun.rmi.transport=ALL-UNNAMED -cp ../../webserver/webserver.jar;../../libs/tomcat/*;../../libs/xmlws/* WebServer /ws random/web 8080 false false

# Artefakte für Webservice-Implementierung generieren
java -cp ../../libs/xmlws/jaxws-tools.jar com.sun.tools.ws.WsImport -Xnocompile -encoding UTF-8 -s random/src -p generated_server http://localhost:8080/ws/RandImplService.wsdl

# Server neu starten (mit ergänztem Classpath)
java --add-opens=java.base/java.lang=ALL-UNNAMED --add-opens=java.base/java.io=ALL-UNNAMED --add-opens=java.rmi/sun.rmi.transport=ALL-UNNAMED -cp out/production/random;../../webserver/webserver.jar;../../libs/tomcat/*;../../libs/xmlws/* WebServer /ws random/web 8080 false false

# Artefakte für Client generieren
java -cp ../../libs/xmlws/jaxws-tools.jar com.sun.tools.ws.WsImport -Xnocompile -encoding UTF-8 -s random/src -p generated_client http://localhost:8080/ws/RandImplService.wsdl

# Aufruf Client
java -cp out/production/random;../../libs/xmlws/* client.RandClient

# Aufruf Client für Network-Monitor
java -Dhttp.proxyHost=localhost -Dhttp.proxyPort=8888 -Dhttp.nonProxyHosts= -cp out/production/random;../../libs/xmlws/* client.RandClient

# Aufruf Client mit Dump
java -Dcom.sun.xml.ws.transport.http.client.HttpTransportPipe.dump=true -cp out/production/random;../../libs/xmlws/* client.RandClient