package client;

import generated_client.RandImplService;

import java.net.MalformedURLException;
import java.net.URL;

public class RandClient {
	public static void main(String[] args) throws MalformedURLException {
		var wsdlLocation = System.getProperty("wsdlLocation");
		var service = wsdlLocation == null ? new RandImplService() :
				new RandImplService(new URL(wsdlLocation));
		var port = service.getRandImplPort();
		var rands = port.rand(100, 20);
		System.out.println(rands);
	}
}
