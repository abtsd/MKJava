
package generated_server;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java-Klasse für rand complex type.
 * 
 * <p>Das folgende Schemafragment gibt den erwarteten Content an, der in dieser Klasse enthalten ist.
 * 
 * <pre>
 * &lt;complexType name="rand"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="bound" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="length" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "rand", propOrder = {
    "bound",
    "length"
})
public class Rand_Type {

    protected int bound;
    protected int length;

    /**
     * Ruft den Wert der bound-Eigenschaft ab.
     * 
     */
    public int getBound() {
        return bound;
    }

    /**
     * Legt den Wert der bound-Eigenschaft fest.
     * 
     */
    public void setBound(int value) {
        this.bound = value;
    }

    /**
     * Ruft den Wert der length-Eigenschaft ab.
     * 
     */
    public int getLength() {
        return length;
    }

    /**
     * Legt den Wert der length-Eigenschaft fest.
     * 
     */
    public void setLength(int value) {
        this.length = value;
    }

}
