
package generated_server;

import javax.xml.namespace.QName;
import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlElementDecl;
import jakarta.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the generated_server package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Rand_QNAME = new QName("http://rand.demo/", "rand");
    private final static QName _RandResponse_QNAME = new QName("http://rand.demo/", "randResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: generated_server
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Rand_Type }
     * 
     */
    public Rand_Type createRand_Type() {
        return new Rand_Type();
    }

    /**
     * Create an instance of {@link RandResponse }
     * 
     */
    public RandResponse createRandResponse() {
        return new RandResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Rand_Type }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Rand_Type }{@code >}
     */
    @XmlElementDecl(namespace = "http://rand.demo/", name = "rand")
    public JAXBElement<Rand_Type> createRand(Rand_Type value) {
        return new JAXBElement<Rand_Type>(_Rand_QNAME, Rand_Type.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RandResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RandResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://rand.demo/", name = "randResponse")
    public JAXBElement<RandResponse> createRandResponse(RandResponse value) {
        return new JAXBElement<RandResponse>(_RandResponse_QNAME, RandResponse.class, null, value);
    }

}
