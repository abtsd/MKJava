/**
 * Zufallszahlen generieren
 * 
 */
@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://rand.demo/")
package generated_client;
