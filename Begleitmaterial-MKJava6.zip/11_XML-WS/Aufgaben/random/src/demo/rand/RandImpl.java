package demo.rand;

import generated_server.Rand;
import jakarta.jws.WebService;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@WebService(
	endpointInterface = "generated_server.Rand"
)
public class RandImpl implements Rand {
	@Override
	public List<Integer> rand(int bound, int length) {
		var rands = new ArrayList<Integer>();
		var random = new Random();
		for (var i = 0; i < length; i++) {
			rands.add(random.nextInt(bound));
		}
		return rands;
	}
}
