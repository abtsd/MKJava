
package generated;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java-Klasse für mosteller complex type.
 * 
 * <p>Das folgende Schemafragment gibt den erwarteten Content an, der in dieser Klasse enthalten ist.
 * 
 * <pre>
 * &lt;complexType name="mosteller"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="groesse" type="{http://www.w3.org/2001/XMLSchema}double"/&gt;
 *         &lt;element name="gewicht" type="{http://www.w3.org/2001/XMLSchema}double"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "mosteller", propOrder = {
    "groesse",
    "gewicht"
})
public class Mosteller_Type {

    protected double groesse;
    protected double gewicht;

    /**
     * Ruft den Wert der groesse-Eigenschaft ab.
     * 
     */
    public double getGroesse() {
        return groesse;
    }

    /**
     * Legt den Wert der groesse-Eigenschaft fest.
     * 
     */
    public void setGroesse(double value) {
        this.groesse = value;
    }

    /**
     * Ruft den Wert der gewicht-Eigenschaft ab.
     * 
     */
    public double getGewicht() {
        return gewicht;
    }

    /**
     * Legt den Wert der gewicht-Eigenschaft fest.
     * 
     */
    public void setGewicht(double value) {
        this.gewicht = value;
    }

}
