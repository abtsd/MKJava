@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://mosteller.demo/")
package generated;
