
package generated;

import javax.xml.namespace.QName;
import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlElementDecl;
import jakarta.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the generated package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Mosteller_QNAME = new QName("http://mosteller.demo/", "mosteller");
    private final static QName _MostellerResponse_QNAME = new QName("http://mosteller.demo/", "mostellerResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: generated
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Mosteller_Type }
     * 
     */
    public Mosteller_Type createMosteller_Type() {
        return new Mosteller_Type();
    }

    /**
     * Create an instance of {@link MostellerResponse }
     * 
     */
    public MostellerResponse createMostellerResponse() {
        return new MostellerResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Mosteller_Type }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Mosteller_Type }{@code >}
     */
    @XmlElementDecl(namespace = "http://mosteller.demo/", name = "mosteller")
    public JAXBElement<Mosteller_Type> createMosteller(Mosteller_Type value) {
        return new JAXBElement<Mosteller_Type>(_Mosteller_QNAME, Mosteller_Type.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MostellerResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link MostellerResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://mosteller.demo/", name = "mostellerResponse")
    public JAXBElement<MostellerResponse> createMostellerResponse(MostellerResponse value) {
        return new JAXBElement<MostellerResponse>(_MostellerResponse_QNAME, MostellerResponse.class, null, value);
    }

}
