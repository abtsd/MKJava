package client;

import generated.MostellerImplService;

import java.net.MalformedURLException;
import java.net.URL;

public class MostellerClient {
	public static void main(String[] args) throws MalformedURLException {
		var wsdlLocation = System.getProperty("wsdlLocation");
		var service = wsdlLocation == null ? new MostellerImplService() :
				new MostellerImplService(new URL(wsdlLocation));
		var port = service.getMostellerImplPort();
		var oberflaeche = port.mosteller(182., 82.);
		System.out.println(oberflaeche);
	}
}
