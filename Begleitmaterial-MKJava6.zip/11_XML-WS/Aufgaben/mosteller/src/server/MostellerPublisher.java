package server;

import demo.mosteller.MostellerImpl;
import jakarta.xml.ws.Endpoint;

import java.io.IOException;

public class MostellerPublisher {
	public static void main(String[] args) throws IOException {
		var host = args[0];
		var port = Integer.parseInt(args[1]);

		var address = "http://" + host + ":" + port + "/ws/mosteller";
		var implementor = new MostellerImpl();

		var endpoint = Endpoint.create(implementor);
		endpoint.publish(address);

		System.out.println("Service gestartet: " + address);
		System.out.println("Stoppen mit ENTER");
		System.in.read();
		endpoint.stop();
	}
}
