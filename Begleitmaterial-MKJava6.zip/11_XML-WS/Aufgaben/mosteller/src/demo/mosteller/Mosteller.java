package demo.mosteller;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;

@WebService
public interface Mosteller {
	@WebMethod
	double mosteller(@WebParam(name = "groesse") double groesse, @WebParam(name = "gewicht") double gewicht);
}
