package demo.mosteller;

import jakarta.jws.WebService;

@WebService(endpointInterface = "demo.mosteller.Mosteller")
public class MostellerImpl implements Mosteller {
	@Override
	public double mosteller(double groesse, double gewicht) {
		return Math.sqrt(groesse * gewicht) / 60.;
	}
}
