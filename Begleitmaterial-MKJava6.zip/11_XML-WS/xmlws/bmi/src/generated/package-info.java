@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://bmi.demo/")
package generated;
