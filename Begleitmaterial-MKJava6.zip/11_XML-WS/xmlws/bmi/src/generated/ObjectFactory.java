
package generated;

import javax.xml.namespace.QName;
import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlElementDecl;
import jakarta.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the generated package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Bmi_QNAME = new QName("http://bmi.demo/", "bmi");
    private final static QName _BmiResponse_QNAME = new QName("http://bmi.demo/", "bmiResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: generated
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Bmi_Type }
     * 
     */
    public Bmi_Type createBmi_Type() {
        return new Bmi_Type();
    }

    /**
     * Create an instance of {@link BmiResponse }
     * 
     */
    public BmiResponse createBmiResponse() {
        return new BmiResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Bmi_Type }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Bmi_Type }{@code >}
     */
    @XmlElementDecl(namespace = "http://bmi.demo/", name = "bmi")
    public JAXBElement<Bmi_Type> createBmi(Bmi_Type value) {
        return new JAXBElement<Bmi_Type>(_Bmi_QNAME, Bmi_Type.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BmiResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link BmiResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://bmi.demo/", name = "bmiResponse")
    public JAXBElement<BmiResponse> createBmiResponse(BmiResponse value) {
        return new JAXBElement<BmiResponse>(_BmiResponse_QNAME, BmiResponse.class, null, value);
    }

}
