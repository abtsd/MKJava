package client;

import generated.BmiImplService;

import java.net.MalformedURLException;
import java.net.URL;

public class BmiClient {
	public static void main(String[] args) throws MalformedURLException {
		var wsdlLocation = System.getProperty("wsdlLocation");
		var service = wsdlLocation == null ? new BmiImplService() :
				new BmiImplService(new URL(wsdlLocation));
		var port = service.getBmiImplPort();
		System.out.println(port.bmi(46, 1.7));
		System.out.println(port.bmi(56, 1.7));
		System.out.println(port.bmi(78, 1.76));
		System.out.println(port.bmi(78, 1.6));
	}
}
