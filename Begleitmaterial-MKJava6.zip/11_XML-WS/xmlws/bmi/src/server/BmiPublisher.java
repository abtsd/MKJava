package server;

import demo.bmi.BmiImpl;
import jakarta.xml.ws.Endpoint;

import java.io.IOException;

public class BmiPublisher {
	public static void main(String[] args) throws IOException {
		var host = args[0];
		var port = Integer.parseInt(args[1]);

		var address = "http://" + host + ":" + port + "/ws/bmi";
		var implementor = new BmiImpl();

		var endpoint = Endpoint.create(implementor);
		endpoint.publish(address);

		System.out.println("Service gestartet: " + address);
		System.out.println("Stoppen mit ENTER");
		System.in.read();
		endpoint.stop();
	}
}
