package demo.bmi;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;

@WebService
public interface Bmi {
	@WebMethod
	String bmi(@WebParam(name = "gewicht") double gewicht, @WebParam(name = "groesse") double groesse);
}
