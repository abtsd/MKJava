package demo.bmi;

import jakarta.jws.WebService;

@WebService(endpointInterface = "demo.bmi.Bmi")
public class BmiImpl implements Bmi {
    @Override
    public String bmi(double gewicht, double groesse) {
        var bmi = gewicht / (groesse * groesse);
        var label = "";

        if (bmi < 18.5)
            label = "Untergewicht";
        else if (bmi >= 18.5 && bmi < 25)
            label = "Normalgewicht";
        else if (bmi >= 25 && bmi < 30)
            label = "Übergewicht";
        else
            label = "Adipositas";

        return String.format("%s: %.2f", label, bmi);
    }
}
