# Server starten
java --add-opens java.base/java.lang=ALL-UNNAMED -cp out/production/bmi;../../libs/xmlws/* server.BmiPublisher localhost 8080

# WSDL und XSD abrufen
http://localhost:8080/ws/bmi
http://localhost:8080/ws/bmi?wsdl
http://localhost:8080/ws/bmi?xsd=1

# Artefakte für Client generieren
java -cp ../../libs/xmlws/jaxws-tools.jar com.sun.tools.ws.WsImport -Xnocompile -encoding UTF-8 -s bmi/src -p generated http://localhost:8080/ws/bmi?wsdl

# Aufruf Client
java -cp out/production/bmi;../../libs/xmlws/* client.BmiClient

# Aufruf Client für Network-Monitor
java -Dhttp.proxyHost=localhost -Dhttp.proxyPort=8888 -Dhttp.nonProxyHosts= -cp out/production/bmi;../../libs/xmlws/* client.BmiClient

# Aufruf Client mit Dump
java -Dcom.sun.xml.ws.transport.http.client.HttpTransportPipe.dump=true -cp out/production/bmi;../../libs/xmlws/* client.BmiClient

# PowerShell Client
Windows PowerShell Integrated Scripting Environment (ISE):
powershell_ise bmi/client.ps1
    oder
powershell bmi/client.ps1

Um Skripte in ISE ausführen zu können, PowerShell "Als Administrator ausführen" starten und eingeben:
Set-ExecutionPolicy Unrestricted
Get-ExecutionPolicy
