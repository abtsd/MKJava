@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://transfer.demo/")
package generated;
