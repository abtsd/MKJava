package demo.transfer;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;

@WebService
public interface Transfer {
	@WebMethod
	void upload(@WebParam(name = "name") String name, @WebParam(name = "data") byte[] data);

	@WebMethod
	byte[] download(@WebParam(name = "name") String name);
}
