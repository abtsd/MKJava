package demo.transfer;

import jakarta.jws.WebService;
import jakarta.xml.ws.WebServiceException;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;

@WebService(endpointInterface = "demo.transfer.Transfer")
public class TransferImpl implements Transfer {
	private static final String DIR = "tmp";

	@Override
	public void upload(String name, byte[] data) {
		try {
			Files.write(Paths.get(DIR, name), data);
		} catch (IOException e) {
			throw new WebServiceException("Fehler beim Upload: " + e.getMessage());
		}
	}

	@Override
	public byte[] download(String name) {
		try {
			return Files.readAllBytes(Paths.get(DIR, name));
		} catch (IOException e) {
			throw new WebServiceException("Fehler beim Download: " + e.getMessage());
		}
	}
}
