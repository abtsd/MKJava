package client;

import generated.TransferImplService;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;

public class UploadClient {
	public static void main(String[] args) throws MalformedURLException {
		var wsdlLocation = System.getProperty("wsdlLocation");
		var service = wsdlLocation == null ? new TransferImplService() :
				new TransferImplService(new URL(wsdlLocation));
		var port = service.getTransferImplPort();
		var name = "duke.png";
		try {
			var data = Files.readAllBytes(Paths.get(name));
			port.upload(name, data);
			System.out.println(name + " wurde hochgeladen.");
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}
	}
}