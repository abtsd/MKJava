# Server starten (mit contract_first/web1)
java --add-opens=java.base/java.lang=ALL-UNNAMED --add-opens=java.base/java.io=ALL-UNNAMED --add-opens=java.rmi/sun.rmi.transport=ALL-UNNAMED -cp ../../webserver/webserver.jar;../../libs/tomcat/*;../../libs/xmlws/* WebServer /ws contract_first/web1 8080 false false

# Artefakte für Webservice-Implementierung generieren
java -cp ../../libs/xmlws/jaxws-tools.jar com.sun.tools.ws.WsImport -Xnocompile -encoding UTF-8 -s contract_first/src -p generated_server http://localhost:8080/ws/TimeService.wsdl

# Server neu starten (mit contract_first/web2)
java --add-opens=java.base/java.lang=ALL-UNNAMED --add-opens=java.base/java.io=ALL-UNNAMED --add-opens=java.rmi/sun.rmi.transport=ALL-UNNAMED -cp out/production/contract_first;../../webserver/webserver.jar;../../libs/tomcat/*;../../libs/xmlws/* WebServer /ws contract_first/web2 8080 false false

# Artefakte für Client generieren
java -cp ../../libs/xmlws/jaxws-tools.jar com.sun.tools.ws.WsImport -Xnocompile -encoding UTF-8 -s contract_first/src -p generated_client http://localhost:8080/ws/TimeService.wsdl

# Aufruf Client
java -cp out/production/contract_first;../../libs/xmlws/* client.TimeServiceClient1
java -DwsdlLocation=http://localhost:8080/ws/TimeService.wsdl -cp out/production/contract_first;../../libs/xmlws/* client.TimeServiceClient2
