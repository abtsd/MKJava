package demo.time;

import generated_server.Time;
import jakarta.jws.WebService;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

@WebService(endpointInterface = "generated_server.Time")
public class TimeServiceImpl implements Time {
    @Override
    public String getTime() {
        return LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS).toString();
    }
}
