package client;

import generated_client.TimeService;

import java.net.MalformedURLException;
import java.net.URL;

public class TimeServiceClient1 {
	public static void main(String[] args) throws MalformedURLException {
		var wsdlLocation = System.getProperty("wsdlLocation");
		var service = wsdlLocation == null ? new TimeService() :
				new TimeService(new URL(wsdlLocation));
		var port = service.getTimeServiceSOAP();
		var time = port.getTime();
		System.out.println(time);
	}
}
