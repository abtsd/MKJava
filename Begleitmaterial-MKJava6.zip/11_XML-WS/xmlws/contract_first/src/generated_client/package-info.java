/**
 * Test Contract First
 * 
 */
@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://time.demo/")
package generated_client;
