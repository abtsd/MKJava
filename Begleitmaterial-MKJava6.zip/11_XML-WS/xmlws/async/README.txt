# Server starten
java --add-opens java.base/java.lang=ALL-UNNAMED -cp out/production/async;../../libs/xmlws/* server.ProductPublisher localhost 8080

# WSDL und XSD abrufen
http://localhost:8080/ws/product
http://localhost:8080/ws/product?wsdl
http://localhost:8080/ws/product?xsd=1

# Artefakte für Client generieren
java -cp ../../libs/xmlws/jaxws-tools.jar com.sun.tools.ws.WsImport -Xnocompile -encoding UTF-8 -s async/src -p generated -b async/async.xml http://localhost:8080/ws/product?wsdl

# Aufruf Client
java -cp out/production/async;../../libs/xmlws/* client.ProductClient

# Aufruf Client für Network-Monitor
java -Dhttp.proxyHost=localhost -Dhttp.proxyPort=8888 -Dhttp.nonProxyHosts= -cp out/production/async;../../libs/xmlws/* client.ProductClient

# Aufruf Client mit Dump
java -Dcom.sun.xml.ws.transport.http.client.HttpTransportPipe.dump=true -cp out/production/async;../../libs/xmlws/* client.ProductClient
