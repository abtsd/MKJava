@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://product.demo/")
package generated;
