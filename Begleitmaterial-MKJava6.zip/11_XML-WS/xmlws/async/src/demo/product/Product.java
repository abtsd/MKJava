package demo.product;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;

@WebService
public interface Product {
	@WebMethod
	boolean isAvailable(@WebParam(name = "id") int id, @WebParam(name = "amount") int amount);
}
