package demo.product;

import jakarta.jws.WebService;

import java.util.Random;

@WebService(endpointInterface = "demo.product.Product")
public class ProductImpl implements Product {
	@Override
	public boolean isAvailable(int id, int amount) {
		var r = new Random();
		var delay = 3 + r.nextInt(6);
		try {
			Thread.sleep(delay * 1000);
		} catch (InterruptedException ignored) {
		}
		return r.nextBoolean();
	}
}
