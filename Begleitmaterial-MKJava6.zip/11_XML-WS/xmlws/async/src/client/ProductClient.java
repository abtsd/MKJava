package client;

import generated.IsAvailableResponse;
import generated.Product;
import generated.ProductImplService;
import jakarta.xml.ws.AsyncHandler;
import jakarta.xml.ws.Response;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.CountDownLatch;

public class ProductClient {
    private final Product port;
    private static final CountDownLatch latch = new CountDownLatch(1);

    public ProductClient() throws MalformedURLException {
        var wsdlLocation = System.getProperty("wsdlLocation");
        var service = wsdlLocation == null ? new ProductImplService() :
                new ProductImplService(new URL(wsdlLocation));
        port = service.getProductImplPort();
    }

    public static void main(String[] args) throws InterruptedException, MalformedURLException {
        var client = new ProductClient();
        client.invokeBlocking();
        client.invokeNonblockingPoll();
        client.invokeNonblockingCallback();
        System.out.println("Warte auf Antwort");
        latch.await();
    }

    private void invokeBlocking() {
        System.out.println("--- blocking ---");
        var isAvailable = port.isAvailable(4711, 10);
        System.out.println("isAvailable: " + isAvailable);
    }

    private void invokeNonblockingPoll() {
        System.out.println("--- nonblocking, polling ---");
        var res = port.isAvailableAsync(4711, 10);

        while (!res.isDone()) {
            System.out.println("Warte auf Antwort");
            try {
                Thread.sleep(1000);
            } catch (InterruptedException ignored) {
            }
        }

        try {
            var response = res.get();
            var isAvailable = response.isReturn();
            System.out.println("isAvailable: " + isAvailable);
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    private void invokeNonblockingCallback() {
        System.out.println("--- nonblocking, callback ---");
        port.isAvailableAsync(4711, 10, new MyHandler());
    }

    private static class MyHandler implements AsyncHandler<IsAvailableResponse> {
        public void handleResponse(Response<IsAvailableResponse> res) {
            try {
                var response = res.get();
                var isAvailable = response.isReturn();
                System.out.println("isAvailable: " + isAvailable);
                latch.countDown();
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
        }
    }
}
