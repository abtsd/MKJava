# Server starten
java --add-opens java.base/java.lang=ALL-UNNAMED -cp out/production/crud;../../libs/xmlws/* server.ArtikelManagerPublisher localhost 8080

# WSDL und XSD abrufen
http://localhost:8080/ws/artikel
http://localhost:8080/ws/artikel?wsdl
http://localhost:8080/ws/artikel?xsd=1

# Artefakte für Client generieren
java -cp ../../libs/xmlws/jaxws-tools.jar com.sun.tools.ws.WsImport -Xnocompile -encoding UTF-8 -s crud/src -p generated http://localhost:8080/ws/artikel?wsdl

# Aufruf Client
java -cp out/production/crud;../../libs/xmlws/* client.ArtikelManagerClient

# Aufruf Client für Network-Monitor
java -Dhttp.proxyHost=localhost -Dhttp.proxyPort=8888 -Dhttp.nonProxyHosts= -cp out/production/crud;../../libs/xmlws/* client.ArtikelManagerClient

# Aufruf Client mit Dump
java -Dcom.sun.xml.ws.transport.http.client.HttpTransportPipe.dump=true -cp out/production/crud;../../libs/xmlws/* client.ArtikelManagerClient

# PowerShell Client
Windows PowerShell Integrated Scripting Environment (ISE):
powershell_ise crud/client.ps1
    oder
powershell crud/client.ps1

Um Skripte in ISE ausführen zu können, PowerShell "Als Administrator ausführen" starten und eingeben:
Set-ExecutionPolicy Unrestricted
Get-ExecutionPolicy
