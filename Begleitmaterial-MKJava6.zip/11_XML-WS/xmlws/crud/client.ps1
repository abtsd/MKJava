$url = "http://localhost:8080/ws/artikel?wsdl"
$proxy = New-WebServiceProxy -Uri $url -Class Artikel -Namespace ws

# $proxy | Get-Member -memberType Method

try {
    "--- Neue Artikel einfuegen"
    for ($i = 0; $i -lt 10; $i++) {
        $artikel = New-Object ws.Artikel
        $artikel.id = 4711 + $i
        $artikel.bezeichnung = "Bezeichnung " + ($i + 1)
        $artikel.preis = 1.99 + $i
        $proxy.createArtikel($artikel)
    }

    "--- Artikel 4715 lesen und aendern"
    $artikel = $proxy.getArtikel(4715)
    "{0,-4} {1,-15} {2,8:N2}" -f $artikel.id, $artikel.bezeichnung, $artikel.preis
    $artikel.preis = 10.0
    $proxy.updateArtikel($artikel)

    "--- Liste aller Artikel"
    $list = $proxy.getArtikelListe()
    foreach ($a in $list) {
        "{0,-4} {1,-15} {2,8:N2}" -f $a.id, $a.bezeichnung, $a.preis
    }

    "--- Artikel 4713 loeschen"
    $proxy.deleteArtikel(4713)

    "--- Artikel 4713 lesen"
    $artikel = $proxy.getArtikel(4713)
    "{0,-4} {1,-15} {2,8:N2}" -f $artikel.id, $artikel.bezeichnung, $artikel.preis
} catch {
    $_.Exception.InnerException
}