
package generated;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java-Klasse für createArtikel complex type.
 * 
 * <p>Das folgende Schemafragment gibt den erwarteten Content an, der in dieser Klasse enthalten ist.
 * 
 * <pre>
 * &lt;complexType name="createArtikel"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="artikel" type="{http://artikel.demo/}artikel" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createArtikel", propOrder = {
    "artikel"
})
public class CreateArtikel {

    protected Artikel artikel;

    /**
     * Ruft den Wert der artikel-Eigenschaft ab.
     * 
     * @return
     *     possible object is
     *     {@link Artikel }
     *     
     */
    public Artikel getArtikel() {
        return artikel;
    }

    /**
     * Legt den Wert der artikel-Eigenschaft fest.
     * 
     * @param value
     *     allowed object is
     *     {@link Artikel }
     *     
     */
    public void setArtikel(Artikel value) {
        this.artikel = value;
    }

}
