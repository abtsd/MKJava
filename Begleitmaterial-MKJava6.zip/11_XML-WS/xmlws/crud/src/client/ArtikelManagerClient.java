package client;

import generated.Artikel;
import generated.ArtikelManagerImplService;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

public class ArtikelManagerClient {
    public static void main(String[] args) throws MalformedURLException {
        var wsdlLocation = System.getProperty("wsdlLocation");
        var service = wsdlLocation == null ? new ArtikelManagerImplService() :
                new ArtikelManagerImplService(new URL(wsdlLocation));
        var port = service.getArtikelManagerImplPort();

        try {
            System.out.println("--- Neue Artikel einfügen");
            for (int i = 0; i < 10; i++) {
                var artikel = new Artikel();
                artikel.setId(4711 + i);
                artikel.setBezeichnung("Bezeichnung " + (i + 1));
                artikel.setPreis(1.99 + i);
                port.createArtikel(artikel);
            }

            System.out.println("--- Artikel 4715 lesen und ändern");
            var artikel = port.getArtikel(4715);
            print(artikel);
            artikel.setPreis(10.);
            port.updateArtikel(artikel);

            System.out.println("--- Liste aller Artikel");
            printList(port.getArtikelListe());

            System.out.println("--- Artikel 4713 löschen");
            port.deleteArtikel(4713);

            System.out.println("--- Artikel 4713 lesen");
            artikel = port.getArtikel(4713);
            print(artikel);
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    private static void print(Artikel artikel) {
        System.out.println(artikel.getId() + " " + artikel.getBezeichnung() + " " + artikel.getPreis());
    }

    private static void printList(List<Artikel> list) {
        for (var a : list) {
            print(a);
        }
    }
}
