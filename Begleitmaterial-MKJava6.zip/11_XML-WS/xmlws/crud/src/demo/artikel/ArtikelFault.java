package demo.artikel;

public class ArtikelFault extends Exception {
	public ArtikelFault() {
	}

	public ArtikelFault(String msg) {
		super(msg);
	}
}
