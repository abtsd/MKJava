package demo.artikel;

import jakarta.jws.WebService;

import java.util.*;
import java.util.stream.Collectors;

@WebService(endpointInterface = "demo.artikel.ArtikelManager")
public class ArtikelManagerImpl implements ArtikelManager {
	private final Map<Integer, Artikel> map = new Hashtable<>();

	@Override
	public void createArtikel(Artikel artikel) throws ArtikelFault {
		var id = artikel.getId();
		if (map.get(id) == null) {
			map.put(id, artikel);
		} else
			throw new ArtikelFault("Artikel " + id + " bereits vorhanden");
	}

	@Override
	public Artikel getArtikel(int id) throws ArtikelFault {
		var artikel = map.get(id);
		if (artikel == null)
			throw new ArtikelFault("Artikel " + id + " nicht vorhanden");
		return artikel;
	}

	@Override
	public List<Artikel> getArtikelListe() {
		return map.values()
				.stream()
				.sorted(Comparator.comparingInt(Artikel::getId))
				.collect(Collectors.toList());
	}

	@Override
	public void updateArtikel(Artikel artikel) throws ArtikelFault {
		var id = artikel.getId();
		if (map.get(id) == null)
			throw new ArtikelFault("Artikel " + id + " nicht vorhanden");
		else
			map.put(id, artikel);
	}

	@Override
	public void deleteArtikel(int id) throws ArtikelFault {
		if (map.get(id) == null)
			throw new ArtikelFault("Artikel " + id + " nicht vorhanden");
		else
			map.remove(id);
	}
}
