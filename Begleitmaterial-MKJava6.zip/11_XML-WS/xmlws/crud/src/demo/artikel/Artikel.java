package demo.artikel;

import jakarta.xml.bind.annotation.XmlType;

@XmlType(propOrder = { "id", "bezeichnung", "preis" })
public class Artikel {
	private int id;
	private String bezeichnung;
	private double preis;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBezeichnung() {
		return bezeichnung;
	}

	public void setBezeichnung(String bezeichnung) {
		this.bezeichnung = bezeichnung;
	}

	public double getPreis() {
		return preis;
	}

	public void setPreis(double preis) {
		this.preis = preis;
	}
}
