package demo.artikel;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;

import java.util.List;

@WebService
public interface ArtikelManager {
	@WebMethod
	void createArtikel(@WebParam(name = "artikel") Artikel artikel) throws ArtikelFault;

	@WebMethod
	Artikel getArtikel(@WebParam(name = "id") int id) throws ArtikelFault;

	@WebMethod
	List<Artikel> getArtikelListe();

	@WebMethod
	void updateArtikel(@WebParam(name = "artikel") Artikel artikel) throws ArtikelFault;
	
	@WebMethod
	void deleteArtikel(@WebParam(name = "id") int id) throws ArtikelFault;
}
