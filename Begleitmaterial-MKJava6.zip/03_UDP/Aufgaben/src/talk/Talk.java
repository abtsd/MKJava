package talk;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class Talk extends Application implements Runnable {
	private static final int BUFSIZE = 508;

	private String user;
	private int localPort = 50000;
	private String remoteHost;
	private int remotePort = 50000;

	private DatagramSocket socket;
	private DatagramPacket packetOut;

	private TextArea ta;
	private TextField tf;

	@Override
	public void init() {
		var map = getParameters().getNamed();

		try {
			if (map.containsKey("user"))
				user = map.get("user");
			if (map.containsKey("remoteHost"))
				remoteHost = map.get("remoteHost");
			if (map.containsKey("localPort"))
				localPort = Integer.parseInt(map.get("localPort"));
			if (map.containsKey("remotePort"))
				remotePort = Integer.parseInt(map.get("remotePort"));
		} catch (NumberFormatException e) {
			System.err.println("Portnummer nicht numerisch");
			Platform.exit();
		}

		if (user == null || remoteHost == null) {
			System.err.println("user bzw. remoteHost fehlt");
			Platform.exit();
		}
	}

	@Override
	public void start(Stage stage) {
		var box = new VBox();
		ta = new TextArea();
		tf = new TextField();
		box.getChildren().addAll(ta, tf);

		ta.setWrapText(true);
		ta.setStyle("-fx-font: 16pt \"Arial\";");
		ta.setEditable(false);
		ta.setPrefHeight(500);

		tf.setStyle("-fx-font: 16pt \"Arial\";");
		tf.setOnAction((event) -> send());

		stage.setScene(new Scene(box, 800, 500));
		stage.setTitle("Talk - " + user);
		stage.show();

		try {
			var remoteAddr = InetAddress.getByName(remoteHost);
			socket = new DatagramSocket(localPort);
			packetOut = new DatagramPacket(new byte[BUFSIZE], BUFSIZE, remoteAddr, remotePort);
		} catch (Exception e) {
			ta.setText(e.toString());
		}

		var t = new Thread(this);
		t.start();
	}

	@Override
	public void stop() throws Exception {
		if (socket != null)
			socket.close();
	}

	@Override
	public void run() {
		var packetIn = new DatagramPacket(new byte[BUFSIZE], BUFSIZE);
		while (true) {
			try {
				receive(packetIn);
			} catch (IOException e) {
				break;
			}
		}
	}

	private void send() {
		try {
			var message = user + ": " + tf.getText();
			var data = message.getBytes();
			packetOut.setData(data);
			packetOut.setLength(data.length);
			socket.send(packetOut);
			tf.setText("");
			tf.requestFocus();
		} catch (IOException e) {
			System.err.println(e);
		}
	}

	private void receive(DatagramPacket packetIn) throws IOException {
		socket.receive(packetIn);
		var text = new String(packetIn.getData(), 0, packetIn.getLength());
		Platform.runLater(() -> {
			ta.appendText(text);
			ta.appendText("\n");
		});
	}

	public static void main(String[] args) {
		launch(args);
	}
}
