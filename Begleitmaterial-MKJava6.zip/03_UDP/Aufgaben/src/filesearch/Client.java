package filesearch;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;

public class Client {
	private static final String MCAST_ADDR = "228.5.6.7";
	private static final int PORT = 50000;
	private static final int BUFSIZE = 508;
	private static final int TIMEOUT = 10000;

	public static void main(String[] args) {
		var id = args[0];

		try (var socket = new DatagramSocket()) {
			socket.setSoTimeout(TIMEOUT);

			var data = id.getBytes();
			var addr = InetAddress.getByName(MCAST_ADDR);
			var packetOut = new DatagramPacket(data, data.length, addr, PORT);
			socket.send(packetOut);

			var packetIn = new DatagramPacket(new byte[BUFSIZE], BUFSIZE);
			socket.receive(packetIn);

			var received = new String(packetIn.getData(), 0, packetIn.getLength());
			System.out.println(received);
		} catch (SocketTimeoutException e) {
			System.err.println("Timeout: " + e.getMessage());
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}
}
