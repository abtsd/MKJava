package filesearch;

import java.net.*;
import java.util.HashMap;
import java.util.Map;

public class Server {
	private static final String MCAST_ADDR = "228.5.6.7";
	private static final int PORT = 50000;
	private static final int BUFSIZE = 508;

	private final Map<String, String> map;
	private final String name;

	public Server(String name, int von, int bis) {
		this.name = name;
		map = new HashMap<>();
		for (var i = von; i <= bis; i++) {
			map.put(String.valueOf(i), "Datei " + i);
		}
	}

	public void start() {
		System.out.println("Server " + name + " gestartet ...");
		
		try (var socket = new MulticastSocket(PORT)) {
			socket.setTimeToLive(1);
			var inetSocketAddress = new InetSocketAddress(MCAST_ADDR, 50000);
			var netif = NetworkInterface.getByInetAddress(InetAddress.getLocalHost());
			socket.joinGroup(inetSocketAddress, netif);

			var packetIn = new DatagramPacket(new byte[BUFSIZE], BUFSIZE);
			var packetOut = new DatagramPacket(new byte[BUFSIZE], BUFSIZE);

			while (true) {
				socket.receive(packetIn);
				String received = new String(packetIn.getData(), 0, packetIn.getLength());

				var value = map.get(received);

				if (value != null) {
					value += " auf Server " + name + " vorhanden.";
					var data = value.getBytes();
					packetOut.setData(data);
					packetOut.setLength(data.length);
					packetOut.setSocketAddress(packetIn.getSocketAddress());
					socket.send(packetOut);
				}
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}

	public static void main(String[] args) {
		var name = args[0];
		var von = Integer.parseInt(args[1]);
		var bis = Integer.parseInt(args[2]);

		var server = new Server(name, von, bis);
		server.start();
	}
}
