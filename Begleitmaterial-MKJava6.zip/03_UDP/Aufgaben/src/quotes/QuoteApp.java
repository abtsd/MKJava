package quotes;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class QuoteApp extends Application {
	private String host = "localhost";
	private final int port = 50000;
	private TextArea ta;
	private TextField tf;
	private Thread t;

	@Override
	public void start(Stage stage) {
		var box = new VBox();
		ta = new TextArea();
		tf = new TextField();
		box.getChildren().addAll(ta, tf);

		ta.setWrapText(true);
		ta.setStyle("-fx-font: 20pt \"Arial\";-fx-text-fill: red;");
		ta.setEditable(false);

		tf.setStyle("-fx-font: italic 16pt \"Arial\";");
		tf.setEditable(false);

		stage.setScene(new Scene(box, 700, 200));
		stage.setTitle("QuoteApp");
		stage.show();

		var params = getParameters().getRaw();
		if (!params.isEmpty())
			host = params.get(0);

		t = new Thread(() -> {
			try {
				var client = new QuoteClient(host, port);

				while (true) {
					var quote = client.getQuote();
					Platform.runLater(() -> {
						ta.setText(quote.getText());
						tf.setText(quote.getAuthor());
					});
					Thread.sleep(8000);
				}
			} catch (Exception e) {
				Platform.runLater(() -> ta.setText(e.toString()));
			}
		});

		t.start();
	}

	@Override
	public void stop() {
		t.interrupt();
	}

	public static void main(String[] args) {
		launch(args);
	}
}
