# Die Umgebungsvariable PATH_TO_FX zeigt auf das Verzeichnis lib der JavaFX-Installation.

java -Dfile.encoding=UTF-8 -cp out/production/Aufgaben;../../libs/json/* quotes.QuoteServer
# Zur Ausgabe von Sonderzeichen bei Windows: chcp 1252
java -Dfile.encoding=UTF-8 -cp out/production/Aufgaben;../../libs/json/* quotes.QuoteClient localhost
java -Dfile.encoding=UTF-8 -cp out/production/Aufgaben;../../libs/json/* -p %PATH_TO_FX% --add-modules=javafx.controls quotes.QuoteApp localhost

java -Dfile.encoding=UTF-8 -cp out/production/Aufgaben -p %PATH_TO_FX% --add-modules=javafx.controls talk.Talk --user=Hugo --localPort=40000 --remoteHost=localhost --remotePort=50000
java -Dfile.encoding=UTF-8 -cp out/production/Aufgaben -p %PATH_TO_FX% --add-modules=javafx.controls talk.Talk --user=Emil --localPort=50000 --remoteHost=localhost --remotePort=40000

java -Dfile.encoding=UTF-8 -cp out/production/Aufgaben -p %PATH_TO_FX% --add-modules=javafx.controls talk.Talk --user=Hugo --remoteHost=192.168.2.91
java -Dfile.encoding=UTF-8 -cp out/production/Aufgaben -p %PATH_TO_FX% --add-modules=javafx.controls talk.Talk --user=Emil --remoteHost=192.168.2.99

java -cp out/production/Aufgaben filesearch.Server A 1 10
java -cp out/production/Aufgaben filesearch.Server B 11 20
java -cp out/production/Aufgaben filesearch.Client 15
