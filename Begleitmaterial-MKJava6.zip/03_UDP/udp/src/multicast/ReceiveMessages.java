package multicast;

import jakarta.json.bind.JsonbBuilder;

import java.io.IOException;
import java.net.*;
import java.time.LocalDateTime;

public class ReceiveMessages {
    private static final int BUFSIZE = 508;

    public static void main(String[] args) {
        var multicastAddress = "228.5.6.7";
        var port = 50000;

        try (var socket = new MulticastSocket(port)) {
            socket.setTimeToLive(1);
            var inetSocketAddress = new InetSocketAddress(multicastAddress, 50000);
            var netif = NetworkInterface.getByInetAddress(InetAddress.getLocalHost());
            socket.joinGroup(inetSocketAddress, netif);

            var packet = new DatagramPacket(new byte[BUFSIZE], BUFSIZE);

            System.out.println("Receiver gestartet: " + LocalDateTime.now());

            while (true) {
                socket.receive(packet);
                var data = new String(packet.getData(), 0, packet.getLength());
                var message = deserialize(data);
                System.out.println(message);
            }
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }

    private static Message deserialize(String data) {
        var jsonb = JsonbBuilder.create();
        return jsonb.fromJson(data, Message.class);
    }
}
