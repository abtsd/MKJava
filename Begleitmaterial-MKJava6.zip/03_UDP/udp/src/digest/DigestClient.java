package digest;

import jakarta.json.bind.JsonbBuilder;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;

public class DigestClient {
	private static final int BUFSIZE = 508;
	private static final int TIMEOUT = 10000;

	public static void main(String[] args) {
		var host = args[0];
		var text = args[1];
		var localPort = 40000;
		var port = 50000;

		try (var socket = new DatagramSocket(localPort)) {
			// Maximal TIMEOUT Millisekunden auf Antwort warten
			socket.setSoTimeout(TIMEOUT);

			var data = serialize(new Digest(text)).getBytes();

			// Paket an Server senden
			var addr = InetAddress.getByName(host);
			var packetOut = new DatagramPacket(data, data.length, addr, port);
			socket.send(packetOut);

			// Antwortpaket empfangen
			var packetIn = new DatagramPacket(new byte[BUFSIZE], BUFSIZE);
			socket.receive(packetIn);

			var json = new String(packetIn.getData(), 0, packetIn.getLength());
			var digest = deserialize(json);
			System.out.println(digest.getText());
			System.out.println(digest.getHashValue());
		} catch (SocketTimeoutException e) {
			System.err.println("Timeout: " + e.getMessage());
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}

	private static Digest deserialize(String data) {
		var jsonb = JsonbBuilder.create();
		return jsonb.fromJson(data, Digest.class);
	}

	private static String serialize(Digest digest) {
		var jsonb = JsonbBuilder.create();
		return jsonb.toJson(digest);
	}
}
