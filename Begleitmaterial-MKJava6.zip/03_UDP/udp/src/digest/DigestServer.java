package digest;

import jakarta.json.bind.JsonbBuilder;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class DigestServer {
	private static final int BUFSIZE = 508;

	public static void main(String[] args) {
		var clientHost = args[0];
		var port = 50000;
		var clientPort = 40000;

		try (var socket = new DatagramSocket(port)) {
			// Es werden nur Datagramme dieser Adresse entgegengenommen
			socket.connect(InetAddress.getByName(clientHost), clientPort);

			// Pakete zum Empfangen bzw. Senden
			var packetIn = new DatagramPacket(new byte[BUFSIZE], BUFSIZE);
			var packetOut = new DatagramPacket(new byte[BUFSIZE], BUFSIZE);

			System.out.println("Server gestartet ...");

			while (true) {
				// Paket empfangen
				socket.receive(packetIn);
				System.out.println("Received: " + packetIn.getLength() + " bytes");

				var json = new String(packetIn.getData(), 0, packetIn.getLength());

				var digest = deserialize(json);
				var hashValue = digest(digest.getText());
				digest.setHashValue(hashValue);

				var data = serialize(digest).getBytes();

				// Daten und Länge im Antwortpaket speichern
				packetOut.setData(data);
				packetOut.setLength(data.length);

				// Zieladresse und Zielport im Antwortpaket setzen
				packetOut.setSocketAddress(packetIn.getSocketAddress());

				// Antwortpaket senden
				socket.send(packetOut);
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}

	private static Digest deserialize(String data) {
		var jsonb = JsonbBuilder.create();
		return jsonb.fromJson(data, Digest.class);
	}

	private static String serialize(Digest digest) {
		var jsonb = JsonbBuilder.create();
		return jsonb.toJson(digest);
	}

	private static String digest(String data) throws NoSuchAlgorithmException {
		var md = MessageDigest.getInstance("SHA-256");
		md.update(data.getBytes());
		var digest = md.digest();
		var sb = new StringBuilder();
		for (var b : digest) {
			sb.append(String.format("%02x", b));
		}
		return sb.toString();
	}
}
