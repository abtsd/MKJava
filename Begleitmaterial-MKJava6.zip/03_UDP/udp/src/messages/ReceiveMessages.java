package messages;

import jakarta.json.bind.JsonbBuilder;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

public class ReceiveMessages {
    private static final int BUFSIZE = 508;

    public static void main(String[] args) {
        int port = 50000;

        try (var socket = new DatagramSocket(port)) {
            var packet = new DatagramPacket(new byte[BUFSIZE], BUFSIZE);
            while (true) {
                socket.receive(packet);
                var data = new String(packet.getData(), 0, packet.getLength());
                var message = deserialize(data);
                System.out.println(message);
            }
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }

    private static Message deserialize(String data) {
        var jsonb = JsonbBuilder.create();
        return jsonb.fromJson(data, Message.class);
    }
}
