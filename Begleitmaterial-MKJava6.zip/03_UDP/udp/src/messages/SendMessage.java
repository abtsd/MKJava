package messages;

import jakarta.json.bind.JsonbBuilder;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.time.LocalDateTime;

public class SendMessage {
    private static final int BUFSIZE = 508;

    public static void main(String[] args) throws Exception {
        var host = args[0];
        var user = args[1];
        var text = args[2];
        var port = 50000;

        var message = createMessage(user, text);
        try (var socket = new DatagramSocket()) {
            var addr = InetAddress.getByName(host);
            var packet = new DatagramPacket(new byte[BUFSIZE], BUFSIZE, addr, port);
            var data = message.getBytes();
            packet.setData(data);
            packet.setLength(data.length);
            socket.send(packet);
        }
    }

    private static String createMessage(String user, String text) {
        var msg = new Message(user, LocalDateTime.now(), text);
        var jsonb = JsonbBuilder.create();
        return jsonb.toJson(msg);
    }
}
