# Zur Ausgabe von Sonderzeichen bei Windows: chcp 1252
java -cp out/production/udp;../../libs/json/* messages.ReceiveMessages
java -cp out/production/udp;../../libs/json/* messages.SendMessage localhost Hugo "Das ist ein Test."

java -cp out/production/udp;../../libs/json/* digest.DigestServer localhost
java -cp out/production/udp;../../libs/json/* digest.DigestClient localhost "Das ist ein Test."

# Zur Ausgabe von Sonderzeichen bei Windows: chcp 1252
java -cp out/production/udp;../../libs/json/* multicast.ReceiveMessages
java -cp out/production/udp;../../libs/json/* multicast.SendMessage Hugo "Das ist ein Test."
