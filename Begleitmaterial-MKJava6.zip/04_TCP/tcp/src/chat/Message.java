package chat;

public class Message {
	public enum Action {
		LOGIN, JOIN, LEAVE, SAY, JOIN_ERROR
	}

	public Action action;
	public String user;
	public String text;
}
