package chat;

import jakarta.json.bind.Jsonb;
import jakarta.json.bind.JsonbBuilder;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.*;
import java.net.Socket;

public class ChatClient extends Application implements Runnable {
    private String host = "localhost";
    private final int port = 50000;

    private TextArea ta;
    private TextField tf;
    private Button btn;
    private boolean loggedIn;
    private String user;
    private Socket socket;
    private BufferedReader in;
    private BufferedWriter out;
    private Stage stage;
    private volatile Thread t;
    private Jsonb jsonb;

    @Override
    public void start(Stage stage) {
        this.stage = stage;

        var box = new VBox();
        ta = new TextArea();
        tf = new TextField();
        btn = new Button("Anmelden");

        box.getChildren().addAll(ta, tf, btn);

        ta.setWrapText(true);
        ta.setStyle("-fx-font: 16pt \"Arial\";");
        ta.setEditable(false);
        ta.setPrefHeight(500);

        tf.setStyle("-fx-font: 16pt \"Arial\";");
        tf.setOnAction(event -> {
            if (loggedIn)
                say();
        });

        btn.setStyle("-fx-font: 16pt \"Arial\";");
        btn.setOnAction(event -> btnAction());

        stage.setScene(new Scene(box, 800, 500));
        stage.setTitle("Chat");
        stage.show();

        jsonb = JsonbBuilder.create();
        var params = getParameters().getRaw();
        if (!params.isEmpty())
            host = params.get(0);
    }

    @Override
    public void stop() throws Exception {
        logout();
    }

    private void btnAction() {
        if (loggedIn) {
            logout();
        } else {
            user = tf.getText();
            if (user.length() != 0) {
                login();
            }
        }
    }

    private void login() {
        try {
            socket = new Socket(host, port);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));

            send(Message.Action.LOGIN, user, "");

            t = new Thread(this);
            t.start();
        } catch (IOException e) {
            ta.appendText(e.getMessage() + "\n");
            logout();
        } finally {
            tf.setText("");
            tf.requestFocus();
        }
    }

    private void logout() {
        try {
            loggedIn = false;
            stage.setTitle("Chat");
            btn.setText("Anmelden");
            t = null;
            if (socket != null)
                socket.close();
            if (in != null)
                in.close();
            if (out != null)
                out.close();
        } catch (IOException ignored) {
        }
    }

    private void say() {
        try {
            send(Message.Action.SAY, user, tf.getText());
        } catch (IOException e) {
            ta.appendText(e.getMessage() + "\n");
            logout();
        } finally {
            tf.setText("");
            tf.requestFocus();
        }
    }

    private void send(Message.Action action, String user, String text) throws IOException {
        var message = new Message();
        message.action = action;
        message.user = user;
        message.text = text;
        var jsonStr = jsonb.toJson(message);

        out.write(jsonStr);
        out.newLine();
        out.flush();
    }

    @Override
    public void run() {
        try {
            while (Thread.currentThread() == t) {
                var line = in.readLine();
                if (line == null)
                    break;

                var message = jsonb.fromJson(line, Message.class);
                var msg = "";
                switch (message.action) {
                    case JOIN:
                        Platform.runLater(() -> {
                            loggedIn = true;
                            stage.setTitle("Chat - " + user);
                            btn.setText("Abmelden");
                        });
                        msg = message.user + " ist angemeldet.";
                        break;
                    case JOIN_ERROR:
                        msg = message.user + " ist bereits angemeldet.";
                        break;
                    case LEAVE:
                        msg = message.user + " ist abgemeldet.";
                        break;
                    case SAY:
                        msg = message.user + ": " + message.text;
                        break;
                }

                var output = msg;
                Platform.runLater(() -> {
                    ta.appendText(output);
                    ta.appendText("\n");
                });
            }
        } catch (IOException ignored) {
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
