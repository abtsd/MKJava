package chat;

import jakarta.json.bind.Jsonb;
import jakarta.json.bind.JsonbBuilder;
import tcpframework.AbstractHandler;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class ChatHandler extends AbstractHandler {
    private final static int TIMEOUT = 600000; // 10 Min.
    private final List<PrintWriter> connections;
    private final List<String> users;
    private final Jsonb jsonb;

    public ChatHandler() {
        connections = new CopyOnWriteArrayList<>();
        users = new CopyOnWriteArrayList<>();
        jsonb = JsonbBuilder.create();
    }

    @Override
    public void runTask(Socket socket) {
        String user = null;
        PrintWriter out = null;
        var joined = false;

        try (socket) {
            socket.setSoTimeout(TIMEOUT);
            var in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            var line = "";
            while ((line = in.readLine()) != null) {
                var message = jsonb.fromJson(line, Message.class);
                switch (message.action) {
                    case LOGIN:
                        user = message.user;
                        joined = join(user, out);
                        break;
                    case SAY:
                        say(user, message.text, out);
                        break;
                }
            }
        } catch (IOException e) {
            System.err.println(e.getMessage());
        } finally {
            if (joined)
                leave(user, out);
        }
    }

    private boolean join(String user, PrintWriter out) {
        if (users.contains(user)) {
            var message = new Message();
            message.action = Message.Action.JOIN_ERROR;
            message.user = user;
            var jsonStr = jsonb.toJson(message);
            out.println(jsonStr);
            out.close();
            return false;
        } else {
            connections.add(out);
            users.add(user);
            var message = new Message();
            message.action = Message.Action.JOIN;
            message.user = user;
            broadcast(message);
            System.out.println("Anzahl Verbindungen: " + connections.size());
            System.out.println("Angemeldete User: " + users);
            return true;
        }
    }

    private void leave(String user, PrintWriter out) {
        connections.remove(out);
        users.remove(user);
        var message = new Message();
        message.action = Message.Action.LEAVE;
        message.user = user;
        broadcast(message);
        System.out.println("Anzahl Verbindungen: " + connections.size());
        System.out.println("Angemeldete User: " + users);
    }

    private void say(String user, String text, PrintWriter out) {
        var message = new Message();
        message.action = Message.Action.SAY;
        message.user = user;
        message.text = text;
        broadcast(message);
    }

    private void broadcast(Message message) {
        var jsonStr = jsonb.toJson(message);
        for (var out : connections) {
            out.println(jsonStr);
        }
    }
}
