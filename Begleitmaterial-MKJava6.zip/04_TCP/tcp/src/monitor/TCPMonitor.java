package monitor;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class TCPMonitor {
    private static String destination_host;
    public static int destination_port;
    private static OutputStream logRequest;
    private static OutputStream logResponse;
    private static ServerSocket serverSocket;

    private static class ClientThread extends Thread {
        private final Socket clientSocket;
        private Socket serverSocket;

        public ClientThread(Socket clientSocket) {
            this.clientSocket = clientSocket;
        }

        public void run() {
            InputStream clientIn;
            OutputStream clientOut;
            InputStream serverIn;
            OutputStream serverOut;

            try {
                serverSocket = new Socket(destination_host, destination_port);
                clientIn = clientSocket.getInputStream();
                clientOut = clientSocket.getOutputStream();
                serverIn = serverSocket.getInputStream();
                serverOut = serverSocket.getOutputStream();
            } catch (IOException e) {
                System.err.println(e.getMessage());
                close();
                return;
            }

            var clientForward = new ForwardThread(this, clientIn, serverOut, logRequest);
            clientForward.start();
            var serverForward = new ForwardThread(this, serverIn, clientOut, logResponse);
            serverForward.start();
        }

        public void close() {
            try {
                serverSocket.close();
            } catch (Exception ignored) {
            }
            try {
                clientSocket.close();
            } catch (Exception ignored) {
            }
        }
    }

    private static class ForwardThread extends Thread {
        private static final int BUFFER_SIZE = 8192;
        private final InputStream inputStream;
        private final OutputStream outputStream;
        private final ClientThread clientThread;
        private final OutputStream log;

        public ForwardThread(ClientThread clientThread, InputStream inputStream,
                             OutputStream outputStream, OutputStream log) {
            this.clientThread = clientThread;
            this.inputStream = inputStream;
            this.outputStream = outputStream;
            this.log = log;
        }

        public void run() {
            var buffer = new byte[BUFFER_SIZE];
            try {
                var bytesRead = 0;
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead);
                    outputStream.flush();
                    log.write(buffer, 0, bytesRead);
                    log.flush();
                }
            } catch (IOException ignored) {
            }

            clientThread.close();
        }
    }

    public static void main(String[] args) {
        var source_port = Integer.parseInt(args[0]);
        destination_host = args[1];
        destination_port = Integer.parseInt(args[2]);
        var request = args[3];
        var response = args[4];

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                if (logRequest != null) {
                    logRequest.close();
                }
                if (logResponse != null) {
                    logResponse.close();
                }
                if (serverSocket != null)
                    serverSocket.close();
            } catch (IOException ignored) {
            }
        }));

        try {
            logRequest = new FileOutputStream(request);
            logResponse = new FileOutputStream(response);
            var serverSocket = new ServerSocket(source_port);

            System.out.println("Stoppen mit Strg + C");

            while (true) {
                var clientSocket = serverSocket.accept();
                new ClientThread(clientSocket).start();
            }
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }
}
