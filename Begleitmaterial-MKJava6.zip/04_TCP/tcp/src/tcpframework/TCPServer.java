package tcpframework;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.SocketException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TCPServer extends Thread {
    private final AbstractHandler handler;
    private final ServerSocket serverSocket;
    private final ExecutorService pool;

    public TCPServer(int port, Class<?> handlerClass) throws Exception {
        handler = (AbstractHandler) handlerClass.getDeclaredConstructor().newInstance();
        serverSocket = new ServerSocket(port);
        pool = Executors.newCachedThreadPool();
    }

    public TCPServer(int port, AbstractHandler handlerObject) throws IOException {
        handler = handlerObject;
        serverSocket = new ServerSocket(port);
        pool = Executors.newCachedThreadPool();
    }

    public void run() {
        try {
            while (true) {
                var socket = serverSocket.accept();
                handler.handle(socket, pool);
            }
        } catch (SocketException ignored) {
            // Beim Aufruf von stopServer() wird eine SocketException ausgelöst
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public void stopServer() {
        try {
            serverSocket.close();
        } catch (IOException ignored) {
        }
        pool.shutdown();
    }
}
