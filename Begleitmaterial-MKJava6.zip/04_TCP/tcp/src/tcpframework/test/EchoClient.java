package tcpframework.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

public class EchoClient {
    public static void main(String[] args) {
        var host = args[0];
        var port = Integer.parseInt(args[1]);

        try (var socket = new Socket(host, port);
             var in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
             var out = new PrintWriter(socket.getOutputStream(), true, StandardCharsets.UTF_8);
             var input = new BufferedReader(new InputStreamReader(System.in))) {

            var msg = in.readLine();
            if (msg != null)
                System.out.println(msg);

            var line = "";
            while (true) {
                System.out.print("> ");
                line = input.readLine();
                if (line.equals("q"))
                    break;

                out.println(line);
                var response = in.readLine();
                if (response == null)
                    break;
                System.out.println(response);
            }
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }
}
