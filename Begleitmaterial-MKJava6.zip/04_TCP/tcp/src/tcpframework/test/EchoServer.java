package tcpframework.test;

import tcpframework.TCPServer;

public class EchoServer {
	public static void main(String[] args) throws Exception {
		var port = Integer.parseInt(args[0]);

		var server = new TCPServer(port, EchoHandler.class);
		server.start();

		System.out.println("Stoppen mit ENTER");

		System.in.read();
		server.stopServer();
		System.out.println("EchoServer gestoppt.");
	}
}

