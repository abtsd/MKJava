package info;

import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.SocketAddress;
import java.util.HashMap;
import java.util.Map;

public class InfoServer1 {
    private final int port;
    private Map<Integer, Artikel> map;

    public InfoServer1(int port) {
        this.port = port;
        load();
    }

    public void startServer() {
        try (var serverSocket = new ServerSocket(port)) {
            System.out.println("InfoServer1 gestartet ...");
            process(serverSocket);
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }

    private void process(ServerSocket serverSocket) throws IOException {
        while (true) {
            SocketAddress socketAddress = null;

            try (var socket = serverSocket.accept();
                 var out = new ObjectOutputStream(socket.getOutputStream());
                 var in = new ObjectInputStream(socket.getInputStream())) {

                socketAddress = socket.getRemoteSocketAddress();
                System.out.println("Verbindung zu " + socketAddress + " hergestellt");

                out.flush();

                while (true) {
                    var id = in.readInt();
                    var artikel = map.get(id);
                    out.writeObject(artikel);
                    out.flush();
                }
            } catch (EOFException ignored) {
            } catch (IOException e) {
                System.err.println(e.getMessage());
            } finally {
                System.out.println("Verbindung zu " + socketAddress + " beendet");
            }
        }
    }

    private void load() {
        map = new HashMap<>();
        map.put(4711, new Artikel(4711, "Hammer", 2.99));
        map.put(4712, new Artikel(4712, "Zange", 3.99));
        map.put(4713, new Artikel(4713, "Schraubendreher", 1.50));
    }

    public static void main(String[] args) {
        new InfoServer1(50000).startServer();
    }
}
