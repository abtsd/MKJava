package pool;

import jakarta.json.bind.JsonbBuilder;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class InfoClient {
	public static void main(String[] args) {
		var host = args[0];
		var port = 50000;

		try (var socket = new Socket(host, port);
			 var in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			 var out = new PrintWriter(socket.getOutputStream(), true)) {

			var scanner = new Scanner(System.in);
			while (true) {
				System.out.print("> ");
				var id = 0;
				try {
					id = Integer.parseInt(scanner.next());
				} catch (NumberFormatException e) {
					continue;
				}
				if (id == 0)
					break;
				out.println(id);

				var artikel = deserialize(in.readLine());
				if (artikel.getId() == 0)
					System.out.println("Artikel " + id + " nicht vorhanden");
				else
					System.out.println(artikel);
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}

	private static Artikel deserialize(String data) {
		var jsonb = JsonbBuilder.create();
		return jsonb.fromJson(data, Artikel.class);
	}
}
