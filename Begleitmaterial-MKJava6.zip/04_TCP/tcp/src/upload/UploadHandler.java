package upload;

import tcpframework.AbstractHandler;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;

public class UploadHandler extends AbstractHandler {
	private final String dir;

	public UploadHandler(String dir) {
		this.dir = dir;
	}

	@Override
	public void runTask(Socket socket) {
		try (var in = socket.getInputStream();
			 var out = new PrintWriter(socket.getOutputStream(), true)) {

			var builder = new StringBuilder();
			var c = 0;
			while ((c = in.read()) != '\n') {
				builder.append((char) c);
			}
			var filename = builder.toString();
			var file = new File(dir, filename);

			var message = "";
			try (var os = new FileOutputStream(file)) {
				var buffer = new byte[8192];
				while ((c = in.read(buffer)) != -1) {
					os.write(buffer, 0, c);
				}
				message = "Die Datei '" + filename + "' wurde in '" + dir + "' gespeichert.";
			} catch (IOException e) {
				System.err.println(e.getMessage());
				message = e.getMessage();
			}

			out.println(message);
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}
	}
}
