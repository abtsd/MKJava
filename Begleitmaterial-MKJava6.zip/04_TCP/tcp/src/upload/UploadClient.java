package upload;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.net.Socket;

public class UploadClient {
	public static void main(String[] args) {
		var host = args[0];
		var port = 50000;
		var filename = "test.pdf";

		try (var socket = new Socket(host, port);
			 var in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			 var out = socket.getOutputStream()) {

			out.write(filename.getBytes());
			out.write('\n');

			try (var is = new FileInputStream(filename)) {
				var buffer = new byte[1024];
				var c = 0;
				while ((c = is.read(buffer)) != -1) {
					out.write(buffer, 0, c);
				}
				System.out.println(filename + " wurde hochgeladen.");
			}

			socket.shutdownOutput();

			var msg = in.readLine();
			System.out.println(msg);
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}
}
