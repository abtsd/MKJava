package upload;

import tcpframework.TCPServer;

public class UploadServer {
	public static void main(String[] args) throws Exception {
		var port = 50000;
		var dir = "tmp";

		var server = new TCPServer(port, new UploadHandler(dir));
		server.start();

		System.out.println("Stoppen mit ENTER");
		System.in.read();
		server.stopServer();
	}
}
