package forwarding;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class ForwardServer {
    private static String destination_host;
    public static int destination_port;

    private static class ClientThread extends Thread {
        private final Socket clientSocket;
        private Socket serverSocket;

        public ClientThread(Socket clientSocket) {
            this.clientSocket = clientSocket;
        }

        public void run() {
            InputStream clientIn;
            OutputStream clientOut;
            InputStream serverIn;
            OutputStream serverOut;

            // Verbindung zum Ziel-Server herstellen.
            // Streams zwischen Client und Server bereitstellen.
            try {
                serverSocket = new Socket(destination_host, destination_port);
                clientIn = clientSocket.getInputStream();
                clientOut = clientSocket.getOutputStream();
                serverIn = serverSocket.getInputStream();
                serverOut = serverSocket.getOutputStream();
            } catch (IOException e) {
                System.err.println(e.getMessage());
                close();
                return;
            }

            // Weiterleitung der Daten zwischen Client und Server
            var clientForward = new ForwardThread(this, clientIn, serverOut);
            clientForward.start();
            var serverForward = new ForwardThread(this, serverIn, clientOut);
            serverForward.start();
        }

        public void close() {
            try {
                serverSocket.close();
            } catch (Exception ignored) {
            }
            try {
                clientSocket.close();
            } catch (Exception ignored) {
            }
        }
    }

    private static class ForwardThread extends Thread {
        private static final int BUFFER_SIZE = 8192;
        private final InputStream inputStream;
        private final OutputStream outputStream;
        private final ClientThread clientThread;

        public ForwardThread(ClientThread clientThread, InputStream inputStream, OutputStream outputStream) {
            this.clientThread = clientThread;
            this.inputStream = inputStream;
            this.outputStream = outputStream;
        }

        public void run() {
            var buffer = new byte[BUFFER_SIZE];
            try {
                var bytesRead = 0;
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead);
                    outputStream.flush();
                }
            } catch (IOException ignored) {
            }

            clientThread.close();
        }
    }

    public static void main(String[] args) {
        var source_port = Integer.parseInt(args[0]);
        destination_host = args[1];
        destination_port = Integer.parseInt(args[2]);

        try {
            var serverSocket = new ServerSocket(source_port);
            while (true) {
                var clientSocket = serverSocket.accept();
                new ClientThread(clientSocket).start();
            }
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }
}


