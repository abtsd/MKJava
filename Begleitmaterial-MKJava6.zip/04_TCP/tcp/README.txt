# Die Umgebungsvariable PATH_TO_FX zeigt auf das Verzeichnis lib der JavaFX-Installation.

java -cp out/production/tcp info.InfoServer1
java -cp out/production/tcp info.InfoClient localhost

java -cp out/production/tcp info.InfoServer2

java -cp out/production/tcp;../../libs/json/* pool.InfoServer
java -cp out/production/tcp;../../libs/json/* pool.InfoClient localhost

java -cp out/production/tcp tcpframework.test.EchoServer 50000
# Zur Ausgabe von Sonderzeichen bei Windows: chcp 1252
java -cp out/production/tcp tcpframework.test.EchoClient localhost 50000

java -cp out/production/tcp upload.UploadServer
java -cp out/production/tcp upload.UploadClient localhost

java -cp out/production/tcp;../../libs/json/* chat.ChatServer
java -Dfile.encoding=UTF-8 -cp out/production/tcp;../../libs/json/* -p %PATH_TO_FX% --add-modules=javafx.controls chat.ChatClient localhost

java -cp out/production/tcp;../../libs/json/* async.JobServer
java -cp out/production/tcp;../../libs/json/* async.JobClient localhost localhost

java -cp out/production/tcp tcpframework.test.EchoServer 60000
java -cp out/production/tcp forwarding.ForwardServer 50000 localhost 60000
# Zur Ausgabe von Sonderzeichen bei Windows: chcp 1252
java -cp out/production/tcp tcpframework.test.EchoClient localhost 50000

java -cp out/production/tcp tcpframework.test.EchoServer 50000
java -cp out/production/tcp monitor.TCPMonitor 55555 localhost 50000 request.txt response.txt
# Zur Ausgabe von Sonderzeichen bei Windows: chcp 1252
java -cp out/production/tcp tcpframework.test.EchoClient localhost 55555

jar --create --file ../monitor.jar -C out/production/tcp monitor
