java -Dfile.encoding=UTF-8 -cp out/production/Aufgaben;../../libs/json/* update.ArtikelServer
java -Dfile.encoding=UTF-8 -cp out/production/Aufgaben;../../libs/json/* update.ArtikelClient localhost

java -cp out/production/Aufgaben copy.NetCopy > aus.pdf
java -cp out/production/Aufgaben copy.NetCopy localhost < test.pdf

java -cp out/production/Aufgaben secret.CryptDemo e secret < klar.txt > geheim.txt
java -cp out/production/Aufgaben secret.CryptDemo d secret < geheim.txt > _klar.txt

java -cp out/production/Aufgaben secret.SecretReceiver aus.txt
java -cp out/production/Aufgaben secret.SecretSender localhost klar.txt
