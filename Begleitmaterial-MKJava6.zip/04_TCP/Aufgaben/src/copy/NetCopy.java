package copy;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class NetCopy {
	private static final int PORT = 50000;

	public static void main(String[] args) {
		if (args.length == 1) {
			send(args[0]);
		} else {
			receive();
		}
	}

	private static void send(String host) {
		try (var socket = new Socket(host, PORT);
			 var out = socket.getOutputStream()) {

			var buffer = new byte[8192];
			var c = 0;
			while ((c = System.in.read(buffer)) != -1) {
				out.write(buffer, 0, c);
			}
			out.flush();
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}

	private static void receive() {
		try (var serverSocket = new ServerSocket(PORT);
			 var socket = serverSocket.accept();
			 var in = socket.getInputStream()) {

			var buffer = new byte[8192];
			var c = 0;
			while ((c = in.read(buffer)) != -1) {
				System.out.write(buffer, 0, c);
			}
			System.out.flush();
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}
	}
}
