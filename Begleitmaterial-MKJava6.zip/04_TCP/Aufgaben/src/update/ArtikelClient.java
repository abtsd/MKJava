package update;

import jakarta.json.bind.JsonbBuilder;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class ArtikelClient {
	public static void main(String[] args) {
		var host = args[0];
		var port = 50000;

		try (var socket = new Socket(host, port);
			 var in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			 var out = new PrintWriter(socket.getOutputStream(), true)) {

			var scanner = new Scanner(System.in);
			Loop: while (true) {
				System.out.print("Read (r), Update (u), Exit (e) > ");
				var op = scanner.next();

				var id = 0;
				switch (op) {
					case "r":
						try {
							System.out.print("Id > ");
							id = Integer.parseInt(scanner.next());
							read(id, out);
						} catch (NumberFormatException e) {
							continue;
						}
						break;
					case "u":
						try {
							System.out.print("Id > ");
							id = Integer.parseInt(scanner.next());
							System.out.print("Preis > ");
							double preis = Double.parseDouble(scanner.next());
							update(id, preis, out);
						} catch (NumberFormatException e) {
							continue;
						}
						break;
					case "e":
						break Loop;
					default:
						continue;
				}

				var message = deserialize(in.readLine());
				if (message.info != null) {
					System.out.println(message.info);
				} else {
					System.out.println(message.artikel);
				}
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}

	private static void read(int id, PrintWriter out) {
		var message = new Message();
		message.op = Message.Op.READ;
		var artikel = new Artikel();
		artikel.setId(id);
		message.artikel = artikel;
		out.println(serialize(message));
	}

	private static void update(int id, double preis, PrintWriter out) {
		var message = new Message();
		message.op = Message.Op.UPDATE;
		var artikel = new Artikel();
		artikel.setId(id);
		artikel.setPreis(preis);
		message.artikel = artikel;
		out.println(serialize(message));
	}

	private static String serialize(Message message) {
		var jsonb = JsonbBuilder.create();
		return jsonb.toJson(message);
	}

	private static Message deserialize(String data) {
		var jsonb = JsonbBuilder.create();
		return jsonb.fromJson(data, Message.class);
	}
}
