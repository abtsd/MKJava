package update;

public class Message {
	public enum Op {
		READ, UPDATE
	}

	public Op op;
	public String info;
	public Artikel artikel;
}
