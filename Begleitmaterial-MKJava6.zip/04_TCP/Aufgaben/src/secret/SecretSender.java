package secret;

import javax.crypto.Cipher;
import javax.crypto.CipherOutputStream;
import javax.crypto.spec.SecretKeySpec;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.net.Socket;

public class SecretSender {
    public static void main(String[] args) {
        var host = args[0];
        var file = args[1];
        var port = 50000;
        var password = "secret".getBytes();

        try {
            var cipher = Cipher.getInstance("Blowfish");
            var key = new SecretKeySpec(password, "Blowfish");
            cipher.init(Cipher.ENCRYPT_MODE, key);

            try (var socket = new Socket(host, port);
                 var in = new BufferedInputStream(new FileInputStream(file));
                 var out = new CipherOutputStream(socket.getOutputStream(), cipher)) {

                var buffer = new byte[8 * 1024];
                var c = 0;
                while ((c = in.read(buffer)) != -1) {
                    out.write(buffer, 0, c);
                }
            }
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }
}
