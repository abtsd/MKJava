package secret;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.spec.SecretKeySpec;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.net.ServerSocket;

public class SecretReceiver {
    public static void main(String[] args) {
        var file = args[0];
        var port = 50000;
        var password = "secret".getBytes();

        try (var serverSocket = new ServerSocket(port)) {
            var cipher = Cipher.getInstance("Blowfish");
            var key = new SecretKeySpec(password, "Blowfish");
            cipher.init(Cipher.DECRYPT_MODE, key);

            try (var socket = serverSocket.accept();
                 var in = new CipherInputStream(socket.getInputStream(), cipher);
                 var out = new BufferedOutputStream(new FileOutputStream(file))) {

                var buffer = new byte[8 * 1024];
                var c = 0;
                while ((c = in.read(buffer)) != -1) {
                    out.write(buffer, 0, c);
                }
            }
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }
}
