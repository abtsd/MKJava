package secret;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.spec.SecretKeySpec;

public class CryptDemo {
	private static void encode(byte[] password) throws Exception {
		var cipher = Cipher.getInstance("Blowfish");
		var key = new SecretKeySpec(password, "Blowfish");
		cipher.init(Cipher.ENCRYPT_MODE, key);

		try (var out = new CipherOutputStream(System.out, cipher)) {
			var buffer = new byte[8 * 1024];
			var c = 0;
			while ((c = System.in.read(buffer)) != -1) {
				out.write(buffer, 0, c);
			}
		}
	}

	private static void decode(byte[] password) throws Exception {
		var cipher = Cipher.getInstance("Blowfish");
		var key = new SecretKeySpec(password, "Blowfish");
		cipher.init(Cipher.DECRYPT_MODE, key);
		
		try (var in = new CipherInputStream(System.in, cipher)) {
			var buffer = new byte[8 * 1024];
			var c = 0;
			while ((c = in.read(buffer)) != -1) {
				System.out.write(buffer, 0, c);
			}
		}
	}

	public static void main(String[] args) throws Exception {
		var op = args[0].charAt(0);
		var password = args[1].getBytes();

		if (op == 'e')
			encode(password);
		else
			decode(password);
	}
}