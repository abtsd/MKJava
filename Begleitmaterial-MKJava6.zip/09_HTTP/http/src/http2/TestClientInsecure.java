package http2;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;

public class TestClientInsecure {
    public static void main(String[] args) throws NoSuchAlgorithmException, KeyManagementException {
        var host = args[0];
        var port = Integer.parseInt(args[1]);

        var baseUrl = "https://" + host + ":" + port;

        try {
            // allow insecure SSL connections
            var client = HttpClient.newBuilder()
                    .sslContext(getInsecureContext())
                    .version(HttpClient.Version.HTTP_2)
                    .build();
            var request = HttpRequest.newBuilder()
                    .uri(new URI(baseUrl + "/page1.txt"))
                    .build();
            var response = client.send(request, HttpResponse.BodyHandlers.ofString());
            System.out.println("Status: " + response.statusCode());
            System.out.println("Version: " + response.version());
            System.out.println(response.body());
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    private static SSLContext getInsecureContext()
            throws NoSuchAlgorithmException, KeyManagementException {

        var trustAllCerts = new TrustManager[]{
                new X509TrustManager() {
                    public X509Certificate[] getAcceptedIssuers() {
                        return null;
                    }

                    public void checkClientTrusted(
                            X509Certificate[] certs, String authType) {
                    }

                    public void checkServerTrusted(
                            X509Certificate[] certs, String authType) {
                    }
                }
        };

        var sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, trustAllCerts, null);
        return sslContext;
    }
}
