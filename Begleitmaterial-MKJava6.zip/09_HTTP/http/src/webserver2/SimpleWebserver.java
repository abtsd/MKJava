package webserver2;

import org.apache.catalina.connector.Connector;
import org.apache.catalina.core.StandardContext;
import org.apache.catalina.startup.Tomcat;
import org.apache.catalina.valves.AccessLogValve;

import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SimpleWebserver {
    public static void main(String[] args) throws Exception {
        var docBase = args[0];
        var port = Integer.parseInt(args[1]);
        var log = Boolean.parseBoolean(args[2]);

        Logger.getLogger("org").setLevel(Level.SEVERE);
        var tomcat = new Tomcat();
        tomcat.setBaseDir(System.getProperty("java.io.tmpdir"));

        var ctx = tomcat.addWebapp("", new File(docBase).getAbsolutePath());

        if (log) {
            var valve = new AccessLogValve();
            valve.setDirectory(new File(".").getAbsolutePath());
            valve.setPrefix("log");
            valve.setSuffix(".txt");
            valve.setPattern("common");
            ((StandardContext) ctx).addValve(valve);
        }

        var con = new Connector();
        con.setPort(port);

        var service = tomcat.getService();
        service.addConnector(con);

        tomcat.start();

        System.out.println("Stoppen mit ENTER");
        System.in.read();
        tomcat.stop();
        tomcat.destroy();
    }
}
