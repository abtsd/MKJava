package request;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;

public class ShowRequest {
	public static void main(String[] args) {
		try (var server = new ServerSocket(50000)) {
			while (true) {
				try (var client = server.accept();
					 var in = new BufferedReader(new InputStreamReader(client.getInputStream()));
					 var out = new BufferedOutputStream(client.getOutputStream())) {

					out.write("HTTP/1.1 200 OK\r\n".getBytes());
					out.write("Content-Type: text/plain\r\n\r\n".getBytes());

					var n = 0;
					var length = 0;
					var line = "";
					while (true) {
						line = in.readLine();
						out.write((++n + "\t" + line + "\n").getBytes());

						if (line == null || line.length() == 0)
							break;

						if (line.startsWith("Content-Length")) {
							length = Integer.parseInt(line.substring(line.indexOf(':') + 1).trim());
						}
					}

					out.write('\t');
					for (int i = 0; i < length; i++) {
						int c = in.read();
						out.write((char) c);
					}
				}
			}
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}
	}
}
