package download;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class Download {
    private String url;
    private final String dir;

    public Download(String url, String dir) {
        this.url = url;
        this.dir = dir;
    }

    public void process() throws IOException {
        // Leerzeichen ersetzen
        url = url.replaceAll(" ", "%20");
        var u = new URL(url);

        // Dateiname extrahieren
        var path = u.getPath();
        path = path.replaceAll("%20", " ");
        var idx = path.lastIndexOf("/");
        var file = dir + "/" + path.substring(idx + 1);

        var con = (HttpURLConnection) u.openConnection();

        System.out.println("Request: " + con.getRequestMethod() + " " + con.getURL());
        con.connect();
        System.out.println("Response-Code: " + con.getResponseCode());

        if (con.getResponseCode() != HttpURLConnection.HTTP_OK) {
            throw new IllegalStateException("Error: " + con.getResponseCode());
        }

        try (var in = new BufferedInputStream(con.getInputStream());
             var out = new BufferedOutputStream(new FileOutputStream(file))) {

            var length = con.getContentLength();
            if (length == -1)
                return;

            var c = 0;
            for (var i = 0; i < length; i++) {
                c = in.read();
                out.write(c);
            }

            System.out.println(length + " Bytes");
            System.out.println("Gespeichert in " + new File(file));
        }
    }

    public static void main(String[] args) {
        var url = args[0];
        var dir = args[1];

        try {
            new Download(url, dir).process();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }
}
