package webserver1;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class AccessLog {
	public static AccessLog logger;
	private final BufferedWriter logfileWriter;
	
	private AccessLog(File logfile) throws IOException {
		logfileWriter = new BufferedWriter(new FileWriter(logfile, true));
	}
	
	public static void initializeLogger(File logfile) throws IOException {
		if (logger == null)
			logger = new AccessLog(logfile);
	}
	
	public void log(String info) throws IOException {
		synchronized (logfileWriter) {
			logfileWriter.write(info);
			logfileWriter.newLine();
			logfileWriter.flush();
			System.out.println(info);
		}
	}
	
	public void close() {
		try {
			logfileWriter.flush();
			logfileWriter.close();
		} catch (IOException ignored) {
		}
	}
}
