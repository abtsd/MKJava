package webserver1;

import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;

public class SimpleWebserver extends Thread {
	private static final String LOG_FILE = "access.log";
	private static final int SOCKET_TIMEOUT = 30000;
	private final File root;
	private final boolean log;
	private final ServerSocket serverSocket;

	public SimpleWebserver(File root, int port, boolean log) throws IOException {
		this.root = root.getCanonicalFile();
		this.log = log;

		if (!root.isDirectory())
			throw new IOException("No directory");

		if (log)
			AccessLog.initializeLogger(new File(LOG_FILE));

		Runtime.getRuntime().addShutdownHook(new Thread(this::shutdown));

		serverSocket = new ServerSocket(port);
	}

	@Override
	public void run() {
		while (true) {
			try {
				Socket socket;
				try {
					socket = serverSocket.accept();
				} catch (SocketException e) {
					break;
				}

				socket.setSoTimeout(SOCKET_TIMEOUT);

				var request = new Request(socket, root, log);
				request.start();
			} catch (IOException e) {
				System.err.println(e.getMessage());
			}
		}
	}

	public void shutdown() {
		try {
			if (serverSocket != null) {
				serverSocket.close();
			}

			if (AccessLog.logger != null) {
				AccessLog.logger.close();
			}
		} catch (IOException ignored) {
		}
	}

	public static void main(String[] args) {
		var root = args[0];
		var port = Integer.parseInt(args[1]);
		var log = Boolean.parseBoolean(args[2]);

		try {
			var server = new SimpleWebserver(new File(root), port, log);
			server.start();
			System.out.println("SimpleWebserver gestartet ...");
			System.out.println("Stoppen mit ENTER oder Strg+C");
			System.in.read();
			System.exit(0);
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}
	}
}
