package crud.client;

import crud.Contact;
import jakarta.json.bind.Jsonb;
import jakarta.json.bind.JsonbBuilder;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class ContactClient {
    private static String BASE_URL;
    private static final Jsonb jsonb = JsonbBuilder.create();

    public static void main(String[] args) {
        var host = args[0];
        var port = Integer.parseInt(args[1]);
        BASE_URL = "http://" + host + ":" + port;

        try {
            System.out.println("\n--- Neuen Kontakt anlegen");
            var contact = new Contact("Flick, Pit", "pit.flick@gmx.de");
            var id = create(contact);
            System.out.println("Kontakt mit Id=" + id + " angelegt.");

            System.out.println("\n--- Neuen Kontakt anlegen");
            contact = new Contact("Meier, Hugo", "hugo.meier@gmx.de");
            id = create(contact);
            System.out.println("Kontakt mit Id=" + id + " angelegt.");

            System.out.println("\n--- Alle Kontakte lesen");
            var list = read();
            for (var c : list) {
                System.out.println(c);
            }

            System.out.println("\n--- Kontakt " + id + " lesen");
            contact = read(id);
            System.out.println(contact);

            System.out.println("\n--- Kontakt " + id + " ändern");
            if (contact != null) {
                contact.setEmail("hugo.meier@web.de");
                update(contact);
                System.out.println("Kontakt geändert");
            }

            System.out.println("\n--- Kontakt " + id + " lesen");
            contact = read(id);
            System.out.println(contact);

            System.out.println("\n--- Kontakt " + id + " löschen");
            if (contact != null) {
                delete(contact);
                System.out.println("Kontakt gelöscht");
            }

            System.out.println("\n--- Kontakt " + id + " lesen");
            contact = read(id);
            System.out.println(contact);
        } catch (Exception e) {
            System.err.println("Exception: " + e.getMessage());
        }
    }

    private static int create(Contact contact) throws IOException {
        var url = new URL(BASE_URL + "/contacts");
        var con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("POST");
        System.out.println(con.getURL() + " " + con.getRequestMethod());
        con.setDoOutput(true);
        con.setRequestProperty("Content-Type", "application/json");
        jsonb.toJson(contact, new OutputStreamWriter(con.getOutputStream()));

        var code = con.getResponseCode();
        if (code == HttpURLConnection.HTTP_CREATED) {
            var id = con.getHeaderField("X-Id");
            return Integer.parseInt(id);
        } else {
            throw new RuntimeException(String.valueOf(code));
        }
    }

    private static Contact read(int id) throws IOException {
        var url = new URL(BASE_URL + "/contacts/" + id);
        var con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("GET");
        System.out.println(con.getURL() + " " + con.getRequestMethod());

        var code = con.getResponseCode();
        if (code == HttpURLConnection.HTTP_OK) {
            return jsonb.fromJson(new InputStreamReader(con.getInputStream()), Contact.class);
        } else if (code == HttpURLConnection.HTTP_NOT_FOUND) {
            return null;
        } else {
            throw new RuntimeException(String.valueOf(code));
        }
    }

    private static List<Contact> read() throws IOException {
        var url = new URL(BASE_URL + "/contacts");
        var con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("GET");
        System.out.println(con.getURL() + " " + con.getRequestMethod());

        var code = con.getResponseCode();
        if (code == HttpURLConnection.HTTP_OK) {
            var type = new ArrayList<Contact>() {
            }.getClass().getGenericSuperclass();
            return jsonb.fromJson(new InputStreamReader(con.getInputStream()), type);
        } else {
            throw new RuntimeException(String.valueOf(code));
        }
    }

    private static void update(Contact contact) throws IOException {
        var url = new URL(BASE_URL + "/contacts/" + contact.getId());
        var con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("PUT");
        System.out.println(con.getURL() + " " + con.getRequestMethod());
        con.setDoOutput(true);
        con.setRequestProperty("Content-Type", "application/json");
        jsonb.toJson(contact, new OutputStreamWriter(con.getOutputStream()));

        var code = con.getResponseCode();
        if (code != HttpURLConnection.HTTP_NO_CONTENT) {
            throw new RuntimeException(String.valueOf(code));
        }
    }

    private static void delete(Contact contact) throws IOException {
        var url = new URL(BASE_URL + "/contacts/" + contact.getId());
        var con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("DELETE");
        System.out.println(con.getURL() + " " + con.getRequestMethod());

        var code = con.getResponseCode();
        if (code != HttpURLConnection.HTTP_NO_CONTENT) {
            throw new RuntimeException(String.valueOf(code));
        }
    }
}
