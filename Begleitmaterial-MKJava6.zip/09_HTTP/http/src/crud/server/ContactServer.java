package crud.server;

import org.apache.catalina.connector.Connector;
import org.apache.catalina.core.StandardContext;
import org.apache.catalina.startup.Tomcat;
import org.apache.catalina.valves.AccessLogValve;

import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ContactServer {
    public static void main(String[] args) throws Exception {
        var port = Integer.parseInt(args[0]);
        var log = Boolean.parseBoolean(args[1]);

        Logger.getLogger("").setLevel(Level.SEVERE);
        var tomcat = new Tomcat();
        tomcat.setBaseDir(System.getProperty("java.io.tmpdir"));

        var ctx = tomcat.addWebapp("", new File(".").getAbsolutePath());

        var servletClass = ContactServlet.class;
        Tomcat.addServlet(ctx, servletClass.getSimpleName(), servletClass.getName());
        ctx.addServletMappingDecoded("/contacts/*", servletClass.getSimpleName());

        if (log) {
            var valve = new AccessLogValve();
            valve.setDirectory(new File(".").getAbsolutePath());
            valve.setPrefix("log");
            valve.setSuffix(".txt");
            valve.setPattern("common");
            ((StandardContext) ctx).addValve(valve);
        }

        var con = new Connector();
        con.setPort(port);

        var service = tomcat.getService();
        service.addConnector(con);

        tomcat.start();

        System.out.println("Stoppen mit ENTER");
        System.in.read();
        tomcat.stop();
        tomcat.destroy();
    }
}
