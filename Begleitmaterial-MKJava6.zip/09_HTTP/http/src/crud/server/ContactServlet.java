package crud.server;

import crud.Contact;
import jakarta.json.bind.Jsonb;
import jakarta.json.bind.JsonbBuilder;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.atomic.AtomicInteger;

public class ContactServlet extends HttpServlet {
    private final Map<Integer, Contact> contacts = Collections.synchronizedMap(new TreeMap<>());
    private final AtomicInteger counter;
    private final Jsonb jsonb;

    public ContactServlet() {
        counter = new AtomicInteger();
        jsonb = JsonbBuilder.create();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        var path = req.getPathInfo();
        if (path == null) {
            var list = new ArrayList<Contact>();
            synchronized (contacts) {
                for (var key : contacts.keySet()) {
                    list.add(contacts.get(key));
                }
            }
            resp.setStatus(HttpServletResponse.SC_OK);
            resp.setContentType("application/json");
            jsonb.toJson(list, new OutputStreamWriter(resp.getOutputStream()));
        } else {
            var id = 0;
            try {
                id = Integer.parseInt(path.substring(1));
            } catch (Exception e) {
                resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                return;
            }
            var contact = contacts.get(id);
            if (contact == null) {
                resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
                return;
            }
            resp.setStatus(HttpServletResponse.SC_OK);
            resp.setContentType("application/json");
            jsonb.toJson(contact, new OutputStreamWriter(resp.getOutputStream()));
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        var contact = jsonb.fromJson(new InputStreamReader(req.getInputStream()), Contact.class);
        var id = counter.incrementAndGet();
        contact.setId(id);
        contacts.put(id, contact);
        resp.setStatus(HttpServletResponse.SC_CREATED);
        resp.setHeader("X-Id", String.valueOf(id));
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        var path = req.getPathInfo();
        var id = 0;
        try {
            id = Integer.parseInt(path.substring(1));
        } catch (Exception e) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }
        var contact = contacts.get(id);
        if (contact == null) {
            resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        var c = jsonb.fromJson(new InputStreamReader(req.getInputStream()), Contact.class);
        contact.setName(c.getName());
        contact.setEmail(c.getEmail());
        resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) {
        var path = req.getPathInfo();
        var id = 0;
        try {
            id = Integer.parseInt(path.substring(1));
        } catch (Exception e) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }
        var contact = contacts.get(id);
        if (contact == null) {
            resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        contacts.remove(contact.getId());
        resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
    }
}
