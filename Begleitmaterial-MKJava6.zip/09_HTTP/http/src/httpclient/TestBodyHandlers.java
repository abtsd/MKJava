package httpclient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Paths;
import java.util.Arrays;

public class TestBodyHandlers {
    private static String baseUri;

    public static void main(String[] args) throws Exception {
        var host = args[0];
        var port = Integer.parseInt(args[1]);
        baseUri = "http://" + host + ":" + port;

        var client = HttpClient.newBuilder()
                .version(HttpClient.Version.HTTP_1_1)
                .build();

        System.out.println("--- ofString");
        testString(client);

        System.out.println("--- ofLines");
        testLines(client);

        System.out.println("--- ofByteArray");
        testByteArray(client);

        System.out.println("--- ofFile");
        testFile(client);

        System.out.println("--- ofInputStream");
        testInputStream(client);
    }

    private static void testString(HttpClient client) throws IOException, InterruptedException {
        var request = HttpRequest.newBuilder()
                .uri(URI.create(baseUri + "/page1.txt"))
                .GET()  // Default
                .build();
        var response = client.send(request, HttpResponse.BodyHandlers.ofString());
        System.out.println("Status: " + response.statusCode());
        System.out.println(response.body());
    }

    private static void testLines(HttpClient client) throws IOException, InterruptedException {
        var request = HttpRequest.newBuilder()
                .uri(URI.create(baseUri + "/page1.txt"))
                .build();
        var response = client.send(request, HttpResponse.BodyHandlers.ofLines());
        System.out.println("Status: " + response.statusCode());
        response.body().forEach(System.out::println);
    }

    private static void testByteArray(HttpClient client) throws IOException, InterruptedException {
        var request = HttpRequest.newBuilder()
                .uri(URI.create(baseUri + "/page1.txt"))
                .build();
        var response = client.send(request, HttpResponse.BodyHandlers.ofByteArray());
        System.out.println("Status: " + response.statusCode());
        var bytes = response.body();
        System.out.println(Arrays.toString(bytes));
    }

    private static void testFile(HttpClient client) throws IOException, InterruptedException {
        var request = HttpRequest.newBuilder()
                .uri(URI.create(baseUri + "/java.gif"))
                .build();
        var response = client.send(request,
                HttpResponse.BodyHandlers.ofFile(Paths.get("xxx.gif")));
        System.out.println("Status: " + response.statusCode());
        System.out.println("Gespeichert in " + response.body());
    }

    private static void testInputStream(HttpClient client) throws IOException, InterruptedException {
        var request = HttpRequest.newBuilder()
                .uri(URI.create(baseUri + "/page1.txt"))
                .build();
        var response = client.send(request, HttpResponse.BodyHandlers.ofInputStream());
        System.out.println("Status: " + response.statusCode());
        try (var in = new BufferedReader(new InputStreamReader(response.body()))) {
            var line = "";
            while ((line = in.readLine()) != null) {
                System.out.println(line);
            }
        }
    }
}
