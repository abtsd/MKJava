package httpclient;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Arrays;
import java.util.concurrent.CountDownLatch;
import java.util.stream.Collectors;

public class TestAsync {
    private static String baseUri;

    public static void main(String[] args) throws Exception {
        var host = args[0];
        var port = Integer.parseInt(args[1]);
        baseUri = "http://" + host + ":" + port;

        var client = HttpClient.newBuilder()
                .version(HttpClient.Version.HTTP_1_1)
                .build();

        System.out.println("--- testAsync1");
        var latch = new CountDownLatch(1);
        testAsync1(client, latch);
        latch.await();

        System.out.println("--- testAsync2");
        testAsync2(client);
    }

    private static void testAsync1(HttpClient client, CountDownLatch latch) {
        var request = HttpRequest.newBuilder()
                .uri(URI.create(baseUri + "/page1.txt"))
                .build();
        client.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(response -> {
                    System.out.println("Status: " + response.statusCode());
                    return response;
                })
                .thenApply(HttpResponse::body)
                .thenAccept(s -> {
                    System.out.println(s);
                    latch.countDown();
                });
    }

    private static void testAsync2(HttpClient client) throws Exception {
        var targets = Arrays.asList(
                new URI(baseUri + "/page1.txt"),
                new URI(baseUri + "/page2.txt")
        );

        var futures = targets.stream()
                .map(target -> client
                        .sendAsync(HttpRequest.newBuilder(target).build(),
                                HttpResponse.BodyHandlers.ofString())
                        .thenApply(HttpResponse::body))
                .collect(Collectors.toList());

        System.out.println("Warten...");
        for (var future : futures) {
            System.out.println(future.get());
        }
    }
}
