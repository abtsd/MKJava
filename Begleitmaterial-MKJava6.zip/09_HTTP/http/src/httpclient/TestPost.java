package httpclient;

import crud.Contact;
import jakarta.json.bind.Jsonb;
import jakarta.json.bind.JsonbBuilder;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;

public class TestPost {
    private static String baseUri;
    private static final Jsonb jsonb = JsonbBuilder.create();

    public static void main(String[] args) throws Exception {
        var host = args[0];
        var port = Integer.parseInt(args[1]);
        baseUri = "http://" + host + ":" + port;

        var client = HttpClient.newBuilder()
                .version(HttpClient.Version.HTTP_1_1)
                .build();

        System.out.println("--- post");
        testPost(client);

        System.out.println("--- get");
        testGet(client);
    }

    private static void testPost(HttpClient client) throws IOException, InterruptedException {
        var contact = new Contact("Flick, Pit", "pit.flick@gmx.de");
        var request = HttpRequest.newBuilder()
                .uri(URI.create(baseUri + "/contacts"))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonb.toJson(contact)))
                .build();
        var response = client.send(request, HttpResponse.BodyHandlers.discarding());
        System.out.println("Status: " + response.statusCode());
        System.out.println("Id: " + response.headers().firstValue("X-Id").get());
    }

    private static void testGet(HttpClient client) throws IOException, InterruptedException {
        var request = HttpRequest.newBuilder()
                .uri(URI.create(baseUri + "/contacts"))
                .build();
        var response = client.send(request, HttpResponse.BodyHandlers.ofString());
        System.out.println("Status: " + response.statusCode());
        var type = new ArrayList<Contact>() {}.getClass().getGenericSuperclass();
        var contacts = jsonb.fromJson(response.body(), type);
        System.out.println(contacts);
    }
}
