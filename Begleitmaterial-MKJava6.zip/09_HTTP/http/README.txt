java -cp out/production/http request.ShowRequest
Test:
1. Im Webbrowser beispielsweise eingeben: http://localhost:50000/abc/xyz.html
2. Formular post.html lokal im Webbrowser aufrufen, Daten senden.
3. Formular get.html lokal im Webbrowser aufrufen, Daten senden.

java -cp out/production/http webserver1.SimpleWebserver web 8080 true
java -Dcontent.types.user.table=content-types.properties -cp out/production/http webserver1.SimpleWebserver web 8080 true
Test: http://localhost:8080

java --add-opens=java.base/java.lang=ALL-UNNAMED --add-opens=java.base/java.io=ALL-UNNAMED --add-opens=java.rmi/sun.rmi.transport=ALL-UNNAMED -cp out/production/http;../../libs/tomcat/* webserver2.SimpleWebserver web 8080 true
Test: http://localhost:8080

java -cp out/production/http download.Download "http://localhost:8080/java.gif" tmp
java -cp out/production/http download.Download "http://www.klavier-noten.com/schumann/Arabeske Op. 18.pdf" tmp
java -cp out/production/http download.Download "https://tools.ietf.org/pdf/rfc1945.pdf" tmp

java --add-opens=java.base/java.lang=ALL-UNNAMED --add-opens=java.base/java.io=ALL-UNNAMED --add-opens=java.rmi/sun.rmi.transport=ALL-UNNAMED -cp out/production/http;../../libs/tomcat/* webserver2.SimpleWebserver web 8080 false
java -cp ../../04_TCP/monitor.jar monitor.TCPMonitor 8888 localhost 8080 request.txt response.txt
java -cp out/production/http download.Download "http://localhost:8888/page1.txt" tmp

Proxy Server (IntelliJ IDEA Network) starten
java --add-opens=java.base/java.lang=ALL-UNNAMED --add-opens=java.base/java.io=ALL-UNNAMED --add-opens=java.rmi/sun.rmi.transport=ALL-UNNAMED -cp out/production/http;../../libs/tomcat/* webserver2.SimpleWebserver web 8080 false
java -Dhttp.proxyHost=localhost -Dhttp.proxyPort=8888 -Dhttp.nonProxyHosts= -cp out/production/http download.Download "http://localhost:8080/page1.txt" tmp

java -Dfile.encoding=UTF-8 --add-opens=java.base/java.lang=ALL-UNNAMED --add-opens=java.base/java.io=ALL-UNNAMED --add-opens=java.rmi/sun.rmi.transport=ALL-UNNAMED -cp out/production/http;../../libs/tomcat/*;../../libs/json/* crud.server.ContactServer 8080 false
# Zur Ausgabe von Sonderzeichen bei Windows: chcp 1252
java -Dfile.encoding=UTF-8 -cp out/production/http;../../libs/json/* crud.client.ContactClient localhost 8080

Proxy Server (IntelliJ IDEA Network) starten
# Zur Ausgabe von Sonderzeichen bei Windows: chcp 1252
java -Dhttp.proxyHost=localhost -Dhttp.proxyPort=8888 -Dhttp.nonProxyHosts= -Dfile.encoding=UTF-8 -cp out/production/http;../../libs/json/* crud.client.ContactClient localhost 8080

java -cp out/production/http webserver1.SimpleWebserver web 8080 false
java -cp out/production/http httpclient.TestBodyHandlers localhost 8080
java -cp out/production/http httpclient.TestAsync localhost 8080

java -Dfile.encoding=UTF-8 --add-opens=java.base/java.lang=ALL-UNNAMED --add-opens=java.base/java.io=ALL-UNNAMED --add-opens=java.rmi/sun.rmi.transport=ALL-UNNAMED -cp out/production/http;../../libs/tomcat/*;../../libs/json/* crud.server.ContactServer 8080 false
java -cp out/production/http;../../libs/json/* httpclient.TestPost localhost 8080

# keystore.jks und certs.jks bereitstellen
copy /Y ..\..\certificate\*.jks .

java --add-opens=java.base/java.lang=ALL-UNNAMED --add-opens=java.base/java.io=ALL-UNNAMED --add-opens=java.rmi/sun.rmi.transport=ALL-UNNAMED -cp ../../webserver/webserver.jar;../../libs/tomcat/* WebServer "" web 8443 false true
java -cp out/production/http http2.TestClient localhost 8443
java -Djavax.net.debug=all -cp out/production/http http2.TestClient localhost 8443

# Alternative, falls Properties nicht im Programm gesetzt sind:
java -Djavax.net.ssl.trustStore=certs.jks -Djavax.net.ssl.trustStorePassword=secret -cp out/production/http http2.TestClient localhost 8443

java -cp out/production/http http2.TestClientInsecure localhost 8443
java -Djavax.net.debug=all -cp out/production/http http2.TestClientInsecure localhost 8443
