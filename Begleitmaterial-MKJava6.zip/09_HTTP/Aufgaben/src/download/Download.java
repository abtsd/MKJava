package download;

import java.io.File;
import java.net.URI;
import java.net.URL;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Paths;

public class Download {
	private final String url;
	private final String dir;

	public Download(String url, String dir) {
		this.url = url;
		this.dir = dir;
	}

	public void process() {
		try {
			var path = new URL(url).getPath();
			var idx = path.lastIndexOf("/");
			var file = dir + "/" + path.substring(idx + 1);

			var client = HttpClient.newBuilder()
					.version(HttpClient.Version.HTTP_1_1)
					.build();
			var request = HttpRequest.newBuilder()
					.uri(URI.create(url.replaceAll(" ", "%20")))
					.build();
			var response = client.send(request,
					HttpResponse.BodyHandlers.ofFile(Paths.get(file)));
			if (response.statusCode() == 200) {
				System.out.println(new File(file).length() + " Bytes");
				System.out.println("Gespeichert in " + response.body());
			} else if (response.statusCode() == 302) {
				var location = response.headers().firstValue("Location").get();
				System.out.println("302 Found");
				System.out.println("Location: " + location);
			} else {
				new File(file).delete();
				System.out.println(response.statusCode());
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		var url = args[0];
		var dir = args[1];

		new Download(url, dir).process();
	}
}
