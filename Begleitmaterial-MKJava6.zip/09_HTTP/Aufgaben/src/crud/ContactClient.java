package crud;

import jakarta.json.bind.Jsonb;
import jakarta.json.bind.JsonbBuilder;

import java.net.HttpURLConnection;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;

public class ContactClient {
    private static String BASE_URL;
    private static final Jsonb jsonb = JsonbBuilder.create();

    public static void main(String[] args) {
        var host = args[0];
        var port = Integer.parseInt(args[1]);
        BASE_URL = "http://" + host + ":" + port;

        var client = HttpClient.newBuilder()
                .version(HttpClient.Version.HTTP_1_1)
                .build();

        try {
            System.out.println("\n--- Neuen Kontakt anlegen");
            var contact = new Contact("Flick, Pit", "pit.flick@gmx.de");
            var id = create(client, contact);
            System.out.println("Kontakt mit Id=" + id + " angelegt.");

            System.out.println("\n--- Neuen Kontakt anlegen");
            contact = new Contact("Meier, Hugo", "hugo.meier@gmx.de");
            id = create(client, contact);
            System.out.println("Kontakt mit Id=" + id + " angelegt.");

            System.out.println("\n--- Alle Kontakte lesen");
            var list = read(client);
            for (var c : list) {
                System.out.println(c);
            }

            System.out.println("\n--- Kontakt " + id + " lesen");
            contact = read(client, id);
            System.out.println(contact);

            System.out.println("\n--- Kontakt " + id + " ändern");
            if (contact != null) {
                contact.setEmail("hugo.meier@web.de");
                update(client, contact);
                System.out.println("Kontakt geändert");
            }

            System.out.println("\n--- Kontakt " + id + " lesen");
            contact = read(client, id);
            System.out.println(contact);

            System.out.println("\n--- Kontakt " + id + " löschen");
            if (contact != null) {
                delete(client, contact);
                System.out.println("Kontakt gelöscht");
            }

            System.out.println("\n--- Kontakt " + id + " lesen");
            contact = read(client, id);
            System.out.println(contact);
        } catch (Exception e) {
            System.err.println("Exception: " + e.getMessage());
        }
    }

    private static int create(HttpClient client, Contact contact) throws Exception {
        var request = HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/contacts"))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonb.toJson(contact)))
                .build();
        System.out.println(request.uri() + " " + request.method());
        var response = client.send(request, HttpResponse.BodyHandlers.discarding());
        var code = response.statusCode();
        if (code == HttpURLConnection.HTTP_CREATED) {
            var id = response.headers().firstValue("X-Id").get();
            return Integer.parseInt(id);
        } else {
            throw new RuntimeException("Status: " + code);
        }
    }

    private static Contact read(HttpClient client, int id) throws Exception {
        var request = HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/contacts/" + id))
                .build();
        System.out.println(request.uri() + " " + request.method());
        var response = client.send(request, HttpResponse.BodyHandlers.ofString());
        var code = response.statusCode();
        if (code == HttpURLConnection.HTTP_OK) {
            return jsonb.fromJson(response.body(), Contact.class);
        } else if (code == HttpURLConnection.HTTP_NOT_FOUND) {
            return null;
        } else {
            throw new RuntimeException("Status: " + code);
        }
    }

    private static List<Contact> read(HttpClient client) throws Exception {
        var request = HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/contacts"))
                .build();
        System.out.println(request.uri() + " " + request.method());
        var response = client.send(request, HttpResponse.BodyHandlers.ofString());
        var code = response.statusCode();
        if (code == HttpURLConnection.HTTP_OK) {
            var type = new ArrayList<Contact>() {
            }.getClass().getGenericSuperclass();
            return jsonb.fromJson(response.body(), type);
        } else {
            throw new RuntimeException("Status: " + code);
        }
    }

    private static void update(HttpClient client, Contact contact) throws Exception {
        var request = HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/contacts/" + contact.getId()))
                .header("Content-Type", "application/json")
                .PUT(HttpRequest.BodyPublishers.ofString(jsonb.toJson(contact)))
                .build();
        System.out.println(request.uri() + " " + request.method());
        var response = client.send(request, HttpResponse.BodyHandlers.discarding());
        var code = response.statusCode();
        if (code != HttpURLConnection.HTTP_NO_CONTENT) {
            throw new RuntimeException("Status: " + code);
        }
    }

    private static void delete(HttpClient client, Contact contact) throws Exception {
        var request = HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/contacts/" + contact.getId()))
                .header("Content-Type", "application/json")
                .DELETE()
                .build();
        System.out.println(request.uri() + " " + request.method());
        var response = client.send(request, HttpResponse.BodyHandlers.discarding());
        var code = response.statusCode();
        if (code != HttpURLConnection.HTTP_NO_CONTENT) {
            throw new RuntimeException("Status: " + code);
        }
    }
}
