package single;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

public class Download {
    public static void main(String[] args) throws Exception {
        var host = args[0];
        var port = Integer.parseInt(args[1]);
        var uri = "http://" + host + ":" + port;

        var client = HttpClient.newBuilder()
                .version(HttpClient.Version.HTTP_1_1)
                .build();
        var request = HttpRequest.newBuilder()
                .uri(URI.create(uri))
                .build();
        var response = client.send(request,
                HttpResponse.BodyHandlers.ofFileDownload(Paths.get("tmp"),
                        StandardOpenOption.CREATE, StandardOpenOption.WRITE));
        System.out.println("Gespeichert in " + response.body());
    }
}
