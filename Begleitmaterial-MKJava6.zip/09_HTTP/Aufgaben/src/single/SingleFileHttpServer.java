package single;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class SingleFileHttpServer {
    private static final String TYPE = "application/pdf";
    private final int port;
    private final File file;

    public SingleFileHttpServer(int port, File file) {
        this.port = port;
        this.file = file;

        var filename = file.getName();
        if (!filename.endsWith(".pdf"))
            throw new IllegalArgumentException(filename + " ist keine PDF-Datei");
    }

    public void start() {
        try (var serverSocket = new ServerSocket(port)) {
            while (true) {
                var socket = serverSocket.accept();
                new SingleFileThread(socket).start();
            }
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }

    private class SingleFileThread extends Thread {
        private final Socket socket;

        public SingleFileThread(Socket socket) {
            this.socket = socket;
        }

        public void run() {
            try (var in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                 var out = new BufferedOutputStream(socket.getOutputStream())) {

                var line = in.readLine();
                if (line == null)
                    return;

                if (line.startsWith("GET / ")) {
                    var header = "HTTP/1.1 200 OK"
                            + "\r\nContent-Type: " + TYPE
                            + "\r\nContent-Length: " + file.length()
                            + "\r\nContent-Disposition: attachment; filename=\"" + file.getName() + "\""
                            + "\r\nConnection: close"
                            + "\r\n\r\n";
                    out.write(header.getBytes());
                    writeFile(file, out);
                } else {
                    // Google Chrome fordert automatisch an: GET /favicon.ico HTTP/1.1
                    var header = "HTTP/1.1 404 Not Found"
                            + "\r\nConnection: close"
                            + "\r\n\r\n";
                    out.write(header.getBytes());
                }
                out.flush();
            } catch (IOException e) {
                System.err.println(e.getMessage());
            } finally {
                if (socket != null) {
                    try {
                        socket.close();
                    } catch (IOException ignored) {
                    }
                }
            }
        }
    }

    private void writeFile(File file, OutputStream out) throws IOException {
        try (var in = new FileInputStream(file)) {
            var buffer = new byte[8192];
            var c = 0;
            while ((c = in.read(buffer)) != -1) {
                out.write(buffer, 0, c);
            }
            out.flush();
        }
    }

    public static void main(String[] args) {
        var port = Integer.parseInt(args[0]);
        var file = new File(args[1]);

        if (!file.isFile()) {
            System.err.println("Datei '" + args[1] + "' ist nicht vorhanden");
            System.exit(1);
        }

        try {
            var server = new SingleFileHttpServer(port, file);
            server.start();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }
}
