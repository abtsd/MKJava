package redirect;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class Redirector {
	private final int port;
	private final String site;

	public Redirector(int port, String site) {
		this.port = port;
		this.site = site;
	}

	public void start() {
		try (var serverSocket = new ServerSocket(port)) {
			while (true) {
				var socket = serverSocket.accept();
				new RedirectThread(socket).start();
			}
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}
	}

	private class RedirectThread extends Thread {
		private final Socket socket;

		public RedirectThread(Socket socket) {
			this.socket = socket;
		}

		public void run() {
			try (var in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
				 var out = new BufferedOutputStream(socket.getOutputStream())) {

				var line = in.readLine();
				if (line == null)
					return;

				var path = line.substring(4, line.length() - 9);
				if (path.equals("/"))
					path = "";

				var header = "HTTP/1.1 307 Temporary Redirect\r\nLocation: " + site + path;
				System.out.println(header);
				header += "\r\n\r\n";

				out.write(header.getBytes());
				out.flush();
			} catch (IOException e) {
				System.err.println(e);
			} finally {
				if (socket != null) {
					try {
						socket.close();
					} catch (IOException ignored) {
					}
				}
			}
		}
	}

	public static void main(String[] args) {
		var port = Integer.parseInt(args[0]);
		var site = args[1];

		if (site.endsWith("/"))
			site = site.substring(0, site.length() - 1);

		var server = new Redirector(port, site);
		server.start();
	}
}
