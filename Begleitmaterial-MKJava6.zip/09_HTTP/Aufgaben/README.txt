java -cp out/production/Aufgaben single.SingleFileHttpServer 8080 test.pdf

java -cp out/production/Aufgaben single.Download localhost 8080

java -cp out/production/Aufgaben redirect.Redirector 8080 http://de.wikipedia.org/wiki
Browser: http://localhost:8080/HTTP-Statuscode

java -cp out/production/Aufgaben download.Download "https://datatracker.ietf.org/doc/pdf/rfc1945.pdf" tmp

java -Dfile.encoding=UTF-8 --add-opens=java.base/java.lang=ALL-UNNAMED --add-opens=java.base/java.io=ALL-UNNAMED --add-opens=java.rmi/sun.rmi.transport=ALL-UNNAMED -cp ../http/out/production/http;../../libs/tomcat/*;../../libs/json/* crud.server.ContactServer 8080 false
# Zur Ausgabe von Sonderzeichen bei Windows: chcp 1252
java -Dfile.encoding=UTF-8 -cp out/production/Aufgaben;../../libs/json/* crud.ContactClient localhost 8080
