java -cp out/production/mqtt;../../libs/mqtt/* sensor.CPUTempPublisher tcp://localhost:1883
java -cp out/production/mqtt;../../libs/mqtt/* sensor.RoomTempPublisher tcp://localhost:1883
java -cp out/production/mqtt;../../libs/mqtt/* sensor.TempSubscriber tcp://localhost:1883 sensor/temperature/cpu
java -cp out/production/mqtt;../../libs/mqtt/* sensor.TempSubscriber tcp://localhost:1883 sensor/temperature/room
java -cp out/production/mqtt;../../libs/mqtt/* sensor.TempSubscriber tcp://localhost:1883 sensor/temperature/+

# Broker und Webserver auf demselben Rechner
java --add-opens=java.base/java.lang=ALL-UNNAMED --add-opens=java.base/java.io=ALL-UNNAMED --add-opens=java.rmi/sun.rmi.transport=ALL-UNNAMED -cp ../../webserver/webserver.jar;../../libs/tomcat/* WebServer /demo web 8080 false false
java -cp out/production/mqtt;../../libs/mqtt/* sensor.RoomTempPublisher tcp://localhost:1883

java -cp out/production/mqtt;../../libs/mqtt/* lwt.Publisher tcp://localhost:1883
java -cp out/production/mqtt;../../libs/mqtt/* lwt.Subscriber tcp://localhost:1883

java -cp out/production/mqtt;../../libs/mqtt/* control.Sensor tcp://localhost:1883
java -cp out/production/mqtt;../../libs/mqtt/* control.Controller tcp://localhost:1883
java -cp out/production/mqtt;../../libs/mqtt/* control.Controller tcp://localhost:1883 TOGGLE

java --add-modules=javafx.controls -p %PATH_TO_FX% -cp out/production/mqtt;../../libs/mqtt/* chart.LiveChart tcp://localhost:1883
java -cp out/production/mqtt;../../libs/mqtt/* chart.Publisher tcp://localhost:1883

java -cp out/production/mqtt;../../libs/mqtt/* session.SessionManager tcp://localhost:1883 4711 subscribe
java -cp out/production/mqtt;../../libs/mqtt/* session.Publisher tcp://localhost:1883
java -cp out/production/mqtt;../../libs/mqtt/* session.Consumer tcp://localhost:1883 4711
java -cp out/production/mqtt;../../libs/mqtt/* session.SessionManager tcp://localhost:1883 4711 unsubscribe
