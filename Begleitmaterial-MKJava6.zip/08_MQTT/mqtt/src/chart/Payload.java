package chart;

public class Payload {
	public String time;
	public int data;

	public Payload(String time, int data) {
		this.time = time;
		this.data = data;
	}

	public String toString() {
		return time + "#" + data;
	}

	public static Payload fromString(String s) {
		var parts = s.split("#");
		return new Payload(parts[0], Integer.parseInt(parts[1]));
	}
}
