package chart;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.io.IOException;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ThreadLocalRandom;

public class Publisher implements AutoCloseable {
	private static final String TOPIC = "sensor/data";
	private final MqttClient client;

	public Publisher(String url) throws MqttException {
		var clientId = MqttClient.generateClientId();
		var client = new MqttClient(url, clientId);
		var options = new MqttConnectOptions();
		options.setAutomaticReconnect(true);
		client.connect(options);
		this.client = client;
	}

	public void publish() throws MqttException {
		var msg = new MqttMessage(getData());
		msg.setQos(0);
		client.publish(TOPIC, msg);
	}

	@Override
	public void close() throws MqttException {
		client.disconnect();
		client.close();
	}

	private static byte[] getData() {
		var formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
		var payload = new Payload(
				formatter.format(LocalTime.now()),
				ThreadLocalRandom.current().nextInt(1000, 10000));
		return payload.toString().getBytes();
	}

	public static void main(String[] args) {
		var url = args[0];

		try (var publisher = new Publisher(url)) {
			var thread = new Thread(() -> {
				while (true) {
					try {
						publisher.publish();
						Thread.sleep(1000);
					} catch (MqttException e) {
						System.out.println(e.getMessage());
					} catch (InterruptedException e) {
						break;
					}
				}
			});
			thread.start();

			System.out.println("Stoppen mit ENTER");
			System.in.read();
			thread.interrupt();
		} catch (MqttException | IOException e) {
			System.out.println(e.getMessage());
		}
	}
}
