package chart;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Consumer;

public class LiveChart extends Application {
	private static final String TOPIC = "sensor/data";
	private static final long PERIOD = 5000; // Millisekunden
	private static final int WINDOW_SIZE = 10;

	private String url;
	private XYChart.Series<String, Number> series;
	private MqttClient client;

	@Override
	public void start(Stage primaryStage) {
		primaryStage.setTitle("Live Chart");

		var xAxis = new CategoryAxis();
		var yAxis = new NumberAxis();
		xAxis.setLabel("Uhrzeit");
		xAxis.setAnimated(false);
		yAxis.setLabel("Wert");
		yAxis.setAnimated(false);

		var lineChart = new LineChart<>(xAxis, yAxis);
		lineChart.setTitle("Live Chart");
		lineChart.setAnimated(false);
		lineChart.setLegendVisible(false);

		series = new XYChart.Series<>();
		lineChart.getData().add(series);

		var scene = new Scene(lineChart, 800, 600);
		primaryStage.setScene(scene);
		primaryStage.show();

		var params = getParameters().getRaw();
		url = params.get(0);

		buildClient();
		if (client != null)
			subscribe();
	}

	@Override
	public void stop() throws Exception {
		super.stop();
		client.disconnect();
		client.close();
	}

	private void buildClient() {
		try {
			var clientId = MqttClient.generateClientId();
			var client = new MqttClient(url, clientId);
			var options = new MqttConnectOptions();
			options.setAutomaticReconnect(true);
			client.connect(options);
			this.client = client;
		} catch (MqttException e) {
			showError(e);
		}
	}

	private void subscribe() {
		try {
			var last = new AtomicLong(0);
			client.subscribe(TOPIC, 0, (topic, msg) -> throttle(last, msg, display));
		} catch (MqttException e) {
			showError(e);
		}
	}

	private void throttle(AtomicLong last, MqttMessage msg, Consumer<MqttMessage> consumer) {
		var current = System.currentTimeMillis();
		if (current - last.get() > PERIOD) {
			last.set(System.currentTimeMillis());
			consumer.accept(msg);
		}
	}

	private final Consumer<MqttMessage> display = msg -> {
		var message = new String(msg.getPayload());
		var payload = Payload.fromString(message);
		Platform.runLater(() -> {
			series.getData().add(new XYChart.Data<>(payload.time, payload.data));
			if (series.getData().size() > WINDOW_SIZE)
				series.getData().remove(0);
		});
	};

	private void showError(MqttException e) {
		Platform.runLater(() -> {
			var alert = new Alert(Alert.AlertType.ERROR);
			alert.setContentText(e.getMessage());
			alert.showAndWait();
			System.exit(1);
		});
	}

	public static void main(String[] args) {
		launch(args);
	}
}