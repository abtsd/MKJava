package sensor;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.io.IOException;
import java.util.Scanner;
import java.util.regex.Pattern;

public class CPUTempPublisher implements AutoCloseable {
	private static final String TOPIC = "sensor/temperature/cpu";
	private final MqttClient client;
	private final boolean rpi;

	public CPUTempPublisher(String url, boolean rpi) throws MqttException {
		this.rpi = rpi;
		var clientId = MqttClient.generateClientId();
		var client = new MqttClient(url, clientId);
		var options = new MqttConnectOptions();
		options.setAutomaticReconnect(true);
		client.connect(options);
		this.client = client;
	}

	public void publish() throws MqttException {
		if (rpi) {
			try {
				var msg = readRpiTemp();
				msg.setQos(0);
				msg.setRetained(true);
				client.publish(TOPIC, msg);
			} catch (IOException | InterruptedException e) {
				System.out.println(e.getMessage());
			}
		} else {
			var msg = readSimulatedTemp();
			msg.setQos(0);
			msg.setRetained(true);
			client.publish(TOPIC, msg);
		}
	}

	@Override
	public void close() throws MqttException {
		client.disconnect();
		client.close();
	}

	private static MqttMessage readSimulatedTemp() {
		var temp = 35 + Math.random() * 10.0;
		System.out.println(temp + " C°");
		var payload = String.format("%.1f", temp).getBytes();
		return new MqttMessage(payload);
	}

	// Raspberry Pi
	private static MqttMessage readRpiTemp() throws IOException, InterruptedException {
		var builder = new ProcessBuilder();
		builder.command("vcgencmd", "measure_temp");
		var process = builder.start();
		var status = process.waitFor();
		var temp = 0.;
		if (status == 0) {
			try (var scanner = new Scanner(process.getInputStream())) {
				var line = scanner.next();
				var matcher = Pattern.compile("\\d+\\.\\d+").matcher(line);
				if (matcher.find())
					temp = Double.parseDouble(matcher.group());
			}
		}
		System.out.println("Raspberry Pi: " + temp + " C°");
		var payload = String.format("%.1f", temp).getBytes();
		return new MqttMessage(payload);
	}

	public static void main(String[] args) {
		var url = args[0];
		var rpi = false;
		if (args.length == 2 && args[1].equals("rpi"))
			rpi = true;

		try (var publisher = new CPUTempPublisher(url, rpi)) {
			var thread = new Thread(() -> {
				while (true) {
					try {
						publisher.publish();
						Thread.sleep(15000);
					} catch (MqttException e) {
						System.err.println(e.getMessage());
					} catch (InterruptedException e) {
						break;
					}
				}
			});
			thread.start();

			System.out.println("Stoppen mit ENTER");
			System.in.read();
			thread.interrupt();
		} catch (MqttException | IOException e) {
			System.err.println(e.getMessage());
		}
	}
}
