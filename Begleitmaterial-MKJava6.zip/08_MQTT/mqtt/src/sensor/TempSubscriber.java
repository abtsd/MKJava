package sensor;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;

import java.io.IOException;

public class TempSubscriber implements AutoCloseable {
	private final String topic;
	private final MqttClient client;

	public TempSubscriber(String url, String topic) throws MqttException {
		this.topic = topic;
		var clientId = MqttClient.generateClientId();
		var client = new MqttClient(url, clientId);
		var options = new MqttConnectOptions();
		options.setAutomaticReconnect(true);
		client.connect(options);
		this.client = client;
	}

	public void subscribe() throws MqttException {
		client.subscribe(topic, 0, (topic, msg) -> {
			var temp = new String(msg.getPayload());
			System.out.println(topic + ": " + temp + " C°");
		});
	}

	@Override
	public void close() throws MqttException {
		client.disconnect();
		client.close();
	}

	public static void main(String[] args) {
		var url = args[0];
		var topic = args[1];

		try (var subscriber = new TempSubscriber(url, topic)) {
			subscriber.subscribe();
			System.out.println("Stoppen mit ENTER");
			System.in.read();
		} catch (MqttException | IOException e) {
			System.out.println(e.getMessage());
		}
	}
}
