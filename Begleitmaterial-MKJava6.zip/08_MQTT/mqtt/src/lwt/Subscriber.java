package lwt;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;

import java.io.IOException;

public class Subscriber implements AutoCloseable {
	private static final String TOPIC = "lwt/+";
	private final MqttClient client;

	public Subscriber(String url) throws MqttException {
		var clientId = MqttClient.generateClientId();
		var client = new MqttClient(url, clientId);
		var options = new MqttConnectOptions();
		options.setAutomaticReconnect(true);
		client.connect(options);
		this.client = client;
	}

	public void subscribe() throws MqttException {
		client.subscribe(TOPIC, 1, (topic, msg) -> {
			var message = new String(msg.getPayload());
			System.out.println(topic + ": " + message);
		});
	}

	@Override
	public void close() throws MqttException {
		client.disconnect();
		client.close();
	}

	public static void main(String[] args) {
		var url = args[0];

		try (var subscriber = new Subscriber(url)) {
			subscriber.subscribe();
			System.out.println("Stoppen mit ENTER");
			System.in.read();
		} catch (MqttException | IOException e) {
			System.out.println(e.getMessage());
		}
	}
}
