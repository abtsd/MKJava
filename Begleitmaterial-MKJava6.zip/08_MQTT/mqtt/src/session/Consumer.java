package session;

import org.eclipse.paho.client.mqttv3.*;

import java.io.IOException;

public class Consumer implements AutoCloseable {
	private final MqttClient client;

	public Consumer(String url, String clientId) throws MqttException {
		var client = new MqttClient(url, clientId);
		var options = new MqttConnectOptions();
		options.setAutomaticReconnect(true);
		options.setCleanSession(false);

		client.setCallback(new MqttCallback() {
			@Override
			public void connectionLost(Throwable throwable) {
			}

			@Override
			public void messageArrived(String topic, MqttMessage mqttMessage) {
				var message = new String(mqttMessage.getPayload());
				System.out.println(message);
			}

			@Override
			public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {
			}
		});

		client.connect(options);
		this.client = client;
	}

	@Override
	public void close() throws MqttException {
		client.disconnect();
		client.close();
	}

	public static void main(String[] args) {
		var url = args[0];
		var clientId = args[1];

		try (var consumer = new Consumer(url, clientId)) {
			System.out.println("Stoppen mit ENTER");
			System.in.read();
		} catch (MqttException | IOException e) {
			System.out.println(e.getMessage());
		}
	}
}
