package session;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class Publisher implements AutoCloseable {
	private static final String TOPIC = "session/demo";
	private final MqttClient client;

	public Publisher(String url) throws MqttException {
		var clientId = MqttClient.generateClientId();
		var client = new MqttClient(url, clientId);
		var options = new MqttConnectOptions();
		options.setAutomaticReconnect(true);
		client.connect(options);
		this.client = client;
	}

	public void publish(String topic, String message) throws MqttException {
		var payload = message.getBytes();
		var msg = new MqttMessage(payload);
		msg.setQos(1);
		client.publish(topic, msg);
	}

	@Override
	public void close() throws MqttException {
		client.disconnect();
		client.close();
	}

	public static void main(String[] args) {
		var url = args[0];

		try (var publisher = new Publisher(url)) {
			var formatter = DateTimeFormatter.ofPattern("HH:mm:ss");

			for (var i = 0; i < 10; i++) {
				var msg = formatter.format(LocalTime.now()) + " " + i;
				publisher.publish(TOPIC, msg);
				System.out.println(msg);
				Thread.sleep(3000);
			}
		} catch (MqttException | InterruptedException e) {
			System.out.println(e.getMessage());
		}
	}
}
