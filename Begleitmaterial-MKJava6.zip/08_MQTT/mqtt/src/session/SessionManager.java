package session;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;

public class SessionManager {
	private static final String TOPIC = "session/demo";

	public static void main(String[] args) {
		var url = args[0];
		var clientId = args[1];
		var op = args[2];

		try {
			var client = new MqttClient(url, clientId);
			var options = new MqttConnectOptions();
			options.setAutomaticReconnect(true);

			if (op.equals("subscribe"))
				options.setCleanSession(false);	// persistent session
			else if (op.equals("unsubscribe"))
				options.setCleanSession(true);
			client.connect(options);

			if (op.equals("subscribe"))
				client.subscribe(TOPIC, 1);
			else if (op.equals("unsubscribe"))
				client.unsubscribe(TOPIC);

			client.disconnect();
			client.close();
		} catch (MqttException e) {
			System.out.println(e.getMessage());
		}
	}
}
