package control;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.io.IOException;

public class Sensor implements AutoCloseable {
    private static final String TOPIC_STATUS = "light/status";
    private static final String TOPIC_CONTROL = "light/control";
    private final MqttClient client;
    private final LightSensor lightSensor;

    public Sensor(String url) throws MqttException, IOException {
        var clientId = MqttClient.generateClientId();
        var client = new MqttClient(url, clientId);
        var options = new MqttConnectOptions();
        options.setAutomaticReconnect(true);
        client.connect(options);
        this.client = client;

        lightSensor = new LightSensor();
    }

    public void publish(String topic, String message) throws MqttException {
        var payload = message.getBytes();
        var msg = new MqttMessage(payload);
        msg.setQos(0);
        msg.setRetained(true);
        client.publish(topic, msg);
    }

    public void subscribe() throws MqttException {
        client.subscribe(TOPIC_CONTROL, 0, (topic, msg) -> {
            var message = new String(msg.getPayload());
            if (message.equals("toggle"))
                lightSensor.toggle();
        });
    }

    @Override
    public void close() throws MqttException {
        client.disconnect();
        client.close();
    }

    public static void main(String[] args) {
        var url = args[0];

        try (var sensor = new Sensor(url)) {
            sensor.subscribe();

            var thread = new Thread(() -> {
                while (true) {
                    try {
                        var status = sensor.lightSensor.getStatus() == 0 ? "OFF" : "ON";
                        sensor.publish(TOPIC_STATUS, status);
                        Thread.sleep(5000);
                    } catch (MqttException | IOException e) {
                        System.out.println(e.getMessage());
                    } catch (InterruptedException e) {
                        break;
                    }
                }
            });
            thread.start();

            System.out.println("Stoppen mit ENTER");
            System.in.read();
            thread.interrupt();
        } catch (MqttException | IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
