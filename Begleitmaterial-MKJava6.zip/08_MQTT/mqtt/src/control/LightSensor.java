package control;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class LightSensor {
	private static final Path PATH = Paths.get("light.txt");

	public LightSensor() throws IOException {
		if (!Files.exists(PATH))
			Files.writeString(PATH, "0");
	}

	public int getStatus() throws IOException {
		var value = Files.readString(PATH);
		return value.equals("0") ? 0 : 1;
	}

	public void toggle() throws IOException {
		var status = getStatus() == 0 ? 1 : 0;
		Files.writeString(PATH, String.valueOf(status));
	}

	// Test des Sensors
	public static void main(String[] args) throws IOException {
		var sensor = new LightSensor();
		System.out.println(sensor.getStatus());
		sensor.toggle();
		System.out.println(sensor.getStatus());
	}
}
