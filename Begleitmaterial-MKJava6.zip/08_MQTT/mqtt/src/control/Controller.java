package control;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class Controller implements AutoCloseable {
    private static final String TOPIC_STATUS = "light/status";
    private static final String TOPIC_CONTROL = "light/control";
    private final MqttClient client;

    public Controller(String url) throws MqttException {
        var clientId = MqttClient.generateClientId();
        var client = new MqttClient(url, clientId);
        var options = new MqttConnectOptions();
        options.setAutomaticReconnect(true);
        client.connect(options);
        this.client = client;
    }

    public void publish(String topic, String message) throws MqttException {
        var payload = message.getBytes();
        var msg = new MqttMessage(payload);
        msg.setQos(0);
        client.publish(topic, msg);
    }

    public void subscribe() throws MqttException, InterruptedException {
        var receivedSignal = new CountDownLatch(1);
        client.subscribe(TOPIC_STATUS, 0, (topic, msg) -> {
            var message = new String(msg.getPayload());
            System.out.println(message);
            receivedSignal.countDown();
        });
        receivedSignal.await(10, TimeUnit.SECONDS);
    }

    @Override
    public void close() throws MqttException {
        client.disconnect();
        client.close();
    }

    public static void main(String[] args) {
        var url = args[0];
        var value = args.length == 2 ? args[1] : null;

        try (var controller = new Controller(url)) {
            if (value == null) {
                controller.subscribe();
            } else {
                if (value.equalsIgnoreCase("TOGGLE"))
                    controller.publish(TOPIC_CONTROL, "toggle");
            }
        } catch (MqttException | InterruptedException e) {
            System.out.println(e.getMessage());
        }
    }
}
