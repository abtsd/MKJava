package chat;

import jakarta.json.bind.Jsonb;
import jakarta.json.bind.JsonbBuilder;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Chat implements AutoCloseable {
	private static final String TOPIC = "chat";
	private final MqttClient client;
	private final String clientId;
	private final String name;
	private final Jsonb jsonb;

	public Chat(String url, String name) throws MqttException {
		this.name = name;
		clientId = MqttClient.generateClientId();
		var client = new MqttClient(url, clientId);
		var options = new MqttConnectOptions();
		options.setAutomaticReconnect(true);
		client.connect(options);
		this.client = client;
		jsonb = JsonbBuilder.create();

		publish("angemeldet");
	}

	public void publish(String text) throws MqttException {
		var jsonStr = jsonb.toJson(new Payload(name, text, clientId));
		var payload = jsonStr.getBytes(StandardCharsets.UTF_8);
		var msg = new MqttMessage(payload);
		msg.setQos(0);
		client.publish(TOPIC, msg);
	}

	public void subscribe() throws MqttException {
		client.subscribe(TOPIC, 0, (topic, msg) -> {
			var json = new String(msg.getPayload(), StandardCharsets.UTF_8);
			var payload = jsonb.fromJson(json, Payload.class);
			// Die eigene Nachricht wird nicht angezeigt
			if (!payload.getId().equals(clientId)) {
				System.out.println(payload.getName() + ": " + payload.getText());
			}
		});
	}

	@Override
	public void close() throws MqttException {
		publish("abgemeldet");
		client.disconnect();
		client.close();
	}

	public static void main(String[] args) {
		var url = args[0];
		var name = args[1];

		try (var chat = new Chat(url, name)) {
			chat.subscribe();

			try (var scanner = new Scanner(System.in)) {
				while (true) {
					var input = scanner.nextLine().trim();
					if (input.equals("q")) {
						break;
					} else {
						if (input.length() > 0) {
							chat.publish(input);
						}
					}
				}
			}
		} catch (MqttException e) {
			System.out.println(e.getMessage());
		}
	}
}
