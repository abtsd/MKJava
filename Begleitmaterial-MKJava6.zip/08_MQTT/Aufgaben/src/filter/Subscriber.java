package filter;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;

public class Subscriber implements AutoCloseable {
    private static final String TOPIC_BASE = "news/priority/";
    private final String priority;
    private final MqttClient client;

    public Subscriber(String url, String priority) throws MqttException {
        this.priority = priority;
        var clientId = MqttClient.generateClientId();
        var client = new MqttClient(url, clientId);
        var options = new MqttConnectOptions();
        options.setAutomaticReconnect(true);
        client.connect(options);
        this.client = client;
    }

    public void subscribe() throws MqttException {
        client.subscribe(TOPIC_BASE + priority, 0, (topic, msg) -> {
            var message = new String(msg.getPayload());
            var p = topic.substring(topic.lastIndexOf("/") + 1);
            System.out.println(message + ": " + p);
        });
    }

    @Override
    public void close() throws MqttException {
        client.disconnect();
        client.close();
    }

    public static void main(String[] args) {
        var url = args[0];
        var priority = args[1];

        try (var subscriber = new Subscriber(url, priority)) {
            subscriber.subscribe();
            Thread.sleep(30000);
        } catch (MqttException | InterruptedException e) {
            System.out.println(e.getMessage());
        }
    }
}
