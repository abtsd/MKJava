package filter;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class Publisher implements AutoCloseable {
	private static final String TOPIC_BASE = "news/priority/";
	private final MqttClient client;

	public Publisher(String url) throws MqttException {
		var clientId = MqttClient.generateClientId();
		var client = new MqttClient(url, clientId);
		var options = new MqttConnectOptions();
		options.setAutomaticReconnect(true);
		client.connect(options);
		this.client = client;
	}

	public void publish(String topic, String message) throws MqttException {
		var payload = message.getBytes();
		var msg = new MqttMessage(payload);
		msg.setQos(0);
		client.publish(topic, msg);
	}

	@Override
	public void close() throws MqttException {
		client.disconnect();
		client.close();
	}

	public static void main(String[] args) {
		var url = args[0];

		try (var publisher = new Publisher(url)) {
			for (var i = 0; i < 60; i++) {
				var message = "Nachricht " + i;

				var priority = "";
				if (Math.random() < 0.25) {
					priority = "low";
				} else if (Math.random() < 0.75) {
					priority = "normal";
				} else {
					priority = "high";
				}

				publisher.publish(TOPIC_BASE + priority, message);
				System.out.println(message + ": " + priority);
				Thread.sleep(1000);
			}
		} catch (MqttException | InterruptedException e) {
			System.out.println(e.getMessage());
		}
	}
}
