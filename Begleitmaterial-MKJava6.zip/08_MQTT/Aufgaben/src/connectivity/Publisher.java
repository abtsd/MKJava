package connectivity;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.io.IOException;

public class Publisher implements AutoCloseable {
    private static final String TOPIC = "sensor/data";
    private final MqttClient client;

    public Publisher(String url) throws MqttException {
        var clientId = MqttClient.generateClientId();
        var client = new MqttClient(url, clientId);
        var options = new MqttConnectOptions();
        options.setAutomaticReconnect(true);
        client.connect(options);
        this.client = client;
    }

    public void publish() throws MqttException {
        var msg = readSimulatedTemp();
        msg.setQos(0);
        msg.setRetained(true);
        client.publish(TOPIC, msg);
    }

    @Override
    public void close() throws MqttException {
        client.disconnect();
        client.close();
    }

    private static MqttMessage readSimulatedTemp() {
        var temp = 20 + Math.random();
        System.out.println(temp + " C°");
        var payload = String.format("%.1f", temp).getBytes();
        return new MqttMessage(payload);
    }

    public static void main(String[] args) {
        var url = args[0];

        try (var publisher = new Publisher(url)) {
            var thread = new Thread(() -> {
                while (true) {
                    try {
                        publisher.publish();
                        Thread.sleep(10000);
                    } catch (MqttException e) {
                        System.err.println(e.getMessage());
                    } catch (InterruptedException e) {
                        break;
                    }
                }
            });
            thread.start();

            System.out.println("Stoppen mit ENTER");
            System.in.read();
            thread.interrupt();
        } catch (MqttException | IOException e) {
            System.err.println(e.getMessage());
        }
    }
}
