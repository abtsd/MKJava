package connectivity;

import javax.jms.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.io.IOException;
import java.util.Properties;

public class Subscriber {
	public static void main(String[] args) {
		var host = args[0];

		Connection connection = null;
		try {
			var props = new Properties();
			props.setProperty(Context.INITIAL_CONTEXT_FACTORY,
					"org.apache.activemq.jndi.ActiveMQInitialContextFactory");
			props.setProperty(Context.PROVIDER_URL, "tcp://" + host + ":61616");
			var ctx = new InitialContext(props);
			var factory = (ConnectionFactory) ctx.lookup("ConnectionFactory");
			var topic = (Destination) ctx.lookup("dynamicTopics/sensor.data");

			connection = factory.createConnection();
			var session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			var messageConsumer = session.createConsumer(topic);
			messageConsumer.setMessageListener(Subscriber::handleMessage);
			connection.start();

			System.out.println("Stoppen mit ENTER");
			System.in.read();
		} catch (NamingException | JMSException | IOException e) {
			System.err.println(e.getMessage());
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (JMSException e) {
					System.err.println(e.getMessage());
				}
			}
		}
	}

	private static void handleMessage(Message message) {
		try {
			if (message instanceof BytesMessage) {
				var bytesMessage = (BytesMessage) message;
				var bytes = new byte[(int) bytesMessage.getBodyLength()];
				bytesMessage.readBytes(bytes);
				System.out.println(new String(bytes));
			}
		} catch (JMSException e) {
			System.err.println(e.getMessage());
		}
	}
}
