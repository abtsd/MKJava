java -cp out/production/Aufgaben;../../libs/mqtt/* filter.Publisher tcp://localhost:1883
java -cp out/production/Aufgaben;../../libs/mqtt/* filter.Subscriber tcp://localhost:1883 +
java -cp out/production/Aufgaben;../../libs/mqtt/* filter.Subscriber tcp://localhost:1883 low
java -cp out/production/Aufgaben;../../libs/mqtt/* filter.Subscriber tcp://localhost:1883 normal
java -cp out/production/Aufgaben;../../libs/mqtt/* filter.Subscriber tcp://localhost:1883 high

# Zur Ausgabe von Sonderzeichen bei Windows: chcp 1252
java -cp out/production/Aufgaben;../../libs/mqtt/*;../../libs/json/* chat.Chat tcp://localhost:1883 Hugo
java -cp out/production/Aufgaben;../../libs/mqtt/*;../../libs/json/* chat.Chat tcp://localhost:1883 Emil

java -cp out/production/Aufgaben;../../libs/mqtt/* connectivity.Publisher tcp://localhost:1883


