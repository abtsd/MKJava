package error_demo;

import io.rsocket.Payload;
import io.rsocket.RSocket;
import io.rsocket.SocketAcceptor;
import io.rsocket.core.RSocketServer;
import io.rsocket.transport.netty.server.TcpServerTransport;
import io.rsocket.util.DefaultPayload;
import reactor.core.Disposable;
import reactor.core.publisher.Mono;

import java.io.IOException;

public class EchoServer {
    private final Disposable server;

    public EchoServer() {
        server = RSocketServer.create(SocketAcceptor.with(new RSocketImpl()))
                .bind(TcpServerTransport.create(50000))
                .block();
    }

    public void stop() {
        server.dispose();
    }

    private static class RSocketImpl implements RSocket {
        @Override
        public Mono<Payload> requestResponse(Payload payload) {
            try {
                var text = payload.getDataUtf8();
                if (text.trim().length() == 0) {
                    throw new IllegalArgumentException("Text ist leer.");
                }
                return Mono.just(DefaultPayload.create(text));
            } catch (Exception e) {
                return Mono.error(e);
            }
        }
    }

    public static void main(String[] args) throws IOException {
        var server = new EchoServer();
        System.out.println("Stoppen mit ENTER");
        System.in.read();
        server.stop();
    }
}
