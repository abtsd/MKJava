package error_demo;

import io.rsocket.Payload;
import io.rsocket.RSocket;
import io.rsocket.core.RSocketConnector;
import io.rsocket.transport.netty.client.TcpClientTransport;
import io.rsocket.util.DefaultPayload;

import java.util.Scanner;

public class EchoClient {
    private final RSocket socket;

    public EchoClient(String host) {
        socket = RSocketConnector.create()
                .connect(TcpClientTransport.create(host, 50000))
                .block();
    }

    public String send(String text) {
        return socket
                .requestResponse(DefaultPayload.create(text))
                .map(Payload::getDataUtf8)
                .block();
    }

    public void stop() {
        socket.dispose();
    }

    public static void main(String[] args) {
        var client = new EchoClient(args[0]);
        var scanner = new Scanner(System.in);
        while (true) {
            System.out.print("> ");
            var line = scanner.nextLine();
            if (line.equals("q"))
                break;
            String response = null;
            try {
                response = client.send(line);
                System.out.println(response);
            } catch (Exception e) {
                System.out.println("Fehler: " + e.getMessage());
            }
        }
        scanner.close();
        client.stop();
    }
}
