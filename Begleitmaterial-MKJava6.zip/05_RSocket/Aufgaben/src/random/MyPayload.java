package random;

public class MyPayload {
    private int bound;
    private int count;
    private int delay;

    public MyPayload() {
    }

    public MyPayload(int bound, int count, int delay) {
        this.bound = bound;
        this.count = count;
        this.delay = delay;
    }

    public int getBound() {
        return bound;
    }

    public void setBound(int bound) {
        this.bound = bound;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getDelay() {
        return delay;
    }

    public void setDelay(int delay) {
        this.delay = delay;
    }
}
