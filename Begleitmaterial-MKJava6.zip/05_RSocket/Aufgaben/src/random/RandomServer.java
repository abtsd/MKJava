package random;

import io.rsocket.Payload;
import io.rsocket.RSocket;
import io.rsocket.SocketAcceptor;
import io.rsocket.core.RSocketServer;
import io.rsocket.transport.netty.server.TcpServerTransport;
import io.rsocket.util.DefaultPayload;
import jakarta.json.bind.JsonbBuilder;
import reactor.core.Disposable;
import reactor.core.publisher.Flux;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.time.Duration;
import java.util.Random;

public class RandomServer {
    private final Disposable server;

    public RandomServer() {
        server = RSocketServer.create(SocketAcceptor.with(new RSocketImpl()))
                .bind(TcpServerTransport.create(50000))
                .block();
    }

    public void stop() {
        server.dispose();
    }

    private static class RSocketImpl implements RSocket {
        @Override
        public Flux<Payload> requestStream(Payload payload) {
            var json = payload.getDataUtf8();
            var jsonb = JsonbBuilder.create();
            MyPayload myPayload = jsonb.fromJson(json, MyPayload.class);
            var bound = myPayload.getBound();
            var count = myPayload.getCount();
            var delay = myPayload.getDelay();

            var random = new Random();
            var buffer = ByteBuffer.allocate(4);
            return Flux.interval(Duration.ofSeconds(delay))
                    .take(count)
                    .map(i -> buffer.clear().putInt(random.nextInt(bound)).rewind())
                    .map(DefaultPayload::create);
        }
    }

    public static void main(String[] args) throws IOException {
        var server = new RandomServer();
        System.out.println("Stoppen mit ENTER");
        System.in.read();
        server.stop();
    }
}
