package random;

import io.rsocket.RSocket;
import io.rsocket.core.RSocketConnector;
import io.rsocket.transport.netty.client.TcpClientTransport;
import io.rsocket.util.DefaultPayload;
import jakarta.json.bind.JsonbBuilder;

import java.util.concurrent.CountDownLatch;

public class RandomClient {
    private final RSocket socket;
    private static CountDownLatch latch;

    public RandomClient(String host) {
        socket = RSocketConnector.create()
                .connect(TcpClientTransport.create(host, 50000))
                .block();
    }

    public void request(String payload) {
        latch = new CountDownLatch(1);
        socket.requestStream(DefaultPayload.create(payload))
                .map(p -> p.getData().getInt())
                .doOnComplete(latch::countDown)
                .subscribe(System.out::println);
    }

    public void stop() {
        socket.dispose();
    }

    public static void main(String[] args) throws InterruptedException {
        var client = new RandomClient(args[0]);
        var myPayload = new MyPayload(1000, 10, 3);
        var jsonb = JsonbBuilder.create();
        var json = jsonb.toJson(myPayload);
        client.request(json);
        latch.await();
        client.stop();
    }
}
