package sensor;

import io.rsocket.RSocket;
import io.rsocket.core.RSocketConnector;
import io.rsocket.transport.netty.client.TcpClientTransport;
import io.rsocket.util.DefaultPayload;
import reactor.core.publisher.Flux;

import java.time.Duration;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;

public class Sender {
    private final RSocket socket;

    public Sender(String host) {
        socket = RSocketConnector.create()
                .connect(TcpClientTransport.create(host, 50000))
                .block();
    }

    private String generateData() {
        var time = ZonedDateTime.now(ZoneOffset.UTC);
        var value = 30 + Math.random();
        return String.format("%19.19s %.2f C°", time, value);
    }

    public void send() {
        Flux.interval(Duration.ofSeconds(5))
                .map(i -> generateData())
                .map(DefaultPayload::create)
                .flatMap(socket::fireAndForget)
                .blockLast();
    }

    public static void main(String[] args) {
        var client = new Sender(args[0]);
        client.send();
    }
}
