package sensor;

import io.rsocket.Payload;
import io.rsocket.RSocket;
import io.rsocket.SocketAcceptor;
import io.rsocket.core.RSocketServer;
import io.rsocket.transport.netty.server.TcpServerTransport;
import reactor.core.Disposable;
import reactor.core.publisher.Mono;

import java.io.IOException;

public class Receiver {
    private final Disposable server;

    public Receiver() {
        server = RSocketServer.create(SocketAcceptor.with(new RSocketImpl()))
                .bind(TcpServerTransport.create(50000))
                .block();
    }

    public void stop() {
        server.dispose();
    }

    private static class RSocketImpl implements RSocket {
        @Override
        public Mono<Void> fireAndForget(Payload payload) {
            System.out.println(payload.getDataUtf8());
            return Mono.empty();
        }
    }

    public static void main(String[] args) throws IOException {
        var server = new Receiver();
        System.out.println("Stoppen mit ENTER");
        System.in.read();
        server.stop();
    }
}
