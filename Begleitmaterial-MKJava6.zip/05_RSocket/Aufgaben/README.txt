java -cp out/production/Aufgaben;../../libs/rsocket/* echo.EchoServer
# Zur Ausgabe von Sonderzeichen bei Windows: chcp 1252
java -cp out/production/Aufgaben;../../libs/rsocket/* echo.EchoClient localhost

java -cp out/production/Aufgaben;../../libs/rsocket/* sensor.Receiver
java -cp out/production/Aufgaben;../../libs/rsocket/* sensor.Sender localhost

java -cp out/production/Aufgaben;../../libs/rsocket/*;../../libs/json/* random.RandomServer
java -cp out/production/Aufgaben;../../libs/rsocket/*;../../libs/json/* random.RandomClient localhost

java -cp out/production/Aufgaben;../../libs/rsocket/* error_demo.EchoServer
java -cp out/production/Aufgaben;../../libs/rsocket/* error_demo.EchoClient localhost
