package interaction_models;

import io.rsocket.RSocket;
import io.rsocket.core.RSocketConnector;
import io.rsocket.transport.netty.client.TcpClientTransport;
import io.rsocket.util.DefaultPayload;
import reactor.core.publisher.Flux;

import java.nio.ByteBuffer;
import java.time.Duration;
import java.util.Random;

public class FireAndForgetClient {
    private final RSocket socket;

    public FireAndForgetClient(String host) {
        socket = RSocketConnector.create()
                .connect(TcpClientTransport.create(host, 50000))
                .block();
    }

    public void fireAndForget(int n) {
        var buffer = ByteBuffer.allocate(4);
        var random = new Random();
        Flux.interval(Duration.ofSeconds(1))
                .take(n)
                .map(i -> buffer.clear().putInt(random.nextInt(100)).rewind())
                .map(DefaultPayload::create)
                .flatMap(socket::fireAndForget)
                .blockLast(); // subscribe and block
    }

    public void stop() {
        socket.dispose();
    }

    public static void main(String[] args) {
        var host = args[0];
        var client = new FireAndForgetClient(host);
        client.fireAndForget(5);
        client.stop();
    }
}
