package interaction_models;

import io.rsocket.RSocket;
import io.rsocket.core.RSocketConnector;
import io.rsocket.transport.netty.client.TcpClientTransport;
import io.rsocket.util.DefaultPayload;
import reactor.core.Disposable;
import reactor.core.publisher.Flux;

import java.io.IOException;
import java.time.Duration;
import java.util.Random;

public class ChannelClient {
    private final RSocket socket;

    public ChannelClient(String host) {
        socket = RSocketConnector
                .connectWith(TcpClientTransport.create(host, 50000))
                .block();
    }

    public Disposable run() {
        return socket.requestChannel(subscriber -> {
            var random = new Random();
            Flux.interval(Duration.ofSeconds(1))
                    .map(i -> {
                        int n = random.nextInt(100);
                        System.out.println("send " + n);
                        return DefaultPayload.create(String.valueOf(n));
                    })
                    .subscribe(subscriber);
        }).subscribe(p -> System.out.println("received " + p.getDataUtf8()));
    }

    public void stop() {
        socket.dispose();
    }

    public static void main(String[] args) throws IOException {
        var host = args[0];
        var client = new ChannelClient(host);
        var disposable = client.run();
        System.out.println("Stoppen mit ENTER");
        System.in.read();
        disposable.dispose();
        client.stop();
    }
}
