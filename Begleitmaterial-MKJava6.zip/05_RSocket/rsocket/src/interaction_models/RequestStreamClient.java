package interaction_models;

import io.rsocket.RSocket;
import io.rsocket.core.RSocketConnector;
import io.rsocket.transport.netty.client.TcpClientTransport;
import io.rsocket.util.DefaultPayload;

import java.nio.ByteBuffer;
import java.util.concurrent.CountDownLatch;

public class RequestStreamClient {
    private final RSocket socket;
    private static CountDownLatch latch;

    public RequestStreamClient(String host) {
        socket = RSocketConnector.create()
                .connect(TcpClientTransport.create(host, 50000))
                .block();
    }

    public void callBlocking(int n) {
        var buffer = ByteBuffer.allocate(4).putInt(n).rewind();
        socket.requestStream(DefaultPayload.create(buffer))
                .map(p -> p.getData().getInt())
                .doOnNext(System.out::println)
                .blockLast(); // subscribe and block
    }

    public void callNonBlocking(int n) {
        var buffer = ByteBuffer.allocate(4).putInt(n).rewind();
        latch = new CountDownLatch(1);
        socket.requestStream(DefaultPayload.create(buffer))
                .map(p -> p.getData().getInt())
                .doOnComplete(latch::countDown)
                .subscribe(System.out::println);
    }

    public void stop() {
        socket.dispose();
    }

    public static void main(String[] args) throws InterruptedException {
        var host = args[0];
        var client = new RequestStreamClient(host);
        System.out.println("Blocking");
        client.callBlocking(5);
        System.out.println("Non Blocking");
        client.callNonBlocking(5);
        latch.await();
        client.stop();
    }
}
