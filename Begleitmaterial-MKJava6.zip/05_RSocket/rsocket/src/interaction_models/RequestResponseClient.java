package interaction_models;

import io.rsocket.Payload;
import io.rsocket.RSocket;
import io.rsocket.core.RSocketConnector;
import io.rsocket.transport.netty.client.TcpClientTransport;
import io.rsocket.util.DefaultPayload;

public class RequestResponseClient {
    private final RSocket socket;

    public RequestResponseClient(String host) {
        socket = RSocketConnector.create()
                .connect(TcpClientTransport.create(host, 50000))
                .block();
    }

    public String callBlocking(String text) {
        return socket.requestResponse(DefaultPayload.create(text))
                .map(Payload::getDataUtf8)
                .block(); // subscribe and block
    }

    public void stop() {
        socket.dispose();
    }

    public static void main(String[] args) {
        var host = args[0];
        var client = new RequestResponseClient(host);
        var response = client.callBlocking("Hallo Welt!");
        System.out.println(response);
        client.stop();
    }
}
