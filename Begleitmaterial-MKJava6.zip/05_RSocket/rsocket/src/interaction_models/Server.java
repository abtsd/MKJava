package interaction_models;

import io.rsocket.Payload;
import io.rsocket.RSocket;
import io.rsocket.SocketAcceptor;
import io.rsocket.core.RSocketServer;
import io.rsocket.transport.netty.server.TcpServerTransport;
import io.rsocket.util.DefaultPayload;
import org.reactivestreams.Publisher;
import reactor.core.Disposable;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.time.Duration;
import java.util.Random;

public class Server {
    private final Disposable server;

    public Server() {
        server = RSocketServer.create(SocketAcceptor.with(new RSocketImpl()))
                .bind(TcpServerTransport.create(50000))
                .block();
    }

    public void stop() {
        server.dispose();
    }

    private static class RSocketImpl implements RSocket {
        @Override
        public Mono<Void> fireAndForget(Payload payload) {
            System.out.println(payload.getData().getInt());
            return Mono.empty();
        }

        @Override
        public Mono<Payload> requestResponse(Payload payload) {
            var text = payload.getDataUtf8().toUpperCase();
            return Mono.just(DefaultPayload.create(text));
        }

        @Override
        public Flux<Payload> requestStream(Payload payload) {
            var n = payload.getData().getInt();
            var buffer = ByteBuffer.allocate(4);
            var random = new Random();
            return Flux.interval(Duration.ofSeconds(1))
                    .take(n)
                    .map(i -> buffer.clear().putInt(random.nextInt(100)).rewind())
                    .map(DefaultPayload::create);
        }

        @Override
        public Flux<Payload> requestChannel(Publisher<Payload> payloads) {
            return Flux.from(payloads)
                    .doOnNext(payload -> {
                        System.out.println(payload.getDataUtf8());
                    })
                    .map(payload -> {
                        int n = Integer.parseInt(payload.getDataUtf8());
                        return DefaultPayload.create(String.valueOf(n * n));
                    });
        }
    }

    public static void main(String[] args) throws IOException {
        var server = new Server();
        System.out.println("Stoppen mit ENTER");
        System.in.read();
        server.stop();
    }
}
