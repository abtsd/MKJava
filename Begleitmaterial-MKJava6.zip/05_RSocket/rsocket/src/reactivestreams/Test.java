package reactivestreams;

import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;
import reactor.core.publisher.Flux;
import reactor.core.scheduler.Schedulers;

import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.util.ArrayList;

public class Test {
    public static void main(String[] args) {
        testStaticStream();
//        testSubscriberImplementation();
//        testBackpressureAndCancel();
//        testMapping();
//        testCombining();
//        testConnectableFlux();
//        testThrottling();
    }

    private static void testStaticStream() {
        var elements = new ArrayList<Integer>();
        Flux.just(1, 2, 3, 4).subscribe(elements::add);
        System.out.println(elements);
    }

    private static void testSubscriberImplementation() {
        var elements = new ArrayList<Integer>();
        Flux.just(1, 2, 3, 4)
                .subscribe(new Subscriber<>() {
                    @Override
                    public void onSubscribe(Subscription s) {
                        s.request(Long.MAX_VALUE);
                    }

                    @Override
                    public void onNext(Integer integer) {
                        elements.add(integer);
                    }

                    @Override
                    public void onError(Throwable t) {
                        System.err.println(t.getMessage());
                    }

                    @Override
                    public void onComplete() {
                        System.out.println("Fertig");
                    }
                });
        System.out.println(elements);
    }

    private static void testBackpressureAndCancel() {
        var elements = new ArrayList<Integer>();
        Flux.just(1, 2, 3, 4, 5, 6, 7, 8, 9)
                .subscribe(new Subscriber<>() {
                    private Subscription s;
                    private final int reqLimit = 3;
                    private int reqCount;
                    private int count;

                    @Override
                    public void onSubscribe(Subscription s) {
                        this.s = s;
                        s.request(reqLimit);
                    }

                    @Override
                    public void onNext(Integer integer) {
                        System.out.println(integer);
                        elements.add(integer);
                        count++;
                        reqCount++;
                        if (reqCount == reqLimit) {
                            System.out.println("Verarbeiten");
                            try {
                                Thread.sleep(2000);
                            } catch (InterruptedException ignored) {
                            }
                            reqCount = 0;
                            s.request(reqLimit);
                        }
                        if (count == 6)
                            s.cancel();
                    }

                    @Override
                    public void onError(Throwable t) {
                        System.err.println(t.getMessage());
                    }

                    @Override
                    public void onComplete() {
                        System.out.println("Fertig");
                    }
                });
        System.out.println(elements);
    }

    private static void testMapping() {
        var elements = new ArrayList<Integer>();
        Flux.just(1, 2, 3, 4)
                .map(i -> i * i)
                .subscribe(elements::add);
        System.out.println(elements);
    }

    private static void testCombining() {
        var elements = new ArrayList<String>();
        Flux.just(1, 2, 3, 4)
                .map(i -> i * i)
                .zipWith(Flux.range(1, 10),
                        (a, b) -> String.format("(%d, %d)", b, a))
                .subscribe(elements::add);
        System.out.println(elements);
    }

    private static void testConnectableFlux() {
        var flux = Flux.range(1, 3).publish();
        flux.subscribe(t -> System.out.println("A " + t));
        flux.subscribe(t -> System.out.println("B " + t));
        flux.connect();
    }

    private static void testThrottling() {
        Flux<Long> flux = Flux.create(emitter -> {
            while (true) {
                emitter.next(System.currentTimeMillis());
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ignored) {
                }
            }
        });

        var connectableFlux = flux
                .sample(Duration.ofSeconds(5))
                .map(l -> Instant.ofEpochMilli(l)
                        .atZone(ZoneId.systemDefault()).toLocalTime())
                .subscribeOn(Schedulers.parallel())
                .publish();
        connectableFlux.subscribe(System.out::println);
        var disposable = connectableFlux.connect();

        try {
            Thread.sleep(30000);
        } catch (InterruptedException ignored) {
        }
        disposable.dispose();
    }
}
