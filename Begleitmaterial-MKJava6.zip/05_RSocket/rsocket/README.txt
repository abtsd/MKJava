java -cp out/production/pub_sub simple.Demo1
java -cp out/production/pub_sub flow.Demo2
java -cp out/production/rsocket;../../libs/rsocket/* reactivestreams.Test

java -cp out/production/rsocket;../../libs/rsocket/* interaction_models.Server
java -cp out/production/rsocket;../../libs/rsocket/* interaction_models.FireAndForgetClient localhost
java -cp out/production/rsocket;../../libs/rsocket/* interaction_models.RequestResponseClient localhost
java -cp out/production/rsocket;../../libs/rsocket/* interaction_models.RequestStreamClient localhost
java -cp out/production/rsocket;../../libs/rsocket/* interaction_models.ChannelClient localhost
