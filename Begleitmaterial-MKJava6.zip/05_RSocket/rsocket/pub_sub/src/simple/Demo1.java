package simple;

public class Demo1 {
    static class MyPublisher implements Publisher<Integer> {
        @Override
        public void subscribe(Subscriber<? super Integer> s) {
            setTimeout(() -> s.onNext(1), 1000);
            s.onNext(2);
            setTimeout(() -> {
                s.onNext(3);
                s.onComplete();
            }, 2000);
        }

        private void setTimeout(Runnable runnable, int delay) {
            new Thread(() -> {
                try {
                    Thread.sleep(delay);
                } catch (InterruptedException ignored) {
                }
                runnable.run();
            }).start();
        }
    }

    static class MySubscriber implements Subscriber<Integer> {
        @Override
        public void onSubscribe(Subscription s) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void onNext(Integer integer) {
            System.out.println("NEXT: " + integer);
        }

        @Override
        public void onError(Throwable t) {
            System.err.println("ERROR: " + t.getMessage());
        }

        @Override
        public void onComplete() {
            System.out.println("COMPLETE");
        }
    }

    public static void main(String[] args) {
        var myPublisher = new MyPublisher();
        var mySubscriber = new MySubscriber();
        myPublisher.subscribe(mySubscriber);
    }
}
