package flow;

import java.util.Random;
import java.util.concurrent.Flow;
import java.util.concurrent.SubmissionPublisher;

public class Demo2 {
    static class MyPublisher {
        private final SubmissionPublisher<Integer> submissionPublisher;
        private final Random random;
        private final int bound;
        private final int number;
        private final int delay;

        public MyPublisher(int bound, int number, int delay) {
            this.bound = bound;
            this.number = number;
            this.delay = delay;
            random = new Random();
            submissionPublisher = new SubmissionPublisher<>();
        }

        public void subscribe(Flow.Subscriber<Integer> subscriber) {
            submissionPublisher.subscribe(subscriber);
            for (var i = 0; i <= number; i++) {
                try {
                    Thread.sleep(delay);
                } catch (InterruptedException ignored) {
                }
                submissionPublisher.submit(random.nextInt(bound));
            }
            submissionPublisher.close();
        }
    }

    static class MySubscriber implements Flow.Subscriber<Integer> {
        private Flow.Subscription subscription;

        @Override
        public void onSubscribe(Flow.Subscription subscription) {
            this.subscription = subscription;
            this.subscription.request(1);
        }

        @Override
        public void onNext(Integer item) {
            System.out.println(item);
            subscription.request(1);
        }

        @Override
        public void onError(Throwable throwable) {
            System.err.println(throwable.getMessage());
        }

        @Override
        public void onComplete() {
            System.out.println("Fertig");
        }
    }

    public static void main(String[] args) {
        var myPublisher = new MyPublisher(100, 10, 1000);
        var mySubscriber = new MySubscriber();
        myPublisher.subscribe(mySubscriber);
    }
}
