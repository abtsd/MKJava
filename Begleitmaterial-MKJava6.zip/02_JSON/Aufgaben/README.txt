java -cp out/production/Aufgaben;../../libs/json/* person.Serialize
java -cp out/production/Aufgaben;../../libs/json/* person.Deserialize

java -cp out/production/Aufgaben;../../libs/json/* images.Serialize
java -cp out/production/Aufgaben;../../libs/json/* images.Deserialize
