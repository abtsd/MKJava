package person;

import jakarta.json.bind.JsonbBuilder;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.List;

public class Serialize {
	public static void main(String[] args) throws FileNotFoundException {
		var p = new Person(1, "Meier", 28);
		p.setHobbys(List.of("Schwimmen", "Lesen", "Posaune spielen"));
		var jsonb = JsonbBuilder.create();
		jsonb.toJson(p, new FileOutputStream("person.json"));
	}
}
