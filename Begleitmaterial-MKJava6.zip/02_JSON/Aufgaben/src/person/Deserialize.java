package person;

import jakarta.json.bind.JsonbBuilder;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Deserialize {
	public static void main(String[] args) throws FileNotFoundException {
		var jsonb = JsonbBuilder.create();
		var p = jsonb.fromJson(new FileInputStream("person.json"), Person.class);
		System.out.println(p);
	}
}
