package person;

import jakarta.json.bind.annotation.JsonbPropertyOrder;

import java.util.List;

@JsonbPropertyOrder({"id", "name", "age", "hobbies"})
public class Person {
    private int id;
    private String name;
    private int age;
    private List<String> hobbys;

    public Person() {
    }

    public Person(int id, String name, int age) {
        this.id = id;
        this.name = name;
        this.age = age;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public List<String> getHobbys() {
        return hobbys;
    }

    public void setHobbys(List<String> hobbys) {
        this.hobbys = hobbys;
    }

    @Override
    public String toString() {
        return "Person{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", age=" + age +
                ", hobbys=" + hobbys +
                '}';
    }
}
