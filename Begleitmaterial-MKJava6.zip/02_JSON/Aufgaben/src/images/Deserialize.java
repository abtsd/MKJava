package images;

import jakarta.json.bind.JsonbBuilder;
import jakarta.json.bind.JsonbConfig;
import jakarta.json.bind.config.BinaryDataStrategy;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class Deserialize {
	public static void main(String[] args) throws IOException {
		var jsonbConfig = new JsonbConfig().withBinaryDataStrategy(BinaryDataStrategy.BASE_64);
		var jsonb = JsonbBuilder.create(jsonbConfig);
		var type = new ArrayList<MyImage>() {}.getClass().getGenericSuperclass();
		List<MyImage> images = jsonb.fromJson(new FileInputStream("images.json"), type);
		for (MyImage image : images) {
			System.out.println(image.getName());
			saveImage(image.getData(), image.getName() + "." + image.getType());
		}
	}

	private static void saveImage(byte[] data, String filename) throws IOException {
		Files.write(Paths.get(filename), data);
	}
}
