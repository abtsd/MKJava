package images;

import jakarta.json.bind.JsonbBuilder;
import jakarta.json.bind.JsonbConfig;
import jakarta.json.bind.config.BinaryDataStrategy;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class Serialize {
	public static void main(String[] args) throws IOException {
		var image1 = new MyImage("Facebook", "png", loadImage("images/facebook.png"));
		var image2 = new MyImage("WhatsApp", "png", loadImage("images/whatsapp.png"));
		var images = List.of(image1, image2);

		var jsonbConfig = new JsonbConfig().withBinaryDataStrategy(BinaryDataStrategy.BASE_64);
		var jsonb = JsonbBuilder.create(jsonbConfig);
		jsonb.toJson(images, new FileOutputStream("images.json"));
	}

	private static byte[] loadImage(String filename) throws IOException {
		return Files.readAllBytes(Paths.get(filename));
	}
}
