java -cp out/production/json;../../libs/json/* DefaultTypesTest
java -cp out/production/json;../../libs/json/* ConvertTest
java -cp out/production/json;../../libs/json/* Serialize
java -cp out/production/json Test
java -cp out/production/json;../../libs/json/* Deserialize
