import jakarta.json.bind.JsonbBuilder;

import model.Artikel;
import model.Bestellposition;
import model.Bestellung;
import model.Kunde;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.time.LocalDate;
import java.util.List;

public class Serialize {
    public static void main(String[] args) throws FileNotFoundException {
        var a1 = new Artikel(4711, 10., 100);
        var a2 = new Artikel(4712, 20., 200);
        var a3 = new Artikel(4713, 30., 300);

        var k1 = new Kunde(1, "Hugo Meier");
        var k2 = new Kunde(2, "Emil Schulz");

        var b1 = new Bestellung(101, LocalDate.now());
        b1.setKunde(k1);

        var p11 = new Bestellposition(1, 3);
        p11.setArtikel(a1);
        b1.addPosition(p11);

        var p12 = new Bestellposition(2, 10);
        p12.setArtikel(a2);
        b1.addPosition(p12);

        var b2 = new Bestellung(102, LocalDate.now());
        b2.setKunde(k2);

        var p21 = new Bestellposition(1, 1);
        p21.setArtikel(a1);
        b2.addPosition(p21);

        var p22 = new Bestellposition(2, 5);
        p22.setArtikel(a3);
        b2.addPosition(p22);

        var bestellungen = List.of(b1, b2);

        var jsonb = JsonbBuilder.create();
        jsonb.toJson(bestellungen, new FileOutputStream("bestellungen.json"));
    }
}
