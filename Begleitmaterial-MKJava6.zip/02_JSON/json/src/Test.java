import model.Bestellung;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class Test {
    public static void main(String[] args) {
		Class<?> cls = new ArrayList<Bestellung>() {}.getClass();
        System.out.println(cls.isAnonymousClass());

        // If the superclass is a parameterized type,
        // the Type object returned must accurately reflect
        // the actual type arguments used in the source code.
        Type type = cls.getGenericSuperclass();
        System.out.println(type);
    }
}
