import jakarta.json.bind.JsonbBuilder;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class DefaultTypesTest {
    public static void main(String[] args) {
        var jsonb = JsonbBuilder.create();

        var array = new String[]{"one", "two", "three"};
        var list = List.of("one", "two", "three");
        var set = Set.of(1, 2, 3);
        var map = Map.ofEntries(
                Map.entry("Hugo", 22),
                Map.entry("Emil", 25),
                Map.entry("Tim", 18)
        );

        System.out.println("--- Serialize: Objekt -> JSON-Dokument");

        var json1 = jsonb.toJson(array);
        System.out.println(json1);

        var json2 = jsonb.toJson(list);
        System.out.println(json1);

        var json3 = jsonb.toJson(set);
        System.out.println(json3);

        var json4 = jsonb.toJson(map);
        System.out.println(json4);

        System.out.println("--- Deserialize: JSON-Dokument -> Objekt");

        var array1 = jsonb.fromJson(json1, List.class);
        System.out.println(array1);

        var list1 = jsonb.fromJson(json2, List.class);
        System.out.println(list1);

        var set1 = jsonb.fromJson(json3, Set.class);
        System.out.println(set1);

        var map1 = jsonb.fromJson(json4, Map.class);
        System.out.println(map1);
    }
}
