import jakarta.json.bind.JsonbBuilder;
import model.Bestellung;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

public class Deserialize {
    public static void main(String[] args) throws FileNotFoundException {
        var jsonb = JsonbBuilder.create();
        var type = new ArrayList<Bestellung>() {}.getClass().getGenericSuperclass();
        List<Bestellung> bestellungen = jsonb.fromJson(new FileInputStream("bestellungen.json"), type);

        for (var b : bestellungen) {
            System.out.println(b.getKunde());
            System.out.println("   " + b);
            for (var bpos : b.getPositionen()) {
                System.out.println("      " + bpos);
                System.out.println("         " + bpos.getArtikel());
            }
            System.out.println();
        }
    }
}
