java -cp out/production/Aufgaben Lookup localhost
java -cp out/production/Aufgaben Lookup www.microsoft.de
java -cp out/production/Aufgaben Lookup www.google.de
java -cp out/production/Aufgaben Lookup 192.168.2.1
java -cp out/production/Aufgaben Lookup 1.2.3.4

java -cp out/production/Aufgaben LocalhostV1
jar --create --file localhostv1.jar --main-class LocalhostV1 -C out/production/Aufgaben LocalhostV1.class

java -cp out/production/Aufgaben LocalhostV2
jar --create --file localhostv2.jar --main-class LocalhostV2 -C out/production/Aufgaben LocalhostV2.class

java -cp out/production/Aufgaben IPClass localhost
java -cp out/production/Aufgaben IPClass 192.168.2.99
java -cp out/production/Aufgaben IPClass www.microsoft.de
