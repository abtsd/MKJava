import java.net.InetAddress;
import java.net.UnknownHostException;

public class Lookup {
    public static void main(String[] args) {
        String host = args[0];

        try {
            var addresses = InetAddress.getAllByName(host);
            var isNumber = Character.isDigit(host.charAt(0));

            for (var addr : addresses) {
                var hostAddress = addr.getHostAddress();
                var hostName = addr.getHostName();

                if (isNumber) {
                    if (hostAddress.equals(hostName)) {
                        System.out.println("Der Hostname zu " + hostAddress + " kann nicht ermittelt werden.");
                    } else {
                        System.out.println(hostAddress + " -> " + hostName);
                    }
                } else {
                    System.out.println(hostName + " -> " + hostAddress);
                }
            }
        } catch (UnknownHostException e) {
            System.err.println("Der Host " + host + " ist nicht bekannt.");
        }
    }
}
