import javax.swing.*;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class LocalhostV1 {
    public static void main(String[] args) {
        try {
            var address = InetAddress.getLocalHost();
            var message = "<html><span style='font-family: monospace; font-size: 24; color: blue;'>"
                    + address.getHostName()
                    + "/" + address.getHostAddress()
                    + "</span></html>";
            JOptionPane.showMessageDialog(null,
                    message, "LocalHost",
                    JOptionPane.PLAIN_MESSAGE);
        } catch (UnknownHostException ignored) {
        }
    }
}
