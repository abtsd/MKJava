import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class IPClass {
    public static void main(String[] args) throws UnknownHostException {
        var host = args[0];

        InetAddress address = InetAddress.getByName(host);
        if (address instanceof Inet6Address)
            return;

        String ip = address.getHostAddress();
        String first = ip.substring(0, ip.indexOf('.'));
        int n = Integer.parseInt(first);

        char c;
        if (n >= 0 && n <= 127)
            c = 'A';
        else if (n >= 128 && n <= 191)
            c = 'B';
        else if (n >= 192 && n <= 223)
            c = 'C';
        else if (n >= 224 && n <= 239)
            c = 'D';
        else
            c = 'E';

        System.out.println(ip + " -> " + c);
    }
}
