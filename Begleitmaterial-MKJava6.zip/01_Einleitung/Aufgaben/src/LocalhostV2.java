import javax.swing.*;
import java.net.Inet4Address;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Collections;

public class LocalhostV2 {
	public static void main(String[] args) {
		try {
			var message = new StringBuffer();
			var nets = NetworkInterface.getNetworkInterfaces();
			message.append("<html><span style='font-family: monospace; font-size: 24; color: blue;'>");
			for (var netif : Collections.list(nets)) {
				var addresses = netif.getInetAddresses();
				for (var address : Collections.list(addresses)) {
					if (!address.isLoopbackAddress() && address instanceof Inet4Address) {
						message.append(netif.getDisplayName())
								.append(":")
								.append("<br>")
								.append(address.getHostName())
								.append("/")
								.append(address.getHostAddress())
								.append("<br><br>");
					}
				}
			}
			message.append("</span></html>");

			JOptionPane.showMessageDialog(null,
					message, "LocalHost",
					JOptionPane.PLAIN_MESSAGE);
		} catch (SocketException ignored) {
		}
	}
}
