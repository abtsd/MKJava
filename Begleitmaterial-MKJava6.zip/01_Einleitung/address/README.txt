java -cp out/production/address LocalhostV1
java -cp out/production/address LocalhostV2
java -cp out/production/address Lookup www.hs-niederrhein.de
java -cp out/production/address CreateSocketAddress
