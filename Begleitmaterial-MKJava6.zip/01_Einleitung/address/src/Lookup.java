import java.net.InetAddress;
import java.net.UnknownHostException;

public class Lookup {
    public static void main(String[] args) throws UnknownHostException {
        var host = args[0];
        var address = InetAddress.getByName(host);
        System.out.printf("Looking up %s -> %s/%s%n",
                host,
                address.getHostName(),
                address.getHostAddress());
    }
}