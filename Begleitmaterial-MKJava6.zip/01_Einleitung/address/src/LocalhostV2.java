import java.net.Inet4Address;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Collections;

public class LocalhostV2 {
	public static void main(String[] args) throws SocketException {
		var nets = NetworkInterface.getNetworkInterfaces();
		for (var netif : Collections.list(nets)) {
			var addresses = netif.getInetAddresses();
			for (var address : Collections.list(addresses)) {
				if (!address.isLoopbackAddress() && address instanceof Inet4Address) {
					System.out.printf("%s:%n%s/%s%n",
							netif.getDisplayName(),
							address.getHostName(),
							address.getHostAddress());
				}
			}
		}
	}
}
