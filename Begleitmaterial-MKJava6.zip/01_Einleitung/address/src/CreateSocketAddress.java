import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;

public class CreateSocketAddress {
    public static void main(String[] args) throws UnknownHostException {
        var address = InetAddress.getByName("www.google.de");
        var socketAddress = new InetSocketAddress(address, 80);
        output(socketAddress);

        socketAddress = new InetSocketAddress(80);
        output(socketAddress);

        socketAddress = new InetSocketAddress("www.google.de", 80);
        output(socketAddress);

        socketAddress = new InetSocketAddress("localhost", 80);
        output(socketAddress);
    }

    private static void output(InetSocketAddress socketAddress) {
        System.out.printf("Address: %s%n   Hostname: %s%n   Port: %s%n",
                socketAddress.getAddress(),
                socketAddress.getHostName(),
                socketAddress.getPort());
    }
}
