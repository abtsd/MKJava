import java.net.InetAddress;
import java.net.UnknownHostException;

public class LocalhostV1 {
    public static void main(String[] args) throws UnknownHostException {
        var address = InetAddress.getLocalHost();
        System.out.printf("%s/%s%n",
                address.getHostName(),
                address.getHostAddress());
    }
}